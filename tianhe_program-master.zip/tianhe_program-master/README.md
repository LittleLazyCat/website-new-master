---
title: 颐养天和疗养中心系统-归档
welcome: 一款基于【SpringBoot Spring Mybatis】的web项目
---

###### <sub></sub><br />颐养天和疗养中心系统<br />2021·04·21<br /><br /><br />**alien·tanyajun**<br />*黑龙江省哈尔滨市哈尔滨学院*

[TOC]

# 项目介绍

1. 名称：颐养天和疗养中心系统

2. 描述：为了适应养老、托老、疗养服务类的需求，‘颐养天和’颐养中心系统主要以疗养服务为场景，满足客户入住、档案登记、护理调养、膳食定制等一系列功能需求，结合疗养机构实现Web浏览器端的线上服务

3. 系统功能流程：

   - <img src="https://gitee.com/tanyajun/picgo-for-myself/raw/master/imgs/image-20210526183645403.png?padding=true" alt="系统功能流程图" style="zoom:80%;box-shadow:2px 2px 8px 2px silver" />

4. 业务功能描述

   > - 信息管理模块：包括入住登记、退住登记、档案管理、联系簿、外来登记、外出登记等六个模块，此模块针对服务对象及其相关联系人的身份信息登记
   > - 膳食管理模块：包括膳食分类、膳食菜单、膳食计划等三个模块，此模块主要用于客户日常饮食管理
   > - 护理管理模块：包括护理等级、护理项目、护理计划、护理记录、体检记录等五个模块，此模块主要用于客户日常护理调理
   > - 后勤管理模块：包括设备采购、维修、床位清洁等三个模块，此模块用于日常后勤维护
   > - 床位管理模块：包括房间管理和床位监控两个模块，此模块用于监控和管理客户床位情况
   > - 费用管理模块：此模块主要记录客户在饮食和护理方面的费用明细
   >
   > 除此之外，本系统还包括了权限角色的管理
   > `>(red)`

# 技术点介绍

1. 前台：通过人人开源的renren-fast-vue项目衍生出来，基于Vue+ElementUI搭建的前台页面
2. 后台：通过人人开源的renren-fast项目衍生出来，基于SpringBoot+Spring+Mybatis的后台项目
3. 数据库：采用MySQL关系型数据库存储数据，所使用的版本是MySQL Server5.7

> **声明：本项目是在人人开源的项目基础上，实现的信息系统管理，仅用于学习使用**

# 页面部分截图

### 登录页面

<img src="https://gitee.com/tanyajun/picgo-for-myself/raw/master/imgs/image-20210526191106832.png?padding=true" alt="登录页面" style="zoom:50%;" />

### 档案页面

<img src="https://gitee.com/tanyajun/picgo-for-myself/raw/master/imgs/image-20210526191209222.png?padding=true" alt="档案页面" style="zoom:50%;" />

### 床位监控

<img src="https://gitee.com/tanyajun/picgo-for-myself/raw/master/imgs/image-20210526191401522.png?padding=true" alt="image-20210526191401522" style="zoom:50%;" />

***ps: 在线演示地址：***

###### 归档·完结<br>email: tan92586@163.com
