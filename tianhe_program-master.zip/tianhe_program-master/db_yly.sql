/*
Navicat MySQL Data Transfer

Source Server         : 192.168.76.25
Source Server Version : 50730
Source Host           : 192.168.76.25:3306
Source Database       : db_yly

Target Server Type    : MYSQL
Target Server Version : 50730
File Encoding         : 65001

Date: 2021-05-24 18:59:48
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for qrtz_blob_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_blob_triggers`;
CREATE TABLE `qrtz_blob_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `BLOB_DATA` blob,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  KEY `SCHED_NAME` (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  CONSTRAINT `qrtz_blob_triggers_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `qrtz_triggers` (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qrtz_blob_triggers
-- ----------------------------

-- ----------------------------
-- Table structure for qrtz_calendars
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_calendars`;
CREATE TABLE `qrtz_calendars` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `CALENDAR_NAME` varchar(200) NOT NULL,
  `CALENDAR` blob NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`CALENDAR_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qrtz_calendars
-- ----------------------------

-- ----------------------------
-- Table structure for qrtz_cron_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_cron_triggers`;
CREATE TABLE `qrtz_cron_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `CRON_EXPRESSION` varchar(120) NOT NULL,
  `TIME_ZONE_ID` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  CONSTRAINT `qrtz_cron_triggers_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `qrtz_triggers` (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qrtz_cron_triggers
-- ----------------------------
INSERT INTO `qrtz_cron_triggers` VALUES ('RenrenScheduler', 'TASK_1', 'DEFAULT', '0 0/30 * * * ?', 'Asia/Shanghai');

-- ----------------------------
-- Table structure for qrtz_fired_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_fired_triggers`;
CREATE TABLE `qrtz_fired_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `ENTRY_ID` varchar(95) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `INSTANCE_NAME` varchar(200) NOT NULL,
  `FIRED_TIME` bigint(13) NOT NULL,
  `SCHED_TIME` bigint(13) NOT NULL,
  `PRIORITY` int(11) NOT NULL,
  `STATE` varchar(16) NOT NULL,
  `JOB_NAME` varchar(200) DEFAULT NULL,
  `JOB_GROUP` varchar(200) DEFAULT NULL,
  `IS_NONCONCURRENT` varchar(1) DEFAULT NULL,
  `REQUESTS_RECOVERY` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`SCHED_NAME`,`ENTRY_ID`),
  KEY `IDX_QRTZ_FT_TRIG_INST_NAME` (`SCHED_NAME`,`INSTANCE_NAME`),
  KEY `IDX_QRTZ_FT_INST_JOB_REQ_RCVRY` (`SCHED_NAME`,`INSTANCE_NAME`,`REQUESTS_RECOVERY`),
  KEY `IDX_QRTZ_FT_J_G` (`SCHED_NAME`,`JOB_NAME`,`JOB_GROUP`),
  KEY `IDX_QRTZ_FT_JG` (`SCHED_NAME`,`JOB_GROUP`),
  KEY `IDX_QRTZ_FT_T_G` (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  KEY `IDX_QRTZ_FT_TG` (`SCHED_NAME`,`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qrtz_fired_triggers
-- ----------------------------
INSERT INTO `qrtz_fired_triggers` VALUES ('RenrenScheduler', 'j2613-2416218398573961621839857386', 'TASK_1', 'DEFAULT', 'j2613-241621839857396', '1621853972705', '1621854000000', '5', 'ACQUIRED', null, null, '0', '0');

-- ----------------------------
-- Table structure for qrtz_job_details
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_job_details`;
CREATE TABLE `qrtz_job_details` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `JOB_NAME` varchar(200) NOT NULL,
  `JOB_GROUP` varchar(200) NOT NULL,
  `DESCRIPTION` varchar(250) DEFAULT NULL,
  `JOB_CLASS_NAME` varchar(250) NOT NULL,
  `IS_DURABLE` varchar(1) NOT NULL,
  `IS_NONCONCURRENT` varchar(1) NOT NULL,
  `IS_UPDATE_DATA` varchar(1) NOT NULL,
  `REQUESTS_RECOVERY` varchar(1) NOT NULL,
  `JOB_DATA` blob,
  PRIMARY KEY (`SCHED_NAME`,`JOB_NAME`,`JOB_GROUP`),
  KEY `IDX_QRTZ_J_REQ_RECOVERY` (`SCHED_NAME`,`REQUESTS_RECOVERY`),
  KEY `IDX_QRTZ_J_GRP` (`SCHED_NAME`,`JOB_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qrtz_job_details
-- ----------------------------
INSERT INTO `qrtz_job_details` VALUES ('RenrenScheduler', 'TASK_1', 'DEFAULT', null, 'io.renren.modules.job.utils.ScheduleJob', '0', '0', '0', '0', 0xACED0005737200156F72672E71756172747A2E4A6F62446174614D61709FB083E8BFA9B0CB020000787200266F72672E71756172747A2E7574696C732E537472696E674B65794469727479466C61674D61708208E8C3FBC55D280200015A0013616C6C6F77735472616E7369656E74446174617872001D6F72672E71756172747A2E7574696C732E4469727479466C61674D617013E62EAD28760ACE0200025A000564697274794C00036D617074000F4C6A6176612F7574696C2F4D61703B787001737200116A6176612E7574696C2E486173684D61700507DAC1C31660D103000246000A6C6F6164466163746F724900097468726573686F6C6478703F4000000000000C7708000000100000000174000D4A4F425F504152414D5F4B45597372002E696F2E72656E72656E2E6D6F64756C65732E6A6F622E656E746974792E5363686564756C654A6F62456E7469747900000000000000010200074C00086265616E4E616D657400124C6A6176612F6C616E672F537472696E673B4C000A63726561746554696D657400104C6A6176612F7574696C2F446174653B4C000E63726F6E45787072657373696F6E71007E00094C00056A6F6249647400104C6A6176612F6C616E672F4C6F6E673B4C0006706172616D7371007E00094C000672656D61726B71007E00094C00067374617475737400134C6A6176612F6C616E672F496E74656765723B7870740008746573745461736B7372000E6A6176612E7574696C2E44617465686A81014B597419030000787077080000017917A7F9B87874000E3020302F3330202A202A202A203F7372000E6A6176612E6C616E672E4C6F6E673B8BE490CC8F23DF0200014A000576616C7565787200106A6176612E6C616E672E4E756D62657286AC951D0B94E08B0200007870000000000000000174000672656E72656E74000CE58F82E695B0E6B58BE8AF95737200116A6176612E6C616E672E496E746567657212E2A0A4F781873802000149000576616C75657871007E0013000000007800);

-- ----------------------------
-- Table structure for qrtz_locks
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_locks`;
CREATE TABLE `qrtz_locks` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `LOCK_NAME` varchar(40) NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`LOCK_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qrtz_locks
-- ----------------------------
INSERT INTO `qrtz_locks` VALUES ('RenrenScheduler', 'STATE_ACCESS');
INSERT INTO `qrtz_locks` VALUES ('RenrenScheduler', 'TRIGGER_ACCESS');

-- ----------------------------
-- Table structure for qrtz_paused_trigger_grps
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_paused_trigger_grps`;
CREATE TABLE `qrtz_paused_trigger_grps` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qrtz_paused_trigger_grps
-- ----------------------------

-- ----------------------------
-- Table structure for qrtz_scheduler_state
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_scheduler_state`;
CREATE TABLE `qrtz_scheduler_state` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `INSTANCE_NAME` varchar(200) NOT NULL,
  `LAST_CHECKIN_TIME` bigint(13) NOT NULL,
  `CHECKIN_INTERVAL` bigint(13) NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`INSTANCE_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qrtz_scheduler_state
-- ----------------------------
INSERT INTO `qrtz_scheduler_state` VALUES ('RenrenScheduler', 'j2613-241621839857396', '1621853980463', '15000');

-- ----------------------------
-- Table structure for qrtz_simple_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_simple_triggers`;
CREATE TABLE `qrtz_simple_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `REPEAT_COUNT` bigint(7) NOT NULL,
  `REPEAT_INTERVAL` bigint(12) NOT NULL,
  `TIMES_TRIGGERED` bigint(10) NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  CONSTRAINT `qrtz_simple_triggers_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `qrtz_triggers` (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qrtz_simple_triggers
-- ----------------------------

-- ----------------------------
-- Table structure for qrtz_simprop_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_simprop_triggers`;
CREATE TABLE `qrtz_simprop_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `STR_PROP_1` varchar(512) DEFAULT NULL,
  `STR_PROP_2` varchar(512) DEFAULT NULL,
  `STR_PROP_3` varchar(512) DEFAULT NULL,
  `INT_PROP_1` int(11) DEFAULT NULL,
  `INT_PROP_2` int(11) DEFAULT NULL,
  `LONG_PROP_1` bigint(20) DEFAULT NULL,
  `LONG_PROP_2` bigint(20) DEFAULT NULL,
  `DEC_PROP_1` decimal(13,4) DEFAULT NULL,
  `DEC_PROP_2` decimal(13,4) DEFAULT NULL,
  `BOOL_PROP_1` varchar(1) DEFAULT NULL,
  `BOOL_PROP_2` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  CONSTRAINT `qrtz_simprop_triggers_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `qrtz_triggers` (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qrtz_simprop_triggers
-- ----------------------------

-- ----------------------------
-- Table structure for qrtz_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_triggers`;
CREATE TABLE `qrtz_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `JOB_NAME` varchar(200) NOT NULL,
  `JOB_GROUP` varchar(200) NOT NULL,
  `DESCRIPTION` varchar(250) DEFAULT NULL,
  `NEXT_FIRE_TIME` bigint(13) DEFAULT NULL,
  `PREV_FIRE_TIME` bigint(13) DEFAULT NULL,
  `PRIORITY` int(11) DEFAULT NULL,
  `TRIGGER_STATE` varchar(16) NOT NULL,
  `TRIGGER_TYPE` varchar(8) NOT NULL,
  `START_TIME` bigint(13) NOT NULL,
  `END_TIME` bigint(13) DEFAULT NULL,
  `CALENDAR_NAME` varchar(200) DEFAULT NULL,
  `MISFIRE_INSTR` smallint(2) DEFAULT NULL,
  `JOB_DATA` blob,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  KEY `IDX_QRTZ_T_J` (`SCHED_NAME`,`JOB_NAME`,`JOB_GROUP`),
  KEY `IDX_QRTZ_T_JG` (`SCHED_NAME`,`JOB_GROUP`),
  KEY `IDX_QRTZ_T_C` (`SCHED_NAME`,`CALENDAR_NAME`),
  KEY `IDX_QRTZ_T_G` (`SCHED_NAME`,`TRIGGER_GROUP`),
  KEY `IDX_QRTZ_T_STATE` (`SCHED_NAME`,`TRIGGER_STATE`),
  KEY `IDX_QRTZ_T_N_STATE` (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`,`TRIGGER_STATE`),
  KEY `IDX_QRTZ_T_N_G_STATE` (`SCHED_NAME`,`TRIGGER_GROUP`,`TRIGGER_STATE`),
  KEY `IDX_QRTZ_T_NEXT_FIRE_TIME` (`SCHED_NAME`,`NEXT_FIRE_TIME`),
  KEY `IDX_QRTZ_T_NFT_ST` (`SCHED_NAME`,`TRIGGER_STATE`,`NEXT_FIRE_TIME`),
  KEY `IDX_QRTZ_T_NFT_MISFIRE` (`SCHED_NAME`,`MISFIRE_INSTR`,`NEXT_FIRE_TIME`),
  KEY `IDX_QRTZ_T_NFT_ST_MISFIRE` (`SCHED_NAME`,`MISFIRE_INSTR`,`NEXT_FIRE_TIME`,`TRIGGER_STATE`),
  KEY `IDX_QRTZ_T_NFT_ST_MISFIRE_GRP` (`SCHED_NAME`,`MISFIRE_INSTR`,`NEXT_FIRE_TIME`,`TRIGGER_GROUP`,`TRIGGER_STATE`),
  CONSTRAINT `qrtz_triggers_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `JOB_NAME`, `JOB_GROUP`) REFERENCES `qrtz_job_details` (`SCHED_NAME`, `JOB_NAME`, `JOB_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qrtz_triggers
-- ----------------------------
INSERT INTO `qrtz_triggers` VALUES ('RenrenScheduler', 'TASK_1', 'DEFAULT', 'TASK_1', 'DEFAULT', null, '1621854000000', '1621852200000', '5', 'ACQUIRED', 'CRON', '1619600344000', '0', null, '2', 0xACED0005737200156F72672E71756172747A2E4A6F62446174614D61709FB083E8BFA9B0CB020000787200266F72672E71756172747A2E7574696C732E537472696E674B65794469727479466C61674D61708208E8C3FBC55D280200015A0013616C6C6F77735472616E7369656E74446174617872001D6F72672E71756172747A2E7574696C732E4469727479466C61674D617013E62EAD28760ACE0200025A000564697274794C00036D617074000F4C6A6176612F7574696C2F4D61703B787001737200116A6176612E7574696C2E486173684D61700507DAC1C31660D103000246000A6C6F6164466163746F724900097468726573686F6C6478703F4000000000000C7708000000100000000174000D4A4F425F504152414D5F4B45597372002E696F2E72656E72656E2E6D6F64756C65732E6A6F622E656E746974792E5363686564756C654A6F62456E7469747900000000000000010200074C00086265616E4E616D657400124C6A6176612F6C616E672F537472696E673B4C000A63726561746554696D657400104C6A6176612F7574696C2F446174653B4C000E63726F6E45787072657373696F6E71007E00094C00056A6F6249647400104C6A6176612F6C616E672F4C6F6E673B4C0006706172616D7371007E00094C000672656D61726B71007E00094C00067374617475737400134C6A6176612F6C616E672F496E74656765723B7870740008746573745461736B7372000E6A6176612E7574696C2E44617465686A81014B597419030000787077080000017917A7F9B87874000E3020302F3330202A202A202A203F7372000E6A6176612E6C616E672E4C6F6E673B8BE490CC8F23DF0200014A000576616C7565787200106A6176612E6C616E672E4E756D62657286AC951D0B94E08B0200007870000000000000000174000672656E72656E74000CE58F82E695B0E6B58BE8AF95737200116A6176612E6C616E672E496E746567657212E2A0A4F781873802000149000576616C75657871007E0013000000007800);

-- ----------------------------
-- Table structure for schedule_job
-- ----------------------------
DROP TABLE IF EXISTS `schedule_job`;
CREATE TABLE `schedule_job` (
  `job_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '任务id',
  `bean_name` varchar(200) DEFAULT NULL COMMENT 'spring bean名称',
  `params` varchar(2000) DEFAULT NULL COMMENT '参数',
  `cron_expression` varchar(100) DEFAULT NULL COMMENT 'cron表达式',
  `status` tinyint(4) DEFAULT NULL COMMENT '任务状态  0：正常  1：暂停',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`job_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='定时任务';

-- ----------------------------
-- Records of schedule_job
-- ----------------------------
INSERT INTO `schedule_job` VALUES ('1', 'testTask', 'renren', '0 0/30 * * * ?', '0', '参数测试', '2021-04-28 16:45:55');

-- ----------------------------
-- Table structure for schedule_job_log
-- ----------------------------
DROP TABLE IF EXISTS `schedule_job_log`;
CREATE TABLE `schedule_job_log` (
  `log_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '任务日志id',
  `job_id` bigint(20) NOT NULL COMMENT '任务id',
  `bean_name` varchar(200) DEFAULT NULL COMMENT 'spring bean名称',
  `params` varchar(2000) DEFAULT NULL COMMENT '参数',
  `status` tinyint(4) NOT NULL COMMENT '任务状态    0：成功    1：失败',
  `error` varchar(2000) DEFAULT NULL COMMENT '失败信息',
  `times` int(11) NOT NULL COMMENT '耗时(单位：毫秒)',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`log_id`),
  KEY `job_id` (`job_id`)
) ENGINE=InnoDB AUTO_INCREMENT=293 DEFAULT CHARSET=utf8mb4 COMMENT='定时任务日志';

-- ----------------------------
-- Records of schedule_job_log
-- ----------------------------
INSERT INTO `schedule_job_log` VALUES ('1', '1', 'testTask', 'renren', '0', null, '0', '2021-04-28 17:00:00');
INSERT INTO `schedule_job_log` VALUES ('2', '1', 'testTask', 'renren', '0', null, '2', '2021-04-29 09:30:00');
INSERT INTO `schedule_job_log` VALUES ('3', '1', 'testTask', 'renren', '0', null, '1', '2021-04-29 10:00:00');
INSERT INTO `schedule_job_log` VALUES ('4', '1', 'testTask', 'renren', '0', null, '2', '2021-04-29 10:30:00');
INSERT INTO `schedule_job_log` VALUES ('5', '1', 'testTask', 'renren', '0', null, '4', '2021-04-29 11:00:00');
INSERT INTO `schedule_job_log` VALUES ('6', '1', 'testTask', 'renren', '0', null, '1', '2021-04-29 11:30:00');
INSERT INTO `schedule_job_log` VALUES ('7', '1', 'testTask', 'renren', '0', null, '3', '2021-04-29 12:30:00');
INSERT INTO `schedule_job_log` VALUES ('8', '1', 'testTask', 'renren', '0', null, '1', '2021-04-29 13:00:00');
INSERT INTO `schedule_job_log` VALUES ('9', '1', 'testTask', 'renren', '0', null, '1', '2021-04-29 13:30:00');
INSERT INTO `schedule_job_log` VALUES ('10', '1', 'testTask', 'renren', '0', null, '1', '2021-04-29 14:00:00');
INSERT INTO `schedule_job_log` VALUES ('11', '1', 'testTask', 'renren', '0', null, '1', '2021-04-29 14:30:00');
INSERT INTO `schedule_job_log` VALUES ('12', '1', 'testTask', 'renren', '0', null, '9', '2021-04-29 15:00:00');
INSERT INTO `schedule_job_log` VALUES ('13', '1', 'testTask', 'renren', '0', null, '1', '2021-04-29 15:30:00');
INSERT INTO `schedule_job_log` VALUES ('14', '1', 'testTask', 'renren', '0', null, '0', '2021-04-29 16:00:00');
INSERT INTO `schedule_job_log` VALUES ('15', '1', 'testTask', 'renren', '0', null, '1', '2021-04-29 16:30:00');
INSERT INTO `schedule_job_log` VALUES ('16', '1', 'testTask', 'renren', '0', null, '2', '2021-04-29 18:00:00');
INSERT INTO `schedule_job_log` VALUES ('17', '1', 'testTask', 'renren', '0', null, '0', '2021-04-29 19:30:00');
INSERT INTO `schedule_job_log` VALUES ('18', '1', 'testTask', 'renren', '0', null, '1', '2021-04-29 20:00:00');
INSERT INTO `schedule_job_log` VALUES ('19', '1', 'testTask', 'renren', '0', null, '1', '2021-04-29 20:30:00');
INSERT INTO `schedule_job_log` VALUES ('20', '1', 'testTask', 'renren', '0', null, '0', '2021-04-29 21:00:00');
INSERT INTO `schedule_job_log` VALUES ('21', '1', 'testTask', 'renren', '0', null, '0', '2021-04-29 21:30:00');
INSERT INTO `schedule_job_log` VALUES ('22', '1', 'testTask', 'renren', '0', null, '1', '2021-04-29 22:00:00');
INSERT INTO `schedule_job_log` VALUES ('23', '1', 'testTask', 'renren', '0', null, '1', '2021-04-29 22:30:00');
INSERT INTO `schedule_job_log` VALUES ('24', '1', 'testTask', 'renren', '0', null, '1', '2021-04-29 23:00:00');
INSERT INTO `schedule_job_log` VALUES ('25', '1', 'testTask', 'renren', '0', null, '1', '2021-04-29 23:30:00');
INSERT INTO `schedule_job_log` VALUES ('26', '1', 'testTask', 'renren', '0', null, '17', '2021-04-30 00:00:00');
INSERT INTO `schedule_job_log` VALUES ('27', '1', 'testTask', 'renren', '0', null, '3', '2021-04-30 00:30:00');
INSERT INTO `schedule_job_log` VALUES ('28', '1', 'testTask', 'renren', '0', null, '3', '2021-04-30 01:00:00');
INSERT INTO `schedule_job_log` VALUES ('29', '1', 'testTask', 'renren', '0', null, '3', '2021-04-30 01:30:00');
INSERT INTO `schedule_job_log` VALUES ('30', '1', 'testTask', 'renren', '0', null, '1', '2021-04-30 02:00:00');
INSERT INTO `schedule_job_log` VALUES ('31', '1', 'testTask', 'renren', '0', null, '2', '2021-04-30 02:30:00');
INSERT INTO `schedule_job_log` VALUES ('32', '1', 'testTask', 'renren', '0', null, '1', '2021-04-30 03:00:00');
INSERT INTO `schedule_job_log` VALUES ('33', '1', 'testTask', 'renren', '0', null, '2', '2021-04-30 03:30:00');
INSERT INTO `schedule_job_log` VALUES ('34', '1', 'testTask', 'renren', '0', null, '2', '2021-04-30 04:00:00');
INSERT INTO `schedule_job_log` VALUES ('35', '1', 'testTask', 'renren', '0', null, '3', '2021-04-30 04:30:00');
INSERT INTO `schedule_job_log` VALUES ('36', '1', 'testTask', 'renren', '0', null, '2', '2021-04-30 05:00:00');
INSERT INTO `schedule_job_log` VALUES ('37', '1', 'testTask', 'renren', '0', null, '1', '2021-04-30 05:30:00');
INSERT INTO `schedule_job_log` VALUES ('38', '1', 'testTask', 'renren', '0', null, '2', '2021-04-30 06:00:00');
INSERT INTO `schedule_job_log` VALUES ('39', '1', 'testTask', 'renren', '0', null, '2', '2021-04-30 06:30:00');
INSERT INTO `schedule_job_log` VALUES ('40', '1', 'testTask', 'renren', '0', null, '2', '2021-04-30 07:00:00');
INSERT INTO `schedule_job_log` VALUES ('41', '1', 'testTask', 'renren', '0', null, '2', '2021-04-30 07:30:00');
INSERT INTO `schedule_job_log` VALUES ('42', '1', 'testTask', 'renren', '0', null, '1', '2021-04-30 08:00:00');
INSERT INTO `schedule_job_log` VALUES ('43', '1', 'testTask', 'renren', '0', null, '2', '2021-04-30 08:30:00');
INSERT INTO `schedule_job_log` VALUES ('44', '1', 'testTask', 'renren', '0', null, '2', '2021-04-30 09:00:00');
INSERT INTO `schedule_job_log` VALUES ('45', '1', 'testTask', 'renren', '0', null, '2', '2021-04-30 09:30:00');
INSERT INTO `schedule_job_log` VALUES ('46', '1', 'testTask', 'renren', '0', null, '2', '2021-04-30 10:00:00');
INSERT INTO `schedule_job_log` VALUES ('47', '1', 'testTask', 'renren', '0', null, '1', '2021-04-30 10:30:00');
INSERT INTO `schedule_job_log` VALUES ('48', '1', 'testTask', 'renren', '0', null, '1', '2021-04-30 11:00:00');
INSERT INTO `schedule_job_log` VALUES ('49', '1', 'testTask', 'renren', '0', null, '2', '2021-04-30 11:30:00');
INSERT INTO `schedule_job_log` VALUES ('50', '1', 'testTask', 'renren', '0', null, '0', '2021-04-30 13:00:00');
INSERT INTO `schedule_job_log` VALUES ('51', '1', 'testTask', 'renren', '0', null, '1', '2021-04-30 13:30:00');
INSERT INTO `schedule_job_log` VALUES ('52', '1', 'testTask', 'renren', '0', null, '1', '2021-04-30 14:00:00');
INSERT INTO `schedule_job_log` VALUES ('53', '1', 'testTask', 'renren', '0', null, '1', '2021-04-30 14:30:00');
INSERT INTO `schedule_job_log` VALUES ('54', '1', 'testTask', 'renren', '0', null, '2', '2021-04-30 15:00:00');
INSERT INTO `schedule_job_log` VALUES ('55', '1', 'testTask', 'renren', '0', null, '0', '2021-04-30 15:30:00');
INSERT INTO `schedule_job_log` VALUES ('56', '1', 'testTask', 'renren', '0', null, '1', '2021-04-30 16:00:00');
INSERT INTO `schedule_job_log` VALUES ('57', '1', 'testTask', 'renren', '0', null, '1', '2021-04-30 16:30:00');
INSERT INTO `schedule_job_log` VALUES ('58', '1', 'testTask', 'renren', '0', null, '1', '2021-04-30 17:00:00');
INSERT INTO `schedule_job_log` VALUES ('59', '1', 'testTask', 'renren', '0', null, '2', '2021-04-30 17:30:00');
INSERT INTO `schedule_job_log` VALUES ('60', '1', 'testTask', 'renren', '0', null, '0', '2021-05-06 11:30:00');
INSERT INTO `schedule_job_log` VALUES ('61', '1', 'testTask', 'renren', '0', null, '1', '2021-05-06 12:00:00');
INSERT INTO `schedule_job_log` VALUES ('62', '1', 'testTask', 'renren', '0', null, '1', '2021-05-06 12:30:00');
INSERT INTO `schedule_job_log` VALUES ('63', '1', 'testTask', 'renren', '0', null, '2', '2021-05-06 13:00:00');
INSERT INTO `schedule_job_log` VALUES ('64', '1', 'testTask', 'renren', '0', null, '2', '2021-05-06 13:30:00');
INSERT INTO `schedule_job_log` VALUES ('65', '1', 'testTask', 'renren', '0', null, '2', '2021-05-06 14:00:00');
INSERT INTO `schedule_job_log` VALUES ('66', '1', 'testTask', 'renren', '0', null, '1', '2021-05-06 14:30:00');
INSERT INTO `schedule_job_log` VALUES ('67', '1', 'testTask', 'renren', '0', null, '1', '2021-05-06 15:00:00');
INSERT INTO `schedule_job_log` VALUES ('68', '1', 'testTask', 'renren', '0', null, '1', '2021-05-06 15:30:00');
INSERT INTO `schedule_job_log` VALUES ('69', '1', 'testTask', 'renren', '0', null, '1', '2021-05-06 16:00:00');
INSERT INTO `schedule_job_log` VALUES ('70', '1', 'testTask', 'renren', '0', null, '1', '2021-05-06 16:30:00');
INSERT INTO `schedule_job_log` VALUES ('71', '1', 'testTask', 'renren', '0', null, '0', '2021-05-06 17:00:00');
INSERT INTO `schedule_job_log` VALUES ('72', '1', 'testTask', 'renren', '0', null, '1', '2021-05-06 16:30:00');
INSERT INTO `schedule_job_log` VALUES ('73', '1', 'testTask', 'renren', '0', null, '1', '2021-05-06 17:00:00');
INSERT INTO `schedule_job_log` VALUES ('74', '1', 'testTask', 'renren', '0', null, '1', '2021-05-06 18:00:00');
INSERT INTO `schedule_job_log` VALUES ('75', '1', 'testTask', 'renren', '0', null, '2', '2021-05-06 18:30:00');
INSERT INTO `schedule_job_log` VALUES ('76', '1', 'testTask', 'renren', '0', null, '1', '2021-05-06 19:00:00');
INSERT INTO `schedule_job_log` VALUES ('77', '1', 'testTask', 'renren', '0', null, '1', '2021-05-06 19:30:00');
INSERT INTO `schedule_job_log` VALUES ('78', '1', 'testTask', 'renren', '0', null, '1', '2021-05-06 20:00:00');
INSERT INTO `schedule_job_log` VALUES ('79', '1', 'testTask', 'renren', '0', null, '1', '2021-05-06 20:30:00');
INSERT INTO `schedule_job_log` VALUES ('80', '1', 'testTask', 'renren', '0', null, '0', '2021-05-06 21:00:00');
INSERT INTO `schedule_job_log` VALUES ('81', '1', 'testTask', 'renren', '0', null, '1', '2021-05-06 21:30:00');
INSERT INTO `schedule_job_log` VALUES ('82', '1', 'testTask', 'renren', '0', null, '0', '2021-05-06 22:00:00');
INSERT INTO `schedule_job_log` VALUES ('83', '1', 'testTask', 'renren', '0', null, '1', '2021-05-06 22:30:00');
INSERT INTO `schedule_job_log` VALUES ('84', '1', 'testTask', 'renren', '0', null, '0', '2021-05-06 23:00:00');
INSERT INTO `schedule_job_log` VALUES ('85', '1', 'testTask', 'renren', '0', null, '0', '2021-05-06 23:30:00');
INSERT INTO `schedule_job_log` VALUES ('86', '1', 'testTask', 'renren', '0', null, '30', '2021-05-07 00:00:00');
INSERT INTO `schedule_job_log` VALUES ('87', '1', 'testTask', 'renren', '0', null, '1', '2021-05-07 00:30:00');
INSERT INTO `schedule_job_log` VALUES ('88', '1', 'testTask', 'renren', '0', null, '1', '2021-05-07 01:00:00');
INSERT INTO `schedule_job_log` VALUES ('89', '1', 'testTask', 'renren', '0', null, '0', '2021-05-07 01:30:00');
INSERT INTO `schedule_job_log` VALUES ('90', '1', 'testTask', 'renren', '0', null, '0', '2021-05-07 02:00:00');
INSERT INTO `schedule_job_log` VALUES ('91', '1', 'testTask', 'renren', '0', null, '1', '2021-05-07 02:30:00');
INSERT INTO `schedule_job_log` VALUES ('92', '1', 'testTask', 'renren', '0', null, '1', '2021-05-07 03:00:00');
INSERT INTO `schedule_job_log` VALUES ('93', '1', 'testTask', 'renren', '0', null, '1', '2021-05-07 03:30:00');
INSERT INTO `schedule_job_log` VALUES ('94', '1', 'testTask', 'renren', '0', null, '1', '2021-05-07 04:00:00');
INSERT INTO `schedule_job_log` VALUES ('95', '1', 'testTask', 'renren', '0', null, '0', '2021-05-07 04:30:00');
INSERT INTO `schedule_job_log` VALUES ('96', '1', 'testTask', 'renren', '0', null, '1', '2021-05-07 05:00:00');
INSERT INTO `schedule_job_log` VALUES ('97', '1', 'testTask', 'renren', '0', null, '1', '2021-05-07 05:30:00');
INSERT INTO `schedule_job_log` VALUES ('98', '1', 'testTask', 'renren', '0', null, '0', '2021-05-07 06:00:00');
INSERT INTO `schedule_job_log` VALUES ('99', '1', 'testTask', 'renren', '0', null, '0', '2021-05-07 06:30:00');
INSERT INTO `schedule_job_log` VALUES ('100', '1', 'testTask', 'renren', '0', null, '0', '2021-05-07 07:00:00');
INSERT INTO `schedule_job_log` VALUES ('101', '1', 'testTask', 'renren', '0', null, '0', '2021-05-07 07:30:00');
INSERT INTO `schedule_job_log` VALUES ('102', '1', 'testTask', 'renren', '0', null, '0', '2021-05-07 08:00:00');
INSERT INTO `schedule_job_log` VALUES ('103', '1', 'testTask', 'renren', '0', null, '2', '2021-05-07 09:00:00');
INSERT INTO `schedule_job_log` VALUES ('104', '1', 'testTask', 'renren', '0', null, '1', '2021-05-07 09:30:00');
INSERT INTO `schedule_job_log` VALUES ('105', '1', 'testTask', 'renren', '0', null, '2', '2021-05-07 10:00:00');
INSERT INTO `schedule_job_log` VALUES ('106', '1', 'testTask', 'renren', '0', null, '1', '2021-05-07 10:30:00');
INSERT INTO `schedule_job_log` VALUES ('107', '1', 'testTask', 'renren', '0', null, '0', '2021-05-07 11:00:00');
INSERT INTO `schedule_job_log` VALUES ('108', '1', 'testTask', 'renren', '0', null, '1', '2021-05-07 12:30:00');
INSERT INTO `schedule_job_log` VALUES ('109', '1', 'testTask', 'renren', '0', null, '1', '2021-05-07 12:00:00');
INSERT INTO `schedule_job_log` VALUES ('110', '1', 'testTask', 'renren', '0', null, '1', '2021-05-07 13:30:00');
INSERT INTO `schedule_job_log` VALUES ('111', '1', 'testTask', 'renren', '0', null, '1', '2021-05-07 14:00:00');
INSERT INTO `schedule_job_log` VALUES ('112', '1', 'testTask', 'renren', '0', null, '1', '2021-05-07 14:30:00');
INSERT INTO `schedule_job_log` VALUES ('113', '1', 'testTask', 'renren', '0', null, '1', '2021-05-07 15:00:00');
INSERT INTO `schedule_job_log` VALUES ('114', '1', 'testTask', 'renren', '0', null, '1', '2021-05-07 15:30:00');
INSERT INTO `schedule_job_log` VALUES ('115', '1', 'testTask', 'renren', '0', null, '1', '2021-05-07 16:00:00');
INSERT INTO `schedule_job_log` VALUES ('116', '1', 'testTask', 'renren', '0', null, '1', '2021-05-07 16:30:00');
INSERT INTO `schedule_job_log` VALUES ('117', '1', 'testTask', 'renren', '0', null, '1', '2021-05-07 17:00:00');
INSERT INTO `schedule_job_log` VALUES ('118', '1', 'testTask', 'renren', '0', null, '0', '2021-05-07 17:30:00');
INSERT INTO `schedule_job_log` VALUES ('119', '1', 'testTask', 'renren', '0', null, '0', '2021-05-08 09:00:00');
INSERT INTO `schedule_job_log` VALUES ('120', '1', 'testTask', 'renren', '0', null, '1', '2021-05-08 10:30:00');
INSERT INTO `schedule_job_log` VALUES ('121', '1', 'testTask', 'renren', '0', null, '0', '2021-05-08 11:00:00');
INSERT INTO `schedule_job_log` VALUES ('122', '1', 'testTask', 'renren', '0', null, '0', '2021-05-08 11:30:00');
INSERT INTO `schedule_job_log` VALUES ('123', '1', 'testTask', 'renren', '0', null, '0', '2021-05-08 12:00:00');
INSERT INTO `schedule_job_log` VALUES ('124', '1', 'testTask', 'renren', '0', null, '0', '2021-05-08 12:30:00');
INSERT INTO `schedule_job_log` VALUES ('125', '1', 'testTask', 'renren', '0', null, '0', '2021-05-08 13:00:00');
INSERT INTO `schedule_job_log` VALUES ('126', '1', 'testTask', 'renren', '0', null, '0', '2021-05-08 13:30:00');
INSERT INTO `schedule_job_log` VALUES ('127', '1', 'testTask', 'renren', '0', null, '0', '2021-05-08 14:00:00');
INSERT INTO `schedule_job_log` VALUES ('128', '1', 'testTask', 'renren', '0', null, '0', '2021-05-08 14:30:00');
INSERT INTO `schedule_job_log` VALUES ('129', '1', 'testTask', 'renren', '0', null, '0', '2021-05-08 15:00:00');
INSERT INTO `schedule_job_log` VALUES ('130', '1', 'testTask', 'renren', '0', null, '1', '2021-05-08 15:30:00');
INSERT INTO `schedule_job_log` VALUES ('131', '1', 'testTask', 'renren', '0', null, '0', '2021-05-08 16:00:00');
INSERT INTO `schedule_job_log` VALUES ('132', '1', 'testTask', 'renren', '0', null, '0', '2021-05-08 16:30:00');
INSERT INTO `schedule_job_log` VALUES ('133', '1', 'testTask', 'renren', '0', null, '0', '2021-05-08 17:00:00');
INSERT INTO `schedule_job_log` VALUES ('134', '1', 'testTask', 'renren', '0', null, '0', '2021-05-08 17:30:00');
INSERT INTO `schedule_job_log` VALUES ('135', '1', 'testTask', 'renren', '0', null, '1', '2021-05-08 17:00:00');
INSERT INTO `schedule_job_log` VALUES ('136', '1', 'testTask', 'renren', '0', null, '1', '2021-05-08 19:00:00');
INSERT INTO `schedule_job_log` VALUES ('137', '1', 'testTask', 'renren', '0', null, '1', '2021-05-08 19:30:00');
INSERT INTO `schedule_job_log` VALUES ('138', '1', 'testTask', 'renren', '0', null, '1', '2021-05-08 20:00:00');
INSERT INTO `schedule_job_log` VALUES ('139', '1', 'testTask', 'renren', '0', null, '1', '2021-05-08 20:30:00');
INSERT INTO `schedule_job_log` VALUES ('140', '1', 'testTask', 'renren', '0', null, '0', '2021-05-08 21:00:00');
INSERT INTO `schedule_job_log` VALUES ('141', '1', 'testTask', 'renren', '0', null, '1', '2021-05-08 21:30:00');
INSERT INTO `schedule_job_log` VALUES ('142', '1', 'testTask', 'renren', '0', null, '0', '2021-05-08 22:00:00');
INSERT INTO `schedule_job_log` VALUES ('143', '1', 'testTask', 'renren', '0', null, '0', '2021-05-08 22:30:00');
INSERT INTO `schedule_job_log` VALUES ('144', '1', 'testTask', 'renren', '0', null, '0', '2021-05-08 23:00:00');
INSERT INTO `schedule_job_log` VALUES ('145', '1', 'testTask', 'renren', '0', null, '0', '2021-05-08 23:30:00');
INSERT INTO `schedule_job_log` VALUES ('146', '1', 'testTask', 'renren', '0', null, '8', '2021-05-09 00:00:00');
INSERT INTO `schedule_job_log` VALUES ('147', '1', 'testTask', 'renren', '0', null, '1', '2021-05-09 00:30:00');
INSERT INTO `schedule_job_log` VALUES ('148', '1', 'testTask', 'renren', '0', null, '0', '2021-05-09 01:00:00');
INSERT INTO `schedule_job_log` VALUES ('149', '1', 'testTask', 'renren', '0', null, '1', '2021-05-09 01:30:00');
INSERT INTO `schedule_job_log` VALUES ('150', '1', 'testTask', 'renren', '0', null, '0', '2021-05-09 02:00:00');
INSERT INTO `schedule_job_log` VALUES ('151', '1', 'testTask', 'renren', '0', null, '1', '2021-05-09 02:30:00');
INSERT INTO `schedule_job_log` VALUES ('152', '1', 'testTask', 'renren', '0', null, '0', '2021-05-09 03:00:00');
INSERT INTO `schedule_job_log` VALUES ('153', '1', 'testTask', 'renren', '0', null, '1', '2021-05-09 03:30:00');
INSERT INTO `schedule_job_log` VALUES ('154', '1', 'testTask', 'renren', '0', null, '0', '2021-05-09 04:00:00');
INSERT INTO `schedule_job_log` VALUES ('155', '1', 'testTask', 'renren', '0', null, '1', '2021-05-09 04:30:00');
INSERT INTO `schedule_job_log` VALUES ('156', '1', 'testTask', 'renren', '0', null, '0', '2021-05-09 05:00:00');
INSERT INTO `schedule_job_log` VALUES ('157', '1', 'testTask', 'renren', '0', null, '1', '2021-05-09 05:30:00');
INSERT INTO `schedule_job_log` VALUES ('158', '1', 'testTask', 'renren', '0', null, '1', '2021-05-09 06:00:00');
INSERT INTO `schedule_job_log` VALUES ('159', '1', 'testTask', 'renren', '0', null, '1', '2021-05-09 06:30:00');
INSERT INTO `schedule_job_log` VALUES ('160', '1', 'testTask', 'renren', '0', null, '1', '2021-05-09 07:00:00');
INSERT INTO `schedule_job_log` VALUES ('161', '1', 'testTask', 'renren', '0', null, '1', '2021-05-09 07:30:00');
INSERT INTO `schedule_job_log` VALUES ('162', '1', 'testTask', 'renren', '0', null, '1', '2021-05-09 08:00:00');
INSERT INTO `schedule_job_log` VALUES ('163', '1', 'testTask', 'renren', '0', null, '1', '2021-05-09 08:30:00');
INSERT INTO `schedule_job_log` VALUES ('164', '1', 'testTask', 'renren', '0', null, '1', '2021-05-09 09:00:00');
INSERT INTO `schedule_job_log` VALUES ('165', '1', 'testTask', 'renren', '0', null, '1', '2021-05-09 10:30:00');
INSERT INTO `schedule_job_log` VALUES ('166', '1', 'testTask', 'renren', '0', null, '1', '2021-05-09 11:00:00');
INSERT INTO `schedule_job_log` VALUES ('167', '1', 'testTask', 'renren', '0', null, '1', '2021-05-09 11:30:00');
INSERT INTO `schedule_job_log` VALUES ('168', '1', 'testTask', 'renren', '0', null, '1', '2021-05-09 12:00:00');
INSERT INTO `schedule_job_log` VALUES ('169', '1', 'testTask', 'renren', '0', null, '0', '2021-05-09 12:30:00');
INSERT INTO `schedule_job_log` VALUES ('170', '1', 'testTask', 'renren', '0', null, '1', '2021-05-09 13:00:00');
INSERT INTO `schedule_job_log` VALUES ('171', '1', 'testTask', 'renren', '0', null, '1', '2021-05-09 13:30:00');
INSERT INTO `schedule_job_log` VALUES ('172', '1', 'testTask', 'renren', '0', null, '1', '2021-05-09 14:00:00');
INSERT INTO `schedule_job_log` VALUES ('173', '1', 'testTask', 'renren', '0', null, '0', '2021-05-09 14:30:00');
INSERT INTO `schedule_job_log` VALUES ('174', '1', 'testTask', 'renren', '0', null, '0', '2021-05-09 15:00:00');
INSERT INTO `schedule_job_log` VALUES ('175', '1', 'testTask', 'renren', '0', null, '0', '2021-05-09 15:30:00');
INSERT INTO `schedule_job_log` VALUES ('176', '1', 'testTask', 'renren', '0', null, '1', '2021-05-09 16:00:00');
INSERT INTO `schedule_job_log` VALUES ('177', '1', 'testTask', 'renren', '0', null, '1', '2021-05-09 16:30:00');
INSERT INTO `schedule_job_log` VALUES ('178', '1', 'testTask', 'renren', '0', null, '1', '2021-05-09 17:00:00');
INSERT INTO `schedule_job_log` VALUES ('179', '1', 'testTask', 'renren', '0', null, '1', '2021-05-09 17:30:00');
INSERT INTO `schedule_job_log` VALUES ('180', '1', 'testTask', 'renren', '0', null, '2', '2021-05-09 18:00:00');
INSERT INTO `schedule_job_log` VALUES ('181', '1', 'testTask', 'renren', '0', null, '0', '2021-05-10 09:30:00');
INSERT INTO `schedule_job_log` VALUES ('182', '1', 'testTask', 'renren', '0', null, '1', '2021-05-10 10:00:00');
INSERT INTO `schedule_job_log` VALUES ('183', '1', 'testTask', 'renren', '0', null, '1', '2021-05-10 10:30:00');
INSERT INTO `schedule_job_log` VALUES ('184', '1', 'testTask', 'renren', '0', null, '1', '2021-05-10 11:00:00');
INSERT INTO `schedule_job_log` VALUES ('185', '1', 'testTask', 'renren', '0', null, '3', '2021-05-10 11:30:00');
INSERT INTO `schedule_job_log` VALUES ('186', '1', 'testTask', 'renren', '0', null, '3', '2021-05-10 12:00:00');
INSERT INTO `schedule_job_log` VALUES ('187', '1', 'testTask', 'renren', '0', null, '0', '2021-05-10 12:30:00');
INSERT INTO `schedule_job_log` VALUES ('188', '1', 'testTask', 'renren', '0', null, '2', '2021-05-10 13:00:00');
INSERT INTO `schedule_job_log` VALUES ('189', '1', 'testTask', 'renren', '0', null, '2', '2021-05-10 13:30:00');
INSERT INTO `schedule_job_log` VALUES ('190', '1', 'testTask', 'renren', '0', null, '0', '2021-05-10 14:00:00');
INSERT INTO `schedule_job_log` VALUES ('191', '1', 'testTask', 'renren', '0', null, '1', '2021-05-10 14:30:00');
INSERT INTO `schedule_job_log` VALUES ('192', '1', 'testTask', 'renren', '0', null, '1', '2021-05-10 15:00:00');
INSERT INTO `schedule_job_log` VALUES ('193', '1', 'testTask', 'renren', '0', null, '2', '2021-05-10 15:30:00');
INSERT INTO `schedule_job_log` VALUES ('194', '1', 'testTask', 'renren', '0', null, '2', '2021-05-10 16:00:00');
INSERT INTO `schedule_job_log` VALUES ('195', '1', 'testTask', 'renren', '0', null, '1', '2021-05-10 16:30:00');
INSERT INTO `schedule_job_log` VALUES ('196', '1', 'testTask', 'renren', '0', null, '0', '2021-05-10 17:00:00');
INSERT INTO `schedule_job_log` VALUES ('197', '1', 'testTask', 'renren', '0', null, '3', '2021-05-10 17:30:00');
INSERT INTO `schedule_job_log` VALUES ('198', '1', 'testTask', 'renren', '0', null, '1', '2021-05-10 18:00:00');
INSERT INTO `schedule_job_log` VALUES ('199', '1', 'testTask', 'renren', '0', null, '1', '2021-05-10 18:30:00');
INSERT INTO `schedule_job_log` VALUES ('200', '1', 'testTask', 'renren', '0', null, '1', '2021-05-10 19:00:00');
INSERT INTO `schedule_job_log` VALUES ('201', '1', 'testTask', 'renren', '0', null, '2', '2021-05-10 19:30:00');
INSERT INTO `schedule_job_log` VALUES ('202', '1', 'testTask', 'renren', '0', null, '0', '2021-05-10 20:00:00');
INSERT INTO `schedule_job_log` VALUES ('203', '1', 'testTask', 'renren', '0', null, '1', '2021-05-10 20:30:00');
INSERT INTO `schedule_job_log` VALUES ('204', '1', 'testTask', 'renren', '0', null, '2', '2021-05-10 21:00:00');
INSERT INTO `schedule_job_log` VALUES ('205', '1', 'testTask', 'renren', '0', null, '1', '2021-05-11 10:30:00');
INSERT INTO `schedule_job_log` VALUES ('206', '1', 'testTask', 'renren', '0', null, '0', '2021-05-11 11:00:00');
INSERT INTO `schedule_job_log` VALUES ('207', '1', 'testTask', 'renren', '0', null, '0', '2021-05-11 11:30:00');
INSERT INTO `schedule_job_log` VALUES ('208', '1', 'testTask', 'renren', '0', null, '1', '2021-05-11 12:00:00');
INSERT INTO `schedule_job_log` VALUES ('209', '1', 'testTask', 'renren', '0', null, '1', '2021-05-11 12:30:00');
INSERT INTO `schedule_job_log` VALUES ('210', '1', 'testTask', 'renren', '0', null, '2', '2021-05-11 13:00:00');
INSERT INTO `schedule_job_log` VALUES ('211', '1', 'testTask', 'renren', '0', null, '2', '2021-05-11 13:30:00');
INSERT INTO `schedule_job_log` VALUES ('212', '1', 'testTask', 'renren', '0', null, '0', '2021-05-11 14:00:00');
INSERT INTO `schedule_job_log` VALUES ('213', '1', 'testTask', 'renren', '0', null, '1', '2021-05-11 14:30:00');
INSERT INTO `schedule_job_log` VALUES ('214', '1', 'testTask', 'renren', '0', null, '0', '2021-05-11 15:00:00');
INSERT INTO `schedule_job_log` VALUES ('215', '1', 'testTask', 'renren', '0', null, '1', '2021-05-11 15:30:00');
INSERT INTO `schedule_job_log` VALUES ('216', '1', 'testTask', 'renren', '0', null, '0', '2021-05-11 16:00:00');
INSERT INTO `schedule_job_log` VALUES ('217', '1', 'testTask', 'renren', '0', null, '1', '2021-05-11 16:30:00');
INSERT INTO `schedule_job_log` VALUES ('218', '1', 'testTask', 'renren', '0', null, '0', '2021-05-11 17:00:00');
INSERT INTO `schedule_job_log` VALUES ('219', '1', 'testTask', 'renren', '0', null, '1', '2021-05-11 17:30:00');
INSERT INTO `schedule_job_log` VALUES ('220', '1', 'testTask', 'renren', '0', null, '0', '2021-05-11 18:00:00');
INSERT INTO `schedule_job_log` VALUES ('221', '1', 'testTask', 'renren', '0', null, '1', '2021-05-11 18:30:00');
INSERT INTO `schedule_job_log` VALUES ('222', '1', 'testTask', 'renren', '0', null, '0', '2021-05-11 19:00:00');
INSERT INTO `schedule_job_log` VALUES ('223', '1', 'testTask', 'renren', '0', null, '1', '2021-05-11 19:30:00');
INSERT INTO `schedule_job_log` VALUES ('224', '1', 'testTask', 'renren', '0', null, '1', '2021-05-12 09:30:00');
INSERT INTO `schedule_job_log` VALUES ('225', '1', 'testTask', 'renren', '0', null, '1', '2021-05-12 10:00:00');
INSERT INTO `schedule_job_log` VALUES ('226', '1', 'testTask', 'renren', '0', null, '0', '2021-05-12 10:30:00');
INSERT INTO `schedule_job_log` VALUES ('227', '1', 'testTask', 'renren', '0', null, '0', '2021-05-12 11:00:00');
INSERT INTO `schedule_job_log` VALUES ('228', '1', 'testTask', 'renren', '0', null, '0', '2021-05-12 11:30:00');
INSERT INTO `schedule_job_log` VALUES ('229', '1', 'testTask', 'renren', '0', null, '0', '2021-05-12 12:00:00');
INSERT INTO `schedule_job_log` VALUES ('230', '1', 'testTask', 'renren', '0', null, '1', '2021-05-12 12:30:00');
INSERT INTO `schedule_job_log` VALUES ('231', '1', 'testTask', 'renren', '0', null, '0', '2021-05-12 13:00:00');
INSERT INTO `schedule_job_log` VALUES ('232', '1', 'testTask', 'renren', '0', null, '0', '2021-05-12 15:30:00');
INSERT INTO `schedule_job_log` VALUES ('233', '1', 'testTask', 'renren', '0', null, '1', '2021-05-14 14:00:00');
INSERT INTO `schedule_job_log` VALUES ('234', '1', 'testTask', 'renren', '0', null, '2', '2021-05-14 14:30:00');
INSERT INTO `schedule_job_log` VALUES ('235', '1', 'testTask', 'renren', '0', null, '1', '2021-05-14 15:00:00');
INSERT INTO `schedule_job_log` VALUES ('236', '1', 'testTask', 'renren', '0', null, '0', '2021-05-14 15:30:00');
INSERT INTO `schedule_job_log` VALUES ('237', '1', 'testTask', 'renren', '0', null, '2', '2021-05-14 17:00:00');
INSERT INTO `schedule_job_log` VALUES ('238', '1', 'testTask', 'renren', '0', null, '6', '2021-05-15 08:30:00');
INSERT INTO `schedule_job_log` VALUES ('239', '1', 'testTask', 'renren', '0', null, '0', '2021-05-15 09:00:00');
INSERT INTO `schedule_job_log` VALUES ('240', '1', 'testTask', 'renren', '0', null, '0', '2021-05-15 09:30:00');
INSERT INTO `schedule_job_log` VALUES ('241', '1', 'testTask', 'renren', '0', null, '0', '2021-05-15 10:00:00');
INSERT INTO `schedule_job_log` VALUES ('242', '1', 'testTask', 'renren', '0', null, '0', '2021-05-15 10:30:00');
INSERT INTO `schedule_job_log` VALUES ('243', '1', 'testTask', 'renren', '0', null, '1', '2021-05-15 11:00:00');
INSERT INTO `schedule_job_log` VALUES ('244', '1', 'testTask', 'renren', '0', null, '0', '2021-05-15 11:30:00');
INSERT INTO `schedule_job_log` VALUES ('245', '1', 'testTask', 'renren', '0', null, '1', '2021-05-15 12:00:00');
INSERT INTO `schedule_job_log` VALUES ('246', '1', 'testTask', 'renren', '0', null, '1', '2021-05-17 09:00:00');
INSERT INTO `schedule_job_log` VALUES ('247', '1', 'testTask', 'renren', '0', null, '2', '2021-05-17 09:30:00');
INSERT INTO `schedule_job_log` VALUES ('248', '1', 'testTask', 'renren', '0', null, '1', '2021-05-17 10:00:00');
INSERT INTO `schedule_job_log` VALUES ('249', '1', 'testTask', 'renren', '0', null, '1', '2021-05-17 10:30:00');
INSERT INTO `schedule_job_log` VALUES ('250', '1', 'testTask', 'renren', '0', null, '2', '2021-05-17 11:00:00');
INSERT INTO `schedule_job_log` VALUES ('251', '1', 'testTask', 'renren', '0', null, '2', '2021-05-17 11:30:00');
INSERT INTO `schedule_job_log` VALUES ('252', '1', 'testTask', 'renren', '0', null, '1', '2021-05-17 12:00:00');
INSERT INTO `schedule_job_log` VALUES ('253', '1', 'testTask', 'renren', '0', null, '2', '2021-05-17 12:30:00');
INSERT INTO `schedule_job_log` VALUES ('254', '1', 'testTask', 'renren', '0', null, '2', '2021-05-17 13:00:00');
INSERT INTO `schedule_job_log` VALUES ('255', '1', 'testTask', 'renren', '0', null, '1', '2021-05-17 13:30:00');
INSERT INTO `schedule_job_log` VALUES ('256', '1', 'testTask', 'renren', '0', null, '2', '2021-05-17 14:00:00');
INSERT INTO `schedule_job_log` VALUES ('257', '1', 'testTask', 'renren', '0', null, '2', '2021-05-17 19:30:00');
INSERT INTO `schedule_job_log` VALUES ('258', '1', 'testTask', 'renren', '0', null, '1', '2021-05-17 20:00:00');
INSERT INTO `schedule_job_log` VALUES ('259', '1', 'testTask', 'renren', '0', null, '1', '2021-05-17 20:30:00');
INSERT INTO `schedule_job_log` VALUES ('260', '1', 'testTask', 'renren', '0', null, '1', '2021-05-17 21:00:00');
INSERT INTO `schedule_job_log` VALUES ('261', '1', 'testTask', 'renren', '0', null, '2', '2021-05-17 21:30:00');
INSERT INTO `schedule_job_log` VALUES ('262', '1', 'testTask', 'renren', '0', null, '3', '2021-05-17 22:00:00');
INSERT INTO `schedule_job_log` VALUES ('263', '1', 'testTask', 'renren', '0', null, '2', '2021-05-17 22:30:00');
INSERT INTO `schedule_job_log` VALUES ('264', '1', 'testTask', 'renren', '0', null, '1', '2021-05-17 23:00:00');
INSERT INTO `schedule_job_log` VALUES ('265', '1', 'testTask', 'renren', '0', null, '1', '2021-05-17 23:30:00');
INSERT INTO `schedule_job_log` VALUES ('266', '1', 'testTask', 'renren', '0', null, '17', '2021-05-18 00:00:00');
INSERT INTO `schedule_job_log` VALUES ('267', '1', 'testTask', 'renren', '0', null, '14', '2021-05-18 00:30:00');
INSERT INTO `schedule_job_log` VALUES ('268', '1', 'testTask', 'renren', '0', null, '2', '2021-05-18 01:00:00');
INSERT INTO `schedule_job_log` VALUES ('269', '1', 'testTask', 'renren', '0', null, '1', '2021-05-18 01:30:00');
INSERT INTO `schedule_job_log` VALUES ('270', '1', 'testTask', 'renren', '0', null, '2', '2021-05-18 02:00:00');
INSERT INTO `schedule_job_log` VALUES ('271', '1', 'testTask', 'renren', '0', null, '2', '2021-05-18 02:30:00');
INSERT INTO `schedule_job_log` VALUES ('272', '1', 'testTask', 'renren', '0', null, '2', '2021-05-18 03:00:00');
INSERT INTO `schedule_job_log` VALUES ('273', '1', 'testTask', 'renren', '0', null, '2', '2021-05-18 03:30:00');
INSERT INTO `schedule_job_log` VALUES ('274', '1', 'testTask', 'renren', '0', null, '1', '2021-05-18 04:00:00');
INSERT INTO `schedule_job_log` VALUES ('275', '1', 'testTask', 'renren', '0', null, '2', '2021-05-18 04:30:00');
INSERT INTO `schedule_job_log` VALUES ('276', '1', 'testTask', 'renren', '0', null, '0', '2021-05-18 05:00:00');
INSERT INTO `schedule_job_log` VALUES ('277', '1', 'testTask', 'renren', '0', null, '2', '2021-05-18 05:30:00');
INSERT INTO `schedule_job_log` VALUES ('278', '1', 'testTask', 'renren', '0', null, '2', '2021-05-18 06:00:00');
INSERT INTO `schedule_job_log` VALUES ('279', '1', 'testTask', 'renren', '0', null, '1', '2021-05-18 06:30:00');
INSERT INTO `schedule_job_log` VALUES ('280', '1', 'testTask', 'renren', '0', null, '2', '2021-05-18 07:00:00');
INSERT INTO `schedule_job_log` VALUES ('281', '1', 'testTask', 'renren', '0', null, '2', '2021-05-18 07:30:00');
INSERT INTO `schedule_job_log` VALUES ('282', '1', 'testTask', 'renren', '0', null, '2', '2021-05-18 08:00:00');
INSERT INTO `schedule_job_log` VALUES ('283', '1', 'testTask', 'renren', '0', null, '0', '2021-05-18 08:30:00');
INSERT INTO `schedule_job_log` VALUES ('284', '1', 'testTask', 'renren', '0', null, '3', '2021-05-24 14:00:00');
INSERT INTO `schedule_job_log` VALUES ('285', '1', 'testTask', 'renren', '0', null, '0', '2021-05-24 15:00:00');
INSERT INTO `schedule_job_log` VALUES ('286', '1', 'testTask', 'renren', '0', null, '1', '2021-05-24 15:30:00');
INSERT INTO `schedule_job_log` VALUES ('287', '1', 'testTask', 'renren', '0', null, '0', '2021-05-24 16:00:00');
INSERT INTO `schedule_job_log` VALUES ('288', '1', 'testTask', 'renren', '0', null, '4', '2021-05-24 16:30:00');
INSERT INTO `schedule_job_log` VALUES ('289', '1', 'testTask', 'renren', '0', null, '2', '2021-05-24 17:00:00');
INSERT INTO `schedule_job_log` VALUES ('290', '1', 'testTask', 'renren', '0', null, '3', '2021-05-24 17:30:00');
INSERT INTO `schedule_job_log` VALUES ('291', '1', 'testTask', 'renren', '0', null, '1', '2021-05-24 18:00:00');
INSERT INTO `schedule_job_log` VALUES ('292', '1', 'testTask', 'renren', '0', null, '3', '2021-05-24 18:30:00');

-- ----------------------------
-- Table structure for sys_captcha
-- ----------------------------
DROP TABLE IF EXISTS `sys_captcha`;
CREATE TABLE `sys_captcha` (
  `uuid` char(36) NOT NULL COMMENT 'uuid',
  `code` varchar(6) NOT NULL COMMENT '验证码',
  `expire_time` datetime DEFAULT NULL COMMENT '过期时间',
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统验证码';

-- ----------------------------
-- Records of sys_captcha
-- ----------------------------
INSERT INTO `sys_captcha` VALUES ('08ede069-bd77-4938-83d6-b32e494bff8a', 'pfy7a', '2021-04-30 15:33:01');
INSERT INTO `sys_captcha` VALUES ('0fba0e92-1997-4cf5-8e9b-13bc208cfda3', '7yn5e', '2021-05-07 12:08:22');
INSERT INTO `sys_captcha` VALUES ('121f2e72-ee49-4a6d-8b78-51320a5bc6c0', '65exy', '2021-04-30 10:56:19');
INSERT INTO `sys_captcha` VALUES ('1befc8c5-5150-4d88-8386-f39597ac0989', '7g7wb', '2021-04-30 15:43:23');
INSERT INTO `sys_captcha` VALUES ('1d5ea87d-b62e-445d-871e-d135e9df7bbb', '86fg2', '2021-05-09 09:14:26');
INSERT INTO `sys_captcha` VALUES ('1f42ebad-5e6c-455a-852e-cbbab7f8d3b6', 'd6dpe', '2021-05-07 12:28:24');
INSERT INTO `sys_captcha` VALUES ('24a0c44e-8de9-4bec-863a-63f7e21561bc', 'bmbfy', '2021-05-09 08:37:45');
INSERT INTO `sys_captcha` VALUES ('2623a34e-f769-4a72-8b1c-1641124214b7', 'd7fn5', '2021-05-24 17:06:06');
INSERT INTO `sys_captcha` VALUES ('268a1029-c361-4a35-8f99-582311253c37', 'naw7d', '2021-05-14 16:01:29');
INSERT INTO `sys_captcha` VALUES ('2ea43d7a-b52f-4109-8188-9c8d0f4d83be', '33f68', '2021-04-30 15:48:05');
INSERT INTO `sys_captcha` VALUES ('3243128f-2afe-444a-8336-37b10b92d8a1', '8w3e6', '2021-05-07 13:36:25');
INSERT INTO `sys_captcha` VALUES ('32fcec71-40bc-40b9-8a11-c6ca856bb3be', 'n5w5n', '2021-05-14 14:21:03');
INSERT INTO `sys_captcha` VALUES ('330f1cf8-8c72-4466-85ac-37156b9cec09', '6ycwd', '2021-04-30 15:33:03');
INSERT INTO `sys_captcha` VALUES ('3486c2e7-fdee-4547-85a8-aa9fbedadc42', 'c647a', '2021-04-30 16:49:38');
INSERT INTO `sys_captcha` VALUES ('349476d5-ba08-4d6d-8ac9-b4dd5501e46a', 'bc8nn', '2021-04-30 15:39:09');
INSERT INTO `sys_captcha` VALUES ('39266324-cca8-4f23-8eaa-1aa274f91046', '6gygp', '2021-05-17 08:50:53');
INSERT INTO `sys_captcha` VALUES ('3a142a19-0e58-40a1-89a5-e9e8599309d1', 'yc7ac', '2021-05-07 13:05:23');
INSERT INTO `sys_captcha` VALUES ('3c3baa41-c496-4787-8a2a-fa879b25bba5', 'eaa6x', '2021-04-30 10:35:10');
INSERT INTO `sys_captcha` VALUES ('3f89be45-6383-4175-8f1a-e4af0563a178', 'n237m', '2021-05-14 14:26:11');
INSERT INTO `sys_captcha` VALUES ('419de9ac-ce2f-42a2-8493-03107d4d3106', 'e7acy', '2021-04-30 17:29:35');
INSERT INTO `sys_captcha` VALUES ('42215433-470f-4607-8924-0c4556d362b6', '5xean', '2021-05-08 09:17:46');
INSERT INTO `sys_captcha` VALUES ('48acad69-1712-4002-86c9-cf201486ef8f', 'xbyd2', '2021-04-30 11:45:53');
INSERT INTO `sys_captcha` VALUES ('4c3e0f06-668c-41d5-8c3e-a80fb9dbcfe1', 'wgfmf', '2021-05-07 13:05:16');
INSERT INTO `sys_captcha` VALUES ('4de871cf-0062-425d-8b99-c7e9873188d5', 'p3wmx', '2021-04-30 15:38:37');
INSERT INTO `sys_captcha` VALUES ('520230ca-68de-47d9-8e3e-ef57f864034c', '3bp56', '2021-04-30 10:51:32');
INSERT INTO `sys_captcha` VALUES ('5217071e-f319-4006-8e77-b427dd242d2b', 'nnwnn', '2021-04-30 13:50:03');
INSERT INTO `sys_captcha` VALUES ('536b3280-beda-49e4-858b-b9d767fb46c7', 'a2647', '2021-04-30 15:15:40');
INSERT INTO `sys_captcha` VALUES ('53ffb202-8c8e-4c6b-874f-dcbc20d8d50a', 'fbdf4', '2021-04-30 10:56:03');
INSERT INTO `sys_captcha` VALUES ('5b0f934b-afaf-4493-84bb-824f4b02c7c9', 'mbn2b', '2021-04-30 16:32:58');
INSERT INTO `sys_captcha` VALUES ('6053074b-4b52-4262-8b22-63bf0639530d', '55p36', '2021-04-30 16:45:08');
INSERT INTO `sys_captcha` VALUES ('606bd448-b65f-4b60-84a6-754b690863fb', 'ne8nb', '2021-04-30 15:43:18');
INSERT INTO `sys_captcha` VALUES ('85e5e3f9-3603-420f-81b1-c84d1b3cda8f', 'xnxdc', '2021-04-30 16:49:39');
INSERT INTO `sys_captcha` VALUES ('8887958f-9e7b-47d2-8278-02bc1f64f959', '7nfdg', '2021-04-29 19:35:32');
INSERT INTO `sys_captcha` VALUES ('8907f551-3df3-49aa-8beb-aa5393adb03e', 'g2mc4', '2021-05-07 12:00:29');
INSERT INTO `sys_captcha` VALUES ('89237fff-6038-46cd-84ce-e3555878e098', 'ff7da', '2021-04-30 15:43:12');
INSERT INTO `sys_captcha` VALUES ('8ec293f3-5660-4d6a-85ce-68a073c23899', '2exfx', '2021-05-07 13:35:42');
INSERT INTO `sys_captcha` VALUES ('8ee30396-6c15-4d3d-8753-e865a3093501', 'nwfn5', '2021-04-30 12:42:11');
INSERT INTO `sys_captcha` VALUES ('90d7b7fe-0f83-4704-869a-f475fd33f093', 'bx4e6', '2021-04-30 15:39:26');
INSERT INTO `sys_captcha` VALUES ('9881934e-9787-4d5b-87ce-7126ee663f59', 'gnp7x', '2021-05-07 10:19:29');
INSERT INTO `sys_captcha` VALUES ('a46bea2a-ef1e-45e7-86bf-a3580187f66b', 'c42ax', '2021-04-30 14:42:43');
INSERT INTO `sys_captcha` VALUES ('a6988f25-126a-42c6-8ad8-c15fa2b11d3d', '6m42y', '2021-05-07 13:05:47');
INSERT INTO `sys_captcha` VALUES ('a72ba056-f97a-4476-83d5-27591cbebb18', 'gabfe', '2021-05-07 12:33:54');
INSERT INTO `sys_captcha` VALUES ('ac00ad14-4c00-4ae2-8f1a-c04f30641c9d', 'np3ex', '2021-04-30 15:15:35');
INSERT INTO `sys_captcha` VALUES ('ac86ac91-b7c8-4e17-8370-956620382d1b', 'm58fa', '2021-04-30 17:29:15');
INSERT INTO `sys_captcha` VALUES ('b8fd2d7e-3037-4c7a-8e8e-c9e5f6055d3a', 'xdnan', '2021-04-30 15:39:06');
INSERT INTO `sys_captcha` VALUES ('c84ec332-9188-4f6c-8022-1b0ae15a7f8f', 'npawx', '2021-04-30 17:32:27');
INSERT INTO `sys_captcha` VALUES ('cc0fa109-d83b-4e1b-8d64-8e2445b2251f', 'f8dbf', '2021-05-07 13:01:38');
INSERT INTO `sys_captcha` VALUES ('d11674e8-d027-44a2-8555-29d1595e02e1', 'y4fy3', '2021-05-17 19:30:30');
INSERT INTO `sys_captcha` VALUES ('d224d8f6-406f-415e-897d-72dd7c2ef56e', 'ff6x8', '2021-05-24 14:36:56');
INSERT INTO `sys_captcha` VALUES ('da9bf6b3-1066-451f-8623-55a0e9ce27d1', 'yyxcf', '2021-05-07 13:01:05');
INSERT INTO `sys_captcha` VALUES ('e3e051d4-dadc-48c4-867c-e984c6145ed4', 'xc5fy', '2021-05-07 13:05:16');
INSERT INTO `sys_captcha` VALUES ('e6ea82c6-5bf7-4678-8ea3-e2532b230e6b', 'f78py', '2021-05-09 08:43:35');
INSERT INTO `sys_captcha` VALUES ('e7257284-9b32-4c7f-8fc7-9710739df13b', 'b26gy', '2021-05-17 08:42:25');
INSERT INTO `sys_captcha` VALUES ('eb1af94c-e0df-48d7-8deb-a1fd57da98ca', '5ye4c', '2021-04-30 15:39:29');
INSERT INTO `sys_captcha` VALUES ('ecf0deb6-f425-4b11-8e63-f366b47c7042', 'mb47m', '2021-04-30 10:56:19');
INSERT INTO `sys_captcha` VALUES ('f0c06646-4d50-4d60-8535-2fa4062cf8a4', '6c6n8', '2021-05-07 13:05:23');
INSERT INTO `sys_captcha` VALUES ('f4484449-e9b8-4653-83a7-fdf9ba8f9d0c', '3ccmx', '2021-05-07 13:35:42');

-- ----------------------------
-- Table structure for sys_config
-- ----------------------------
DROP TABLE IF EXISTS `sys_config`;
CREATE TABLE `sys_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `param_key` varchar(50) DEFAULT NULL COMMENT 'key',
  `param_value` varchar(2000) DEFAULT NULL COMMENT 'value',
  `status` tinyint(4) DEFAULT '1' COMMENT '状态   0：隐藏   1：显示',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `param_key` (`param_key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='系统配置信息表';

-- ----------------------------
-- Records of sys_config
-- ----------------------------
INSERT INTO `sys_config` VALUES ('1', 'CLOUD_STORAGE_CONFIG_KEY', '{\"aliyunAccessKeyId\":\"\",\"aliyunAccessKeySecret\":\"\",\"aliyunBucketName\":\"\",\"aliyunDomain\":\"\",\"aliyunEndPoint\":\"\",\"aliyunPrefix\":\"\",\"qcloudBucketName\":\"\",\"qcloudDomain\":\"\",\"qcloudPrefix\":\"\",\"qcloudSecretId\":\"\",\"qcloudSecretKey\":\"\",\"qiniuAccessKey\":\"NrgMfABZxWLo5B-YYSjoE8-AZ1EISdi1Z3ubLOeZ\",\"qiniuBucketName\":\"ios-app\",\"qiniuDomain\":\"http://7xqbwh.dl1.z0.glb.clouddn.com\",\"qiniuPrefix\":\"upload\",\"qiniuSecretKey\":\"uIwJHevMRWU0VLxFvgy0tAcOdGqasdtVlJkdy6vV\",\"type\":1}', '0', '云存储配置信息');

-- ----------------------------
-- Table structure for sys_log
-- ----------------------------
DROP TABLE IF EXISTS `sys_log`;
CREATE TABLE `sys_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL COMMENT '用户名',
  `operation` varchar(50) DEFAULT NULL COMMENT '用户操作',
  `method` varchar(200) DEFAULT NULL COMMENT '请求方法',
  `params` varchar(5000) DEFAULT NULL COMMENT '请求参数',
  `time` bigint(20) NOT NULL COMMENT '执行时长(毫秒)',
  `ip` varchar(64) DEFAULT NULL COMMENT 'IP地址',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8mb4 COMMENT='系统日志';

-- ----------------------------
-- Records of sys_log
-- ----------------------------
INSERT INTO `sys_log` VALUES ('1', 'admin', '保存菜单', 'io.renren.modules.sys.controller.SysMenuController.save()', '[{\"menuId\":31,\"parentId\":0,\"name\":\"用户管理\",\"url\":\"\",\"perms\":\"\",\"type\":0,\"icon\":\"admin\",\"orderNum\":0}]', '11', '0:0:0:0:0:0:0:1', '2021-04-29 16:12:13');
INSERT INTO `sys_log` VALUES ('2', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":31,\"parentId\":0,\"name\":\"颐养中心管理\",\"url\":\"\",\"perms\":\"\",\"type\":0,\"icon\":\"admin\",\"orderNum\":0}]', '16', '0:0:0:0:0:0:0:1', '2021-04-29 16:15:02');
INSERT INTO `sys_log` VALUES ('3', 'admin', '保存菜单', 'io.renren.modules.sys.controller.SysMenuController.save()', '[{\"menuId\":32,\"parentId\":31,\"name\":\"用户管理\",\"url\":\"user/info\",\"perms\":\"user:list\",\"type\":1,\"icon\":\"log\",\"orderNum\":0}]', '8', '0:0:0:0:0:0:0:1', '2021-04-29 16:16:07');
INSERT INTO `sys_log` VALUES ('4', 'admin', '保存菜单', 'io.renren.modules.sys.controller.SysMenuController.save()', '[{\"menuId\":34,\"parentId\":0,\"name\":\"膳食管理\",\"url\":\"\",\"perms\":\"\",\"type\":0,\"icon\":\"zonghe\",\"orderNum\":0}]', '8', '0:0:0:0:0:0:0:1', '2021-04-29 19:31:55');
INSERT INTO `sys_log` VALUES ('5', 'admin', '保存菜单', 'io.renren.modules.sys.controller.SysMenuController.save()', '[{\"menuId\":33,\"parentId\":0,\"name\":\"膳食管理\",\"url\":\"\",\"perms\":\"\",\"type\":0,\"icon\":\"zonghe\",\"orderNum\":0}]', '7', '0:0:0:0:0:0:0:1', '2021-04-29 19:31:55');
INSERT INTO `sys_log` VALUES ('6', 'admin', '删除菜单', 'io.renren.modules.sys.controller.SysMenuController.delete()', '[33]', '16', '0:0:0:0:0:0:0:1', '2021-04-29 19:32:12');
INSERT INTO `sys_log` VALUES ('7', 'admin', '保存菜单', 'io.renren.modules.sys.controller.SysMenuController.save()', '[{\"menuId\":35,\"parentId\":34,\"name\":\"饮食菜单\",\"url\":\"ysmenu/ysfoodmenu\",\"perms\":\"ysmenu:ysfoodmenu:list\",\"type\":1,\"icon\":\"menu\",\"orderNum\":0}]', '8', '0:0:0:0:0:0:0:1', '2021-04-29 19:33:34');
INSERT INTO `sys_log` VALUES ('8', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":35,\"parentId\":34,\"name\":\"饮食菜单\",\"url\":\"ysmenu/ysfoodmenu\",\"perms\":\"ysmenu:ysfoodmenu:list,ysmenu:ysfoodmenu:save\",\"type\":1,\"icon\":\"menu\",\"orderNum\":0}]', '10', '0:0:0:0:0:0:0:1', '2021-04-29 19:44:40');
INSERT INTO `sys_log` VALUES ('9', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":35,\"parentId\":34,\"name\":\"饮食菜单\",\"url\":\"ysmenu/ysfoodmenu\",\"perms\":\"ysmenu:ysfoodmenu:list,ysmenu:ysfoodmenu:save,ysmenu:ysfoodmenu:delete,ysmenu:ysfoodmenu:update\",\"type\":1,\"icon\":\"menu\",\"orderNum\":0}]', '9', '0:0:0:0:0:0:0:1', '2021-04-30 10:27:45');
INSERT INTO `sys_log` VALUES ('10', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":35,\"parentId\":34,\"name\":\"饮食菜单\",\"url\":\"ysmenu/ysfoodmenu\",\"perms\":\"ysmenu:ysfoodmenu:list,ysmenu:ysfoodmenu:save,ysmenu:ysfoodmenu:delete,ysmenu:ysfoodmenu:update,ysmenu:ysfoodmenu:info\",\"type\":1,\"icon\":\"menu\",\"orderNum\":0}]', '10', '0:0:0:0:0:0:0:1', '2021-04-30 10:48:45');
INSERT INTO `sys_log` VALUES ('11', 'admin', '保存菜单', 'io.renren.modules.sys.controller.SysMenuController.save()', '[{\"menuId\":66,\"parentId\":0,\"name\":\"信息管理\",\"url\":\"\",\"perms\":\"\",\"type\":0,\"icon\":\"config\",\"orderNum\":0}]', '8', '0:0:0:0:0:0:0:1', '2021-04-30 14:16:20');
INSERT INTO `sys_log` VALUES ('12', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":36,\"parentId\":66,\"name\":\"入住登记\",\"url\":\"customer/infocheckin\",\"perms\":\"customer:infocheckin:list,customer:infocheckin:info,customer:infocheckin:delete,customer:infocheckin:update,customer:infocheckin:save\",\"type\":1,\"icon\":\"config\",\"orderNum\":6}]', '9', '0:0:0:0:0:0:0:1', '2021-04-30 14:20:54');
INSERT INTO `sys_log` VALUES ('13', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":36,\"parentId\":66,\"name\":\"入住登记\",\"url\":\"customer/infocheckin\",\"perms\":\"customer:infocheckin:list,customer:infocheckin:info,customer:infocheckin:delete,customer:infocheckin:update,customer:infocheckin:save\",\"type\":1,\"icon\":\"config\",\"orderNum\":6}]', '10', '0:0:0:0:0:0:0:1', '2021-04-30 14:23:58');
INSERT INTO `sys_log` VALUES ('14', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":41,\"parentId\":66,\"name\":\"退住登记\",\"url\":\"customer/infocheckout\",\"perms\":\"customer:infocheckout:list,customer:infocheckout:info,customer:infocheckout:delete,customer:infocheckout:update,customer:infocheckout:save\",\"type\":1,\"icon\":\"config\",\"orderNum\":6}]', '8', '0:0:0:0:0:0:0:1', '2021-04-30 14:25:02');
INSERT INTO `sys_log` VALUES ('15', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":46,\"parentId\":66,\"name\":\"客户档案\",\"url\":\"customer/infocusomerrecords\",\"perms\":\"customer:infocusomerrecords:list,customer:infocusomerrecords:info,customer:infocusomerrecords:update,customer:infocusomerrecords:save,customer:infocusomerrecords:delete\",\"type\":1,\"icon\":\"config\",\"orderNum\":6}]', '8', '0:0:0:0:0:0:0:1', '2021-04-30 14:25:45');
INSERT INTO `sys_log` VALUES ('16', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":51,\"parentId\":66,\"name\":\"联系簿\",\"url\":\"customer/infofamilyrecords\",\"perms\":\"customer:infofamilyrecords:list,customer:infofamilyrecords:info,customer:infofamilyrecords:delete,customer:infofamilyrecords:update,customer:infofamilyrecords:save\",\"type\":1,\"icon\":\"config\",\"orderNum\":6}]', '6', '0:0:0:0:0:0:0:1', '2021-04-30 14:26:29');
INSERT INTO `sys_log` VALUES ('17', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":56,\"parentId\":66,\"name\":\"外来登记\",\"url\":\"customer/infootherrecords\",\"perms\":\"customer:infootherrecords:list,customer:infootherrecords:save,customer:infootherrecords:update,customer:infootherrecords:info,customer:infootherrecords:delete\",\"type\":1,\"icon\":\"config\",\"orderNum\":6}]', '8', '0:0:0:0:0:0:0:1', '2021-04-30 14:27:10');
INSERT INTO `sys_log` VALUES ('18', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":61,\"parentId\":66,\"name\":\"外出登记\",\"url\":\"customer/infooutrecords\",\"perms\":\"customer:infooutrecords:list,customer:infooutrecords:info,customer:infooutrecords:save,customer:infooutrecords:update,customer:infooutrecords:delete\",\"type\":1,\"icon\":\"config\",\"orderNum\":6}]', '6', '0:0:0:0:0:0:0:1', '2021-04-30 14:28:03');
INSERT INTO `sys_log` VALUES ('19', 'admin', '保存菜单', 'io.renren.modules.sys.controller.SysMenuController.save()', '[{\"menuId\":67,\"parentId\":0,\"name\":\"后勤管理\",\"url\":\"\",\"perms\":\"\",\"type\":0,\"icon\":\"tixing\",\"orderNum\":0}]', '9', '127.0.0.1', '2021-04-30 15:35:42');
INSERT INTO `sys_log` VALUES ('20', 'admin', '保存用户', 'io.renren.modules.sys.controller.SysUserController.save()', '[{\"userId\":2,\"username\":\"a\",\"password\":\"19580e45cf3afb4090cbc15c640d29dcc54dcdd7f50de9aeca2b577deecedece\",\"salt\":\"CKDaBnrxf54oyaHEXJnX\",\"email\":\"1623637010@qq.com\",\"mobile\":\"18144625235\",\"status\":1,\"roleIdList\":[],\"createUserId\":1,\"createTime\":\"Apr 30, 2021 2:38:35 PM\"}]', '256', '0:0:0:0:0:0:0:1', '2021-04-30 14:38:35');
INSERT INTO `sys_log` VALUES ('21', 'admin', '保存角色', 'io.renren.modules.sys.controller.SysRoleController.save()', '[{\"roleId\":1,\"roleName\":\"all\",\"remark\":\"\",\"createUserId\":1,\"menuIdList\":[1,2,15,16,17,18,3,19,20,21,22,4,23,24,25,26,5,6,7,8,9,10,11,12,13,14,27,29,30,31,32,34,35,66,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,67,-666666],\"createTime\":\"Apr 30, 2021 2:39:37 PM\"}]', '57', '0:0:0:0:0:0:0:1', '2021-04-30 14:39:37');
INSERT INTO `sys_log` VALUES ('22', 'admin', '修改角色', 'io.renren.modules.sys.controller.SysRoleController.update()', '[{\"roleId\":1,\"roleName\":\"all\",\"remark\":\"\",\"createUserId\":1,\"menuIdList\":[1,2,15,16,17,18,3,19,20,21,22,4,23,24,25,26,5,6,7,8,9,10,11,12,13,14,27,29,30,31,32,34,35,66,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,67,-666666]}]', '71', '0:0:0:0:0:0:0:1', '2021-04-30 14:39:45');
INSERT INTO `sys_log` VALUES ('23', 'admin', '修改用户', 'io.renren.modules.sys.controller.SysUserController.update()', '[{\"userId\":2,\"username\":\"a\",\"salt\":\"CKDaBnrxf54oyaHEXJnX\",\"email\":\"1623637010@qq.com\",\"mobile\":\"18144625235\",\"status\":1,\"roleIdList\":[1],\"createUserId\":1}]', '12', '0:0:0:0:0:0:0:1', '2021-04-30 14:39:52');
INSERT INTO `sys_log` VALUES ('24', 'admin', '保存用户', 'io.renren.modules.sys.controller.SysUserController.save()', '[{\"userId\":3,\"username\":\"b\",\"password\":\"ad0722f032be2ea937b4c86a503a2ad09625fa30b36890ba89bbc5f66db24e98\",\"salt\":\"p66Cfhhw5WCxZJS6CtFD\",\"email\":\"12312312@qq.com\",\"mobile\":\"18145642051\",\"status\":1,\"roleIdList\":[1],\"createUserId\":1,\"createTime\":\"Apr 30, 2021 2:40:41 PM\"}]', '15', '0:0:0:0:0:0:0:1', '2021-04-30 14:40:42');
INSERT INTO `sys_log` VALUES ('25', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":36,\"parentId\":66,\"name\":\"入住登记\",\"url\":\"customer/infocheckin\",\"perms\":\"customer:infocheckin:list,customer:infocheckin:info,customer:infocheckin:update,customer:infocheckin:save,customer:infocheckin:delete\",\"type\":1,\"icon\":\"config\",\"orderNum\":0}]', '8', '0:0:0:0:0:0:0:1', '2021-04-30 14:41:22');
INSERT INTO `sys_log` VALUES ('26', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":30,\"parentId\":1,\"name\":\"文件上传\",\"url\":\"oss/oss\",\"perms\":\"sys:oss:all\",\"type\":1,\"icon\":\"oss\",\"orderNum\":8}]', '7', '0:0:0:0:0:0:0:1', '2021-04-30 14:42:02');
INSERT INTO `sys_log` VALUES ('27', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":36,\"parentId\":66,\"name\":\"入住登记\",\"url\":\"customer/infocheckin\",\"perms\":\"customer:infocheckin:list,customer:infocheckin:info,customer:infocheckin:update,customer:infocheckin:save,customer:infocheckin:delete\",\"type\":1,\"icon\":\"config\",\"orderNum\":1}]', '9', '0:0:0:0:0:0:0:1', '2021-04-30 14:42:19');
INSERT INTO `sys_log` VALUES ('28', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":41,\"parentId\":66,\"name\":\"退住登记\",\"url\":\"customer/infocheckout\",\"perms\":\"customer:infocheckout:list,customer:infocheckout:info,customer:infocheckout:delete,customer:infocheckout:update,customer:infocheckout:save\",\"type\":1,\"icon\":\"config\",\"orderNum\":2}]', '7', '0:0:0:0:0:0:0:1', '2021-04-30 14:42:28');
INSERT INTO `sys_log` VALUES ('29', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":46,\"parentId\":66,\"name\":\"客户档案\",\"url\":\"customer/infocusomerrecords\",\"perms\":\"customer:infocusomerrecords:list,customer:infocusomerrecords:info,customer:infocusomerrecords:update,customer:infocusomerrecords:save,customer:infocusomerrecords:delete\",\"type\":1,\"icon\":\"config\",\"orderNum\":3}]', '7', '0:0:0:0:0:0:0:1', '2021-04-30 14:42:36');
INSERT INTO `sys_log` VALUES ('30', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":51,\"parentId\":66,\"name\":\"联系簿\",\"url\":\"customer/infofamilyrecords\",\"perms\":\"customer:infofamilyrecords:list,customer:infofamilyrecords:info,customer:infofamilyrecords:delete,customer:infofamilyrecords:update,customer:infofamilyrecords:save\",\"type\":1,\"icon\":\"config\",\"orderNum\":4}]', '9', '0:0:0:0:0:0:0:1', '2021-04-30 14:42:45');
INSERT INTO `sys_log` VALUES ('31', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":56,\"parentId\":66,\"name\":\"外来登记\",\"url\":\"customer/infootherrecords\",\"perms\":\"customer:infootherrecords:list,customer:infootherrecords:save,customer:infootherrecords:update,customer:infootherrecords:info,customer:infootherrecords:delete\",\"type\":1,\"icon\":\"config\",\"orderNum\":5}]', '7', '0:0:0:0:0:0:0:1', '2021-04-30 14:42:54');
INSERT INTO `sys_log` VALUES ('32', 'b', '保存菜单', 'io.renren.modules.sys.controller.SysMenuController.save()', '[{\"menuId\":68,\"parentId\":0,\"name\":\"房间管理\",\"url\":\"\",\"perms\":\"\",\"type\":0,\"icon\":\"shouye\",\"orderNum\":0}]', '10', '0:0:0:0:0:0:0:1', '2021-04-30 14:46:16');
INSERT INTO `sys_log` VALUES ('33', 'admin', '删除菜单', 'io.renren.modules.sys.controller.SysMenuController.delete()', '[47]', '15', '0:0:0:0:0:0:0:1', '2021-04-30 14:46:47');
INSERT INTO `sys_log` VALUES ('34', 'admin', '删除菜单', 'io.renren.modules.sys.controller.SysMenuController.delete()', '[48]', '13', '0:0:0:0:0:0:0:1', '2021-04-30 14:47:03');
INSERT INTO `sys_log` VALUES ('35', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":46,\"parentId\":66,\"name\":\"客户档案\",\"url\":\"customer/infocusomerrecords\",\"perms\":\"customer:infocusomerrecords:list,customer:infocusomerrecords:info\",\"type\":1,\"icon\":\"config\",\"orderNum\":3}]', '11', '0:0:0:0:0:0:0:1', '2021-04-30 14:48:24');
INSERT INTO `sys_log` VALUES ('36', 'b', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":68,\"parentId\":0,\"name\":\"房间管理\",\"url\":\"\",\"perms\":\"\",\"type\":0,\"icon\":\"suoding\",\"orderNum\":0}]', '8', '0:0:0:0:0:0:0:1', '2021-04-30 14:54:31');
INSERT INTO `sys_log` VALUES ('37', 'admin', '修改角色', 'io.renren.modules.sys.controller.SysRoleController.update()', '[{\"roleId\":1,\"roleName\":\"all\",\"remark\":\"\",\"createUserId\":1,\"menuIdList\":[1,2,15,16,17,18,3,19,20,21,22,4,23,24,25,26,5,6,7,8,9,10,11,12,13,14,27,29,30,31,32,34,35,66,36,37,38,39,40,41,42,43,44,45,46,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,67,68,-666666]}]', '101', '0:0:0:0:0:0:0:1', '2021-04-30 15:04:22');
INSERT INTO `sys_log` VALUES ('38', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":41,\"parentId\":66,\"name\":\"退住登记\",\"url\":\"customer/infocheckout\",\"perms\":\"\",\"type\":1,\"icon\":\"config\",\"orderNum\":2}]', '9', '0:0:0:0:0:0:0:1', '2021-04-30 15:04:56');
INSERT INTO `sys_log` VALUES ('39', 'b', '保存菜单', 'io.renren.modules.sys.controller.SysMenuController.save()', '[{\"menuId\":69,\"parentId\":68,\"name\":\"床位管理\",\"url\":\"\",\"perms\":\"\",\"type\":0,\"icon\":\"shouye\",\"orderNum\":0}]', '11', '0:0:0:0:0:0:0:1', '2021-04-30 15:32:10');
INSERT INTO `sys_log` VALUES ('40', 'admin', '修改角色', 'io.renren.modules.sys.controller.SysRoleController.update()', '[{\"roleId\":1,\"roleName\":\"all\",\"remark\":\"\",\"createUserId\":1,\"menuIdList\":[1,2,15,16,17,18,3,19,20,21,22,4,23,24,25,26,5,6,7,8,9,10,11,12,13,14,27,29,30,31,32,34,35,66,36,37,38,39,40,41,42,43,44,45,46,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,67,68,69,-666666]}]', '134', '0:0:0:0:0:0:0:1', '2021-04-30 15:33:27');
INSERT INTO `sys_log` VALUES ('41', 'admin', '修改用户', 'io.renren.modules.sys.controller.SysUserController.update()', '[{\"userId\":1,\"username\":\"admin\",\"password\":\"0d346fb1d43a4d9e8c4fcbf2431d6d38f980148de7ffd9f2672a65afa8e3bcb0\",\"salt\":\"YzcmCZNvbXocrsz9dm8e\",\"email\":\"root@renren.io\",\"mobile\":\"13612345678\",\"status\":1,\"roleIdList\":[],\"createUserId\":1}]', '26', '0:0:0:0:0:0:0:1', '2021-04-30 15:37:00');
INSERT INTO `sys_log` VALUES ('42', 'admin', '修改用户', 'io.renren.modules.sys.controller.SysUserController.update()', '[{\"userId\":2,\"username\":\"wsj\",\"password\":\"2a17de705ed33ad229767b67d75479ade0310665f7ce9282988663ef4e27b426\",\"salt\":\"CKDaBnrxf54oyaHEXJnX\",\"email\":\"1623637010@qq.com\",\"mobile\":\"18144625235\",\"status\":1,\"roleIdList\":[1],\"createUserId\":1}]', '14', '0:0:0:0:0:0:0:1', '2021-04-30 15:37:27');
INSERT INTO `sys_log` VALUES ('43', 'admin', '修改用户', 'io.renren.modules.sys.controller.SysUserController.update()', '[{\"userId\":3,\"username\":\"jfy\",\"password\":\"7c796a2345fe1d72ddb6d2d2f367ff456523561601c1d79016f54262513a4ebe\",\"salt\":\"p66Cfhhw5WCxZJS6CtFD\",\"email\":\"12312312@qq.com\",\"mobile\":\"18145642051\",\"status\":1,\"roleIdList\":[1],\"createUserId\":1}]', '22', '0:0:0:0:0:0:0:1', '2021-04-30 15:37:38');
INSERT INTO `sys_log` VALUES ('44', 'admin', '修改用户', 'io.renren.modules.sys.controller.SysUserController.update()', '[{\"userId\":4,\"username\":\"lyf\",\"salt\":\"p66Cfhhw5WCxZJS6CtFD\",\"email\":\"12312312@qq.com\",\"mobile\":\"18145642052\",\"status\":1,\"roleIdList\":[1],\"createUserId\":1}]', '19', '0:0:0:0:0:0:0:1', '2021-04-30 15:38:13');
INSERT INTO `sys_log` VALUES ('45', 'admin', '修改用户', 'io.renren.modules.sys.controller.SysUserController.update()', '[{\"userId\":5,\"username\":\"xwj\",\"salt\":\"p66Cfhhw5WCxZJS6CtFD\",\"email\":\"12312312@qq.com\",\"mobile\":\"18145642053\",\"status\":1,\"roleIdList\":[1],\"createUserId\":1}]', '16', '0:0:0:0:0:0:0:1', '2021-04-30 15:38:37');
INSERT INTO `sys_log` VALUES ('46', 'admin', '修改用户', 'io.renren.modules.sys.controller.SysUserController.update()', '[{\"userId\":6,\"username\":\"lxh\",\"salt\":\"p66Cfhhw5WCxZJS6CtFD\",\"email\":\"12312312@qq.com\",\"mobile\":\"18145642054\",\"status\":1,\"roleIdList\":[1],\"createUserId\":1}]', '8', '0:0:0:0:0:0:0:1', '2021-04-30 15:38:50');
INSERT INTO `sys_log` VALUES ('47', 'admin', '修改用户', 'io.renren.modules.sys.controller.SysUserController.update()', '[{\"userId\":7,\"username\":\"cxj\",\"salt\":\"p66Cfhhw5WCxZJS6CtFD\",\"email\":\"12312312@qq.com\",\"mobile\":\"18145642055\",\"status\":1,\"roleIdList\":[1],\"createUserId\":1}]', '13', '0:0:0:0:0:0:0:1', '2021-04-30 15:38:55');
INSERT INTO `sys_log` VALUES ('48', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":34,\"parentId\":0,\"name\":\"膳食管理\",\"url\":\"\",\"perms\":\"\",\"type\":0,\"icon\":\"zonghe\",\"orderNum\":1}]', '6', '0:0:0:0:0:0:0:1', '2021-04-30 15:41:52');
INSERT INTO `sys_log` VALUES ('49', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":31,\"parentId\":0,\"name\":\"颐养中心管理\",\"url\":\"\",\"perms\":\"\",\"type\":0,\"icon\":\"admin\",\"orderNum\":2}]', '12', '0:0:0:0:0:0:0:1', '2021-04-30 15:42:02');
INSERT INTO `sys_log` VALUES ('50', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":31,\"parentId\":0,\"name\":\"颐养中心管理\",\"url\":\"\",\"perms\":\"\",\"type\":0,\"icon\":\"admin\",\"orderNum\":11}]', '4', '0:0:0:0:0:0:0:1', '2021-04-30 15:42:25');
INSERT INTO `sys_log` VALUES ('51', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":67,\"parentId\":0,\"name\":\"后勤管理\",\"url\":\"\",\"perms\":\"\",\"type\":0,\"icon\":\"tixing\",\"orderNum\":2}]', '7', '0:0:0:0:0:0:0:1', '2021-04-30 15:42:38');
INSERT INTO `sys_log` VALUES ('52', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":68,\"parentId\":0,\"name\":\"房间管理\",\"url\":\"\",\"perms\":\"\",\"type\":0,\"icon\":\"suoding\",\"orderNum\":3}]', '8', '0:0:0:0:0:0:0:1', '2021-04-30 15:42:47');
INSERT INTO `sys_log` VALUES ('53', 'jfy', '保存菜单', 'io.renren.modules.sys.controller.SysMenuController.save()', '[{\"menuId\":70,\"parentId\":67,\"name\":\"设备维修\",\"url\":\"houqin/hqservice\",\"perms\":\"\",\"type\":1,\"icon\":\"system\",\"orderNum\":0}]', '9', '127.0.0.1', '2021-04-30 16:45:20');
INSERT INTO `sys_log` VALUES ('54', 'jfy', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":70,\"parentId\":67,\"name\":\"设备维修\",\"url\":\"houqin/hqservice\",\"perms\":\"\",\"type\":1,\"icon\":\"config\",\"orderNum\":0}]', '11', '127.0.0.1', '2021-04-30 16:49:48');
INSERT INTO `sys_log` VALUES ('55', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":46,\"parentId\":66,\"name\":\"客户档案\",\"url\":\"customer/infocusomerrecords\",\"perms\":\"customer:infocusomerrecords:list,customer:infocusomerrecords:info,customer:infocusomerrecords:save,customer:infocusomerrecords:update,customer:infocusomerrecords:delete\",\"type\":1,\"icon\":\"config\",\"orderNum\":3}]', '6', '0:0:0:0:0:0:0:1', '2021-04-30 17:20:31');
INSERT INTO `sys_log` VALUES ('56', 'jfy', '保存菜单', 'io.renren.modules.sys.controller.SysMenuController.save()', '[{\"menuId\":71,\"parentId\":67,\"name\":\"设备采购\",\"url\":\"\",\"perms\":\"\",\"type\":0,\"icon\":\"bianji\",\"orderNum\":0}]', '11', '127.0.0.1', '2021-05-06 12:08:00');
INSERT INTO `sys_log` VALUES ('57', 'jfy', '删除菜单', 'io.renren.modules.sys.controller.SysMenuController.delete()', '[71]', '23', '127.0.0.1', '2021-05-06 12:09:02');
INSERT INTO `sys_log` VALUES ('58', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":46,\"parentId\":66,\"name\":\"客户档案\",\"url\":\"customer/infocusomerrecords\",\"perms\":\"customer:infocusomerrecords:all\",\"type\":1,\"icon\":\"config\",\"orderNum\":3}]', '7', '0:0:0:0:0:0:0:1', '2021-05-06 14:02:57');
INSERT INTO `sys_log` VALUES ('59', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":46,\"parentId\":66,\"name\":\"客户档案\",\"url\":\"customer/infocusomerrecords\",\"perms\":\"customer:infocusomerrecords:list,customer:infocusomerrecords:info,customer:infocusomerrecords:save,customer:infocusomerrecords:update,customer:infocusomerrecords:delete\",\"type\":1,\"icon\":\"config\",\"orderNum\":3}]', '8', '0:0:0:0:0:0:0:1', '2021-05-06 14:03:23');
INSERT INTO `sys_log` VALUES ('60', 'jfy', '删除菜单', 'io.renren.modules.sys.controller.SysMenuController.delete()', '[70]', '26', '127.0.0.1', '2021-05-06 15:18:10');
INSERT INTO `sys_log` VALUES ('61', 'wsj', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":68,\"parentId\":0,\"name\":\"床位管理\",\"url\":\"\",\"perms\":\"\",\"type\":0,\"icon\":\"suoding\",\"orderNum\":3}]', '13', '0:0:0:0:0:0:0:1', '2021-05-06 14:56:11');
INSERT INTO `sys_log` VALUES ('62', 'wsj', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":69,\"parentId\":68,\"name\":\"房间管理\",\"url\":\"cw/cwbed\",\"perms\":\"\",\"type\":1,\"icon\":\"shouye\",\"orderNum\":0}]', '14', '0:0:0:0:0:0:0:1', '2021-05-06 14:56:41');
INSERT INTO `sys_log` VALUES ('63', 'wsj', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":69,\"parentId\":68,\"name\":\"房间管理\",\"url\":\"cw/cwroom\",\"perms\":\"cw:cwroom:list,cw:cwroom:info,cw:cwroom:save,cw:cwroom:update,cw:cwroom:delete\",\"type\":1,\"icon\":\"shouye\",\"orderNum\":0}]', '10', '0:0:0:0:0:0:0:1', '2021-05-06 14:58:21');
INSERT INTO `sys_log` VALUES ('64', 'wsj', '保存菜单', 'io.renren.modules.sys.controller.SysMenuController.save()', '[{\"menuId\":77,\"parentId\":68,\"name\":\"床位管理\",\"url\":\"cw/cwbed\",\"perms\":\"cw:cwbed:list,cw:cwbed:info,cw:cwbed:save,cw:cwbed:update,cw:cwbed:delete\",\"type\":1,\"icon\":\"log\",\"orderNum\":0}]', '14', '0:0:0:0:0:0:0:1', '2021-05-06 15:03:32');
INSERT INTO `sys_log` VALUES ('65', 'admin', '修改角色', 'io.renren.modules.sys.controller.SysRoleController.update()', '[{\"roleId\":1,\"roleName\":\"all\",\"remark\":\"\",\"createUserId\":1,\"menuIdList\":[1,2,15,16,17,18,3,19,20,21,22,4,23,24,25,26,5,6,7,8,9,10,11,12,13,14,27,29,30,31,32,34,35,66,36,37,38,39,40,41,42,43,44,45,46,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,67,72,73,74,75,76,68,69,77,-666666]}]', '255', '0:0:0:0:0:0:0:1', '2021-05-06 15:09:28');
INSERT INTO `sys_log` VALUES ('66', 'jfy', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":72,\"parentId\":67,\"name\":\"设备采购\",\"url\":\"houqin/hqbuy\",\"type\":1,\"icon\":\"bianji\",\"orderNum\":6}]', '13', '127.0.0.1', '2021-05-06 16:58:08');
INSERT INTO `sys_log` VALUES ('67', 'jfy', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":78,\"parentId\":67,\"name\":\"设备维修\",\"url\":\"houqin/hqservice\",\"type\":1,\"icon\":\"system\",\"orderNum\":6}]', '11', '127.0.0.1', '2021-05-06 16:58:42');
INSERT INTO `sys_log` VALUES ('68', 'jfy', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":83,\"parentId\":67,\"name\":\"床铺清洁\",\"url\":\"houqin/hqclean\",\"type\":1,\"icon\":\"mudedi\",\"orderNum\":6}]', '10', '127.0.0.1', '2021-05-06 16:42:00');
INSERT INTO `sys_log` VALUES ('69', 'admin', '修改角色', 'io.renren.modules.sys.controller.SysRoleController.update()', '[{\"roleId\":1,\"roleName\":\"all\",\"remark\":\"\",\"createUserId\":1,\"menuIdList\":[1,2,15,16,17,18,3,19,20,21,22,4,23,24,25,26,5,6,7,8,9,10,11,12,13,14,27,29,30,31,32,34,35,66,36,37,38,39,40,41,42,43,44,45,46,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,67,72,73,74,75,76,78,79,80,81,82,83,84,85,86,87,68,69,77,-666666]}]', '315', '0:0:0:0:0:0:0:1', '2021-05-07 10:15:48');
INSERT INTO `sys_log` VALUES ('70', 'jfy', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":83,\"parentId\":67,\"name\":\"床铺清洁\",\"url\":\"houqin/hqclean\",\"type\":1,\"icon\":\"xiangqufill\",\"orderNum\":6}]', '11', '127.0.0.1', '2021-05-07 10:59:50');
INSERT INTO `sys_log` VALUES ('71', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":108,\"parentId\":0,\"name\":\"费用管理\",\"url\":\"\",\"perms\":\"\",\"type\":0,\"icon\":\"zonghe\",\"orderNum\":5}]', '9', '0:0:0:0:0:0:0:1', '2021-05-07 11:15:58');
INSERT INTO `sys_log` VALUES ('72', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":109,\"parentId\":0,\"name\":\"护理管理\",\"url\":\"\",\"perms\":\"\",\"type\":0,\"icon\":\"zonghe\",\"orderNum\":4}]', '4', '0:0:0:0:0:0:0:1', '2021-05-07 11:16:04');
INSERT INTO `sys_log` VALUES ('73', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":109,\"parentId\":0,\"name\":\"护理管理\",\"url\":\"\",\"perms\":\"\",\"type\":0,\"icon\":\"zonghe\",\"orderNum\":2}]', '7', '0:0:0:0:0:0:0:1', '2021-05-07 11:16:45');
INSERT INTO `sys_log` VALUES ('74', 'jfy', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":83,\"parentId\":67,\"name\":\"床铺清洁\",\"url\":\"houqin/hqclean\",\"type\":1,\"icon\":\"job\",\"orderNum\":6}]', '9', '127.0.0.1', '2021-05-07 11:17:14');
INSERT INTO `sys_log` VALUES ('75', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":67,\"parentId\":0,\"name\":\"后勤管理\",\"url\":\"\",\"perms\":\"\",\"type\":0,\"icon\":\"tixing\",\"orderNum\":4}]', '7', '0:0:0:0:0:0:0:1', '2021-05-07 11:16:51');
INSERT INTO `sys_log` VALUES ('76', 'admin', '修改角色', 'io.renren.modules.sys.controller.SysRoleController.update()', '[{\"roleId\":1,\"roleName\":\"all\",\"remark\":\"\",\"createUserId\":1,\"menuIdList\":[1,2,15,16,17,18,3,19,20,21,22,4,23,24,25,26,5,6,7,8,9,10,11,12,13,14,27,29,30,31,32,34,35,88,89,90,91,92,93,94,95,96,97,66,36,37,38,39,40,41,42,43,44,45,46,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,67,72,73,74,75,76,78,79,80,81,82,83,84,85,86,87,68,69,77,108,98,99,100,101,102,103,104,105,106,107,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,-666666]}]', '192', '0:0:0:0:0:0:0:1', '2021-05-07 11:17:43');
INSERT INTO `sys_log` VALUES ('77', 'admin', '修改用户', 'io.renren.modules.sys.controller.SysUserController.update()', '[{\"userId\":5,\"username\":\"xwj\",\"password\":\"15925fd011388bbac240c94aa12477f4884d3a48296fa46b55d97438dae1931a\",\"salt\":\"p66Cfhhw5WCxZJS6CtFD\",\"email\":\"12312312@qq.com\",\"mobile\":\"18145642053\",\"status\":1,\"roleIdList\":[1],\"createUserId\":1}]', '92', '0:0:0:0:0:0:0:1', '2021-05-07 12:01:04');
INSERT INTO `sys_log` VALUES ('78', 'admin', '修改用户', 'io.renren.modules.sys.controller.SysUserController.update()', '[{\"userId\":4,\"username\":\"lyf\",\"password\":\"c5ea9ec499157c6da8b6950757136f1c202d390dfec95f9a174c7cb1c8fd3a8f\",\"salt\":\"p66Cfhhw5WCxZJS6CtFD\",\"email\":\"12312312@qq.com\",\"mobile\":\"18145642052\",\"status\":1,\"roleIdList\":[1],\"createUserId\":1}]', '17', '0:0:0:0:0:0:0:1', '2021-05-07 12:08:48');
INSERT INTO `sys_log` VALUES ('79', 'admin', '修改用户', 'io.renren.modules.sys.controller.SysUserController.update()', '[{\"userId\":6,\"username\":\"lxh\",\"password\":\"1ee8af8df4d01646a413a02507c4b497de59f0ffcca75e09ada1f8f096994f67\",\"salt\":\"p66Cfhhw5WCxZJS6CtFD\",\"email\":\"12312312@qq.com\",\"mobile\":\"18145642054\",\"status\":1,\"roleIdList\":[1],\"createUserId\":1}]', '12', '0:0:0:0:0:0:0:1', '2021-05-07 12:08:59');
INSERT INTO `sys_log` VALUES ('80', 'admin', '修改用户', 'io.renren.modules.sys.controller.SysUserController.update()', '[{\"userId\":7,\"username\":\"cxj\",\"password\":\"cd8b6ad2f8ff53f2f8f66bb3c961277b85e32d8ccf342ff030b49e729d55f57c\",\"salt\":\"p66Cfhhw5WCxZJS6CtFD\",\"email\":\"12312312@qq.com\",\"mobile\":\"18145642055\",\"status\":1,\"roleIdList\":[1],\"createUserId\":1}]', '16', '0:0:0:0:0:0:0:1', '2021-05-07 12:09:08');
INSERT INTO `sys_log` VALUES ('81', 'admin', '修改用户', 'io.renren.modules.sys.controller.SysUserController.update()', '[{\"userId\":3,\"username\":\"jfy\",\"password\":\"7c796a2345fe1d72ddb6d2d2f367ff456523561601c1d79016f54262513a4ebe\",\"salt\":\"p66Cfhhw5WCxZJS6CtFD\",\"email\":\"12312312@qq.com\",\"mobile\":\"18145642051\",\"status\":1,\"roleIdList\":[1],\"createUserId\":1}]', '12', '0:0:0:0:0:0:0:1', '2021-05-07 12:09:22');
INSERT INTO `sys_log` VALUES ('82', 'admin', '删除菜单', 'io.renren.modules.sys.controller.SysMenuController.delete()', '[32]', '55', '0:0:0:0:0:0:0:1', '2021-05-17 13:41:47');
INSERT INTO `sys_log` VALUES ('83', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":135,\"parentId\":31,\"name\":\"职工管理\",\"url\":\"mysys/sysemployee\",\"type\":1,\"icon\":\"config\",\"orderNum\":1}]', '7', '0:0:0:0:0:0:0:1', '2021-05-17 13:44:46');
INSERT INTO `sys_log` VALUES ('84', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":145,\"parentId\":31,\"name\":\"用户管理\",\"url\":\"mysys/sysuser\",\"type\":1,\"icon\":\"config\",\"orderNum\":2}]', '7', '0:0:0:0:0:0:0:1', '2021-05-17 13:44:53');
INSERT INTO `sys_log` VALUES ('85', 'admin', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '[{\"menuId\":140,\"parentId\":31,\"name\":\"权限管理\",\"url\":\"mysys/sysrole\",\"type\":1,\"icon\":\"config\",\"orderNum\":3}]', '4', '0:0:0:0:0:0:0:1', '2021-05-17 13:44:59');

-- ----------------------------
-- Table structure for sys_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_menu`;
CREATE TABLE `sys_menu` (
  `menu_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) DEFAULT NULL COMMENT '父菜单ID，一级菜单为0',
  `name` varchar(50) DEFAULT NULL COMMENT '菜单名称',
  `url` varchar(200) DEFAULT NULL COMMENT '菜单URL',
  `perms` varchar(500) DEFAULT NULL COMMENT '授权(多个用逗号分隔，如：user:list,user:create)',
  `type` int(11) DEFAULT NULL COMMENT '类型   0：目录   1：菜单   2：按钮',
  `icon` varchar(50) DEFAULT NULL COMMENT '菜单图标',
  `order_num` int(11) DEFAULT NULL COMMENT '排序',
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=150 DEFAULT CHARSET=utf8mb4 COMMENT='菜单管理';

-- ----------------------------
-- Records of sys_menu
-- ----------------------------
INSERT INTO `sys_menu` VALUES ('1', '0', '系统管理', null, null, '0', 'system', '0');
INSERT INTO `sys_menu` VALUES ('2', '1', '管理员列表', 'sys/user', null, '1', 'admin', '1');
INSERT INTO `sys_menu` VALUES ('3', '1', '角色管理', 'sys/role', null, '1', 'role', '2');
INSERT INTO `sys_menu` VALUES ('4', '1', '菜单管理', 'sys/menu', null, '1', 'menu', '3');
INSERT INTO `sys_menu` VALUES ('5', '1', 'SQL监控', 'http://localhost:8080/renren-fast/druid/sql.html', null, '1', 'sql', '4');
INSERT INTO `sys_menu` VALUES ('6', '1', '定时任务', 'job/schedule', null, '1', 'job', '5');
INSERT INTO `sys_menu` VALUES ('7', '6', '查看', null, 'sys:schedule:list,sys:schedule:info', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('8', '6', '新增', null, 'sys:schedule:save', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('9', '6', '修改', null, 'sys:schedule:update', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('10', '6', '删除', null, 'sys:schedule:delete', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('11', '6', '暂停', null, 'sys:schedule:pause', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('12', '6', '恢复', null, 'sys:schedule:resume', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('13', '6', '立即执行', null, 'sys:schedule:run', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('14', '6', '日志列表', null, 'sys:schedule:log', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('15', '2', '查看', null, 'sys:user:list,sys:user:info', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('16', '2', '新增', null, 'sys:user:save,sys:role:select', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('17', '2', '修改', null, 'sys:user:update,sys:role:select', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('18', '2', '删除', null, 'sys:user:delete', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('19', '3', '查看', null, 'sys:role:list,sys:role:info', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('20', '3', '新增', null, 'sys:role:save,sys:menu:list', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('21', '3', '修改', null, 'sys:role:update,sys:menu:list', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('22', '3', '删除', null, 'sys:role:delete', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('23', '4', '查看', null, 'sys:menu:list,sys:menu:info', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('24', '4', '新增', null, 'sys:menu:save,sys:menu:select', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('25', '4', '修改', null, 'sys:menu:update,sys:menu:select', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('26', '4', '删除', null, 'sys:menu:delete', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('27', '1', '参数管理', 'sys/config', 'sys:config:list,sys:config:info,sys:config:save,sys:config:update,sys:config:delete', '1', 'config', '6');
INSERT INTO `sys_menu` VALUES ('29', '1', '系统日志', 'sys/log', 'sys:log:list', '1', 'log', '7');
INSERT INTO `sys_menu` VALUES ('30', '1', '文件上传', 'oss/oss', 'sys:oss:all', '1', 'oss', '8');
INSERT INTO `sys_menu` VALUES ('31', '0', '颐养中心管理', '', '', '0', 'admin', '11');
INSERT INTO `sys_menu` VALUES ('34', '0', '膳食管理', '', '', '0', 'zonghe', '1');
INSERT INTO `sys_menu` VALUES ('35', '34', '饮食菜单', 'ysmenu/ysfoodmenu', 'ysmenu:ysfoodmenu:list,ysmenu:ysfoodmenu:save,ysmenu:ysfoodmenu:delete,ysmenu:ysfoodmenu:update,ysmenu:ysfoodmenu:info', '1', 'menu', '0');
INSERT INTO `sys_menu` VALUES ('36', '66', '入住登记', 'customer/infocheckin', 'customer:infocheckin:list,customer:infocheckin:info,customer:infocheckin:update,customer:infocheckin:save,customer:infocheckin:delete', '1', 'config', '1');
INSERT INTO `sys_menu` VALUES ('37', '36', '查看', null, 'customer:infocheckin:list,customer:infocheckin:info', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('38', '36', '新增', null, 'customer:infocheckin:save', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('39', '36', '修改', null, 'customer:infocheckin:update', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('40', '36', '删除', null, 'customer:infocheckin:delete', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('41', '66', '退住登记', 'customer/infocheckout', '', '1', 'config', '2');
INSERT INTO `sys_menu` VALUES ('42', '41', '查看', null, 'customer:infocheckout:list,customer:infocheckout:info', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('43', '41', '新增', null, 'customer:infocheckout:save', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('44', '41', '修改', null, 'customer:infocheckout:update', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('45', '41', '删除', null, 'customer:infocheckout:delete', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('46', '66', '客户档案', 'customer/infocusomerrecords', 'customer:infocusomerrecords:list,customer:infocusomerrecords:info,customer:infocusomerrecords:save,customer:infocusomerrecords:update,customer:infocusomerrecords:delete', '1', 'config', '3');
INSERT INTO `sys_menu` VALUES ('51', '66', '联系簿', 'customer/infofamilyrecords', 'customer:infofamilyrecords:list,customer:infofamilyrecords:info,customer:infofamilyrecords:delete,customer:infofamilyrecords:update,customer:infofamilyrecords:save', '1', 'config', '4');
INSERT INTO `sys_menu` VALUES ('52', '51', '查看', null, 'customer:infofamilyrecords:list,customer:infofamilyrecords:info', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('53', '51', '新增', null, 'customer:infofamilyrecords:save', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('54', '51', '修改', null, 'customer:infofamilyrecords:update', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('55', '51', '删除', null, 'customer:infofamilyrecords:delete', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('56', '66', '外来登记', 'customer/infootherrecords', 'customer:infootherrecords:list,customer:infootherrecords:save,customer:infootherrecords:update,customer:infootherrecords:info,customer:infootherrecords:delete', '1', 'config', '5');
INSERT INTO `sys_menu` VALUES ('57', '56', '查看', null, 'customer:infootherrecords:list,customer:infootherrecords:info', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('58', '56', '新增', null, 'customer:infootherrecords:save', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('59', '56', '修改', null, 'customer:infootherrecords:update', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('60', '56', '删除', null, 'customer:infootherrecords:delete', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('61', '66', '外出登记', 'customer/infooutrecords', 'customer:infooutrecords:list,customer:infooutrecords:info,customer:infooutrecords:save,customer:infooutrecords:update,customer:infooutrecords:delete', '1', 'config', '6');
INSERT INTO `sys_menu` VALUES ('62', '61', '查看', null, 'customer:infooutrecords:list,customer:infooutrecords:info', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('63', '61', '新增', null, 'customer:infooutrecords:save', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('64', '61', '修改', null, 'customer:infooutrecords:update', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('65', '61', '删除', null, 'customer:infooutrecords:delete', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('66', '0', '信息管理', '', '', '0', 'config', '0');
INSERT INTO `sys_menu` VALUES ('67', '0', '后勤管理', '', '', '0', 'tixing', '4');
INSERT INTO `sys_menu` VALUES ('68', '0', '床位管理', '', '', '0', 'suoding', '3');
INSERT INTO `sys_menu` VALUES ('69', '68', '房间管理', 'cw/cwroom', 'cw:cwroom:list,cw:cwroom:info,cw:cwroom:save,cw:cwroom:update,cw:cwroom:delete', '1', 'shouye', '0');
INSERT INTO `sys_menu` VALUES ('72', '67', '设备采购', 'houqin/hqbuy', null, '1', 'bianji', '6');
INSERT INTO `sys_menu` VALUES ('73', '72', '查看', null, 'houqin:hqbuy:list,houqin:hqbuy:info', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('74', '72', '新增', null, 'houqin:hqbuy:save', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('75', '72', '修改', null, 'houqin:hqbuy:update', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('76', '72', '删除', null, 'houqin:hqbuy:delete', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('77', '68', '床位管理', 'cw/cwbed', 'cw:cwbed:list,cw:cwbed:info,cw:cwbed:save,cw:cwbed:update,cw:cwbed:delete', '1', 'log', '0');
INSERT INTO `sys_menu` VALUES ('78', '67', '设备维修', 'houqin/hqservice', null, '1', 'system', '6');
INSERT INTO `sys_menu` VALUES ('79', '78', '查看', null, 'houqin:hqservice:list,houqin:hqservice:info', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('80', '78', '新增', null, 'houqin:hqservice:save', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('81', '78', '修改', null, 'houqin:hqservice:update', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('82', '78', '删除', null, 'houqin:hqservice:delete', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('83', '67', '床铺清洁', 'houqin/hqclean', null, '1', 'job', '6');
INSERT INTO `sys_menu` VALUES ('84', '83', '查看', null, 'houqin:hqclean:list,houqin:hqclean:info', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('85', '83', '新增', null, 'houqin:hqclean:save', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('86', '83', '修改', null, 'houqin:hqclean:update', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('87', '83', '删除', null, 'houqin:hqclean:delete', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('88', '34', '膳食分类', 'ysmenu/ysfoodclass', null, '1', 'config', '6');
INSERT INTO `sys_menu` VALUES ('89', '88', '查看', null, 'ysmenu:ysfoodclass:list,ysmenu:ysfoodclass:info', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('90', '88', '新增', null, 'ysmenu:ysfoodclass:save', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('91', '88', '修改', null, 'ysmenu:ysfoodclass:update', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('92', '88', '删除', null, 'ysmenu:ysfoodclass:delete', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('93', '34', '膳食计划', 'ysmenu/ysfoodplan', null, '1', 'config', '6');
INSERT INTO `sys_menu` VALUES ('94', '93', '查看', null, 'ysmenu:ysfoodplan:list,ysmenu:ysfoodplan:info', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('95', '93', '新增', null, 'ysmenu:ysfoodplan:save', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('96', '93', '修改', null, 'ysmenu:ysfoodplan:update', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('97', '93', '删除', null, 'ysmenu:ysfoodplan:delete', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('98', '108', '费用订单', 'fy/fyorder', null, '1', 'config', '6');
INSERT INTO `sys_menu` VALUES ('99', '98', '查看', null, 'fy:fyorder:list,fy:fyorder:info', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('100', '98', '新增', null, 'fy:fyorder:save', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('101', '98', '修改', null, 'fy:fyorder:update', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('102', '98', '删除', null, 'fy:fyorder:delete', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('103', '108', '费用记录', 'fy/fyrecord', null, '1', 'config', '6');
INSERT INTO `sys_menu` VALUES ('104', '103', '查看', null, 'fy:fyrecord:list,fy:fyrecord:info', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('105', '103', '新增', null, 'fy:fyrecord:save', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('106', '103', '修改', null, 'fy:fyrecord:update', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('107', '103', '删除', null, 'fy:fyrecord:delete', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('108', '0', '费用管理', '', '', '0', 'zonghe', '5');
INSERT INTO `sys_menu` VALUES ('109', '0', '护理管理', '', '', '0', 'zonghe', '2');
INSERT INTO `sys_menu` VALUES ('110', '109', '体检记录', 'hl/hlhealthrecord', null, '1', 'config', '6');
INSERT INTO `sys_menu` VALUES ('111', '110', '查看', null, 'hl:hlhealthrecord:list,hl:hlhealthrecord:info', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('112', '110', '新增', null, 'hl:hlhealthrecord:save', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('113', '110', '修改', null, 'hl:hlhealthrecord:update', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('114', '110', '删除', null, 'hl:hlhealthrecord:delete', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('115', '109', '护理等级', 'hl/hllevel', null, '1', 'config', '6');
INSERT INTO `sys_menu` VALUES ('116', '115', '查看', null, 'hl:hllevel:list,hl:hllevel:info', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('117', '115', '新增', null, 'hl:hllevel:save', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('118', '115', '修改', null, 'hl:hllevel:update', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('119', '115', '删除', null, 'hl:hllevel:delete', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('120', '109', '护理记录', 'hl/hlnursingrecord', null, '1', 'config', '6');
INSERT INTO `sys_menu` VALUES ('121', '120', '查看', null, 'hl:hlnursingrecord:list,hl:hlnursingrecord:info', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('122', '120', '新增', null, 'hl:hlnursingrecord:save', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('123', '120', '修改', null, 'hl:hlnursingrecord:update', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('124', '120', '删除', null, 'hl:hlnursingrecord:delete', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('125', '109', '护理计划', 'hl/hlplan', null, '1', 'config', '6');
INSERT INTO `sys_menu` VALUES ('126', '125', '查看', null, 'hl:hlplan:list,hl:hlplan:info', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('127', '125', '新增', null, 'hl:hlplan:save', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('128', '125', '修改', null, 'hl:hlplan:update', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('129', '125', '删除', null, 'hl:hlplan:delete', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('130', '109', '护理项目', 'hl/hlproject', null, '1', 'config', '6');
INSERT INTO `sys_menu` VALUES ('131', '130', '查看', null, 'hl:hlproject:list,hl:hlproject:info', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('132', '130', '新增', null, 'hl:hlproject:save', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('133', '130', '修改', null, 'hl:hlproject:update', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('134', '130', '删除', null, 'hl:hlproject:delete', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('135', '31', '职工管理', 'mysys/sysemployee', null, '1', 'config', '1');
INSERT INTO `sys_menu` VALUES ('136', '135', '查看', null, 'mysys:sysemployee:list,mysys:sysemployee:info', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('137', '135', '新增', null, 'mysys:sysemployee:save', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('138', '135', '修改', null, 'mysys:sysemployee:update', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('139', '135', '删除', null, 'mysys:sysemployee:delete', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('140', '31', '权限管理', 'mysys/sysrole', null, '1', 'config', '3');
INSERT INTO `sys_menu` VALUES ('141', '140', '查看', null, 'mysys:sysrole:list,mysys:sysrole:info', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('142', '140', '新增', null, 'mysys:sysrole:save', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('143', '140', '修改', null, 'mysys:sysrole:update', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('144', '140', '删除', null, 'mysys:sysrole:delete', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('145', '31', '用户管理', 'mysys/sysuser', null, '1', 'config', '2');
INSERT INTO `sys_menu` VALUES ('146', '145', '查看', null, 'mysys:sysuser:list,mysys:sysuser:info', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('147', '145', '新增', null, 'mysys:sysuser:save', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('148', '145', '修改', null, 'mysys:sysuser:update', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('149', '145', '删除', null, 'mysys:sysuser:delete', '2', null, '6');

-- ----------------------------
-- Table structure for sys_oss
-- ----------------------------
DROP TABLE IF EXISTS `sys_oss`;
CREATE TABLE `sys_oss` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `url` varchar(200) DEFAULT NULL COMMENT 'URL地址',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='文件上传';

-- ----------------------------
-- Records of sys_oss
-- ----------------------------

-- ----------------------------
-- Table structure for sys_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_role`;
CREATE TABLE `sys_role` (
  `role_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(100) DEFAULT NULL COMMENT '角色名称',
  `remark` varchar(100) DEFAULT NULL COMMENT '备注',
  `create_user_id` bigint(20) DEFAULT NULL COMMENT '创建者ID',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='角色';

-- ----------------------------
-- Records of sys_role
-- ----------------------------
INSERT INTO `sys_role` VALUES ('1', 'all', '', '1', '2021-04-30 14:39:37');

-- ----------------------------
-- Table structure for sys_role_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_menu`;
CREATE TABLE `sys_role_menu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) DEFAULT NULL COMMENT '角色ID',
  `menu_id` bigint(20) DEFAULT NULL COMMENT '菜单ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=537 DEFAULT CHARSET=utf8mb4 COMMENT='角色与菜单对应关系';

-- ----------------------------
-- Records of sys_role_menu
-- ----------------------------
INSERT INTO `sys_role_menu` VALUES ('410', '1', '1');
INSERT INTO `sys_role_menu` VALUES ('411', '1', '2');
INSERT INTO `sys_role_menu` VALUES ('412', '1', '15');
INSERT INTO `sys_role_menu` VALUES ('413', '1', '16');
INSERT INTO `sys_role_menu` VALUES ('414', '1', '17');
INSERT INTO `sys_role_menu` VALUES ('415', '1', '18');
INSERT INTO `sys_role_menu` VALUES ('416', '1', '3');
INSERT INTO `sys_role_menu` VALUES ('417', '1', '19');
INSERT INTO `sys_role_menu` VALUES ('418', '1', '20');
INSERT INTO `sys_role_menu` VALUES ('419', '1', '21');
INSERT INTO `sys_role_menu` VALUES ('420', '1', '22');
INSERT INTO `sys_role_menu` VALUES ('421', '1', '4');
INSERT INTO `sys_role_menu` VALUES ('422', '1', '23');
INSERT INTO `sys_role_menu` VALUES ('423', '1', '24');
INSERT INTO `sys_role_menu` VALUES ('424', '1', '25');
INSERT INTO `sys_role_menu` VALUES ('425', '1', '26');
INSERT INTO `sys_role_menu` VALUES ('426', '1', '5');
INSERT INTO `sys_role_menu` VALUES ('427', '1', '6');
INSERT INTO `sys_role_menu` VALUES ('428', '1', '7');
INSERT INTO `sys_role_menu` VALUES ('429', '1', '8');
INSERT INTO `sys_role_menu` VALUES ('430', '1', '9');
INSERT INTO `sys_role_menu` VALUES ('431', '1', '10');
INSERT INTO `sys_role_menu` VALUES ('432', '1', '11');
INSERT INTO `sys_role_menu` VALUES ('433', '1', '12');
INSERT INTO `sys_role_menu` VALUES ('434', '1', '13');
INSERT INTO `sys_role_menu` VALUES ('435', '1', '14');
INSERT INTO `sys_role_menu` VALUES ('436', '1', '27');
INSERT INTO `sys_role_menu` VALUES ('437', '1', '29');
INSERT INTO `sys_role_menu` VALUES ('438', '1', '30');
INSERT INTO `sys_role_menu` VALUES ('439', '1', '31');
INSERT INTO `sys_role_menu` VALUES ('441', '1', '34');
INSERT INTO `sys_role_menu` VALUES ('442', '1', '35');
INSERT INTO `sys_role_menu` VALUES ('443', '1', '88');
INSERT INTO `sys_role_menu` VALUES ('444', '1', '89');
INSERT INTO `sys_role_menu` VALUES ('445', '1', '90');
INSERT INTO `sys_role_menu` VALUES ('446', '1', '91');
INSERT INTO `sys_role_menu` VALUES ('447', '1', '92');
INSERT INTO `sys_role_menu` VALUES ('448', '1', '93');
INSERT INTO `sys_role_menu` VALUES ('449', '1', '94');
INSERT INTO `sys_role_menu` VALUES ('450', '1', '95');
INSERT INTO `sys_role_menu` VALUES ('451', '1', '96');
INSERT INTO `sys_role_menu` VALUES ('452', '1', '97');
INSERT INTO `sys_role_menu` VALUES ('453', '1', '66');
INSERT INTO `sys_role_menu` VALUES ('454', '1', '36');
INSERT INTO `sys_role_menu` VALUES ('455', '1', '37');
INSERT INTO `sys_role_menu` VALUES ('456', '1', '38');
INSERT INTO `sys_role_menu` VALUES ('457', '1', '39');
INSERT INTO `sys_role_menu` VALUES ('458', '1', '40');
INSERT INTO `sys_role_menu` VALUES ('459', '1', '41');
INSERT INTO `sys_role_menu` VALUES ('460', '1', '42');
INSERT INTO `sys_role_menu` VALUES ('461', '1', '43');
INSERT INTO `sys_role_menu` VALUES ('462', '1', '44');
INSERT INTO `sys_role_menu` VALUES ('463', '1', '45');
INSERT INTO `sys_role_menu` VALUES ('464', '1', '46');
INSERT INTO `sys_role_menu` VALUES ('465', '1', '51');
INSERT INTO `sys_role_menu` VALUES ('466', '1', '52');
INSERT INTO `sys_role_menu` VALUES ('467', '1', '53');
INSERT INTO `sys_role_menu` VALUES ('468', '1', '54');
INSERT INTO `sys_role_menu` VALUES ('469', '1', '55');
INSERT INTO `sys_role_menu` VALUES ('470', '1', '56');
INSERT INTO `sys_role_menu` VALUES ('471', '1', '57');
INSERT INTO `sys_role_menu` VALUES ('472', '1', '58');
INSERT INTO `sys_role_menu` VALUES ('473', '1', '59');
INSERT INTO `sys_role_menu` VALUES ('474', '1', '60');
INSERT INTO `sys_role_menu` VALUES ('475', '1', '61');
INSERT INTO `sys_role_menu` VALUES ('476', '1', '62');
INSERT INTO `sys_role_menu` VALUES ('477', '1', '63');
INSERT INTO `sys_role_menu` VALUES ('478', '1', '64');
INSERT INTO `sys_role_menu` VALUES ('479', '1', '65');
INSERT INTO `sys_role_menu` VALUES ('480', '1', '67');
INSERT INTO `sys_role_menu` VALUES ('481', '1', '72');
INSERT INTO `sys_role_menu` VALUES ('482', '1', '73');
INSERT INTO `sys_role_menu` VALUES ('483', '1', '74');
INSERT INTO `sys_role_menu` VALUES ('484', '1', '75');
INSERT INTO `sys_role_menu` VALUES ('485', '1', '76');
INSERT INTO `sys_role_menu` VALUES ('486', '1', '78');
INSERT INTO `sys_role_menu` VALUES ('487', '1', '79');
INSERT INTO `sys_role_menu` VALUES ('488', '1', '80');
INSERT INTO `sys_role_menu` VALUES ('489', '1', '81');
INSERT INTO `sys_role_menu` VALUES ('490', '1', '82');
INSERT INTO `sys_role_menu` VALUES ('491', '1', '83');
INSERT INTO `sys_role_menu` VALUES ('492', '1', '84');
INSERT INTO `sys_role_menu` VALUES ('493', '1', '85');
INSERT INTO `sys_role_menu` VALUES ('494', '1', '86');
INSERT INTO `sys_role_menu` VALUES ('495', '1', '87');
INSERT INTO `sys_role_menu` VALUES ('496', '1', '68');
INSERT INTO `sys_role_menu` VALUES ('497', '1', '69');
INSERT INTO `sys_role_menu` VALUES ('498', '1', '77');
INSERT INTO `sys_role_menu` VALUES ('499', '1', '108');
INSERT INTO `sys_role_menu` VALUES ('500', '1', '98');
INSERT INTO `sys_role_menu` VALUES ('501', '1', '99');
INSERT INTO `sys_role_menu` VALUES ('502', '1', '100');
INSERT INTO `sys_role_menu` VALUES ('503', '1', '101');
INSERT INTO `sys_role_menu` VALUES ('504', '1', '102');
INSERT INTO `sys_role_menu` VALUES ('505', '1', '103');
INSERT INTO `sys_role_menu` VALUES ('506', '1', '104');
INSERT INTO `sys_role_menu` VALUES ('507', '1', '105');
INSERT INTO `sys_role_menu` VALUES ('508', '1', '106');
INSERT INTO `sys_role_menu` VALUES ('509', '1', '107');
INSERT INTO `sys_role_menu` VALUES ('510', '1', '109');
INSERT INTO `sys_role_menu` VALUES ('511', '1', '110');
INSERT INTO `sys_role_menu` VALUES ('512', '1', '111');
INSERT INTO `sys_role_menu` VALUES ('513', '1', '112');
INSERT INTO `sys_role_menu` VALUES ('514', '1', '113');
INSERT INTO `sys_role_menu` VALUES ('515', '1', '114');
INSERT INTO `sys_role_menu` VALUES ('516', '1', '115');
INSERT INTO `sys_role_menu` VALUES ('517', '1', '116');
INSERT INTO `sys_role_menu` VALUES ('518', '1', '117');
INSERT INTO `sys_role_menu` VALUES ('519', '1', '118');
INSERT INTO `sys_role_menu` VALUES ('520', '1', '119');
INSERT INTO `sys_role_menu` VALUES ('521', '1', '120');
INSERT INTO `sys_role_menu` VALUES ('522', '1', '121');
INSERT INTO `sys_role_menu` VALUES ('523', '1', '122');
INSERT INTO `sys_role_menu` VALUES ('524', '1', '123');
INSERT INTO `sys_role_menu` VALUES ('525', '1', '124');
INSERT INTO `sys_role_menu` VALUES ('526', '1', '125');
INSERT INTO `sys_role_menu` VALUES ('527', '1', '126');
INSERT INTO `sys_role_menu` VALUES ('528', '1', '127');
INSERT INTO `sys_role_menu` VALUES ('529', '1', '128');
INSERT INTO `sys_role_menu` VALUES ('530', '1', '129');
INSERT INTO `sys_role_menu` VALUES ('531', '1', '130');
INSERT INTO `sys_role_menu` VALUES ('532', '1', '131');
INSERT INTO `sys_role_menu` VALUES ('533', '1', '132');
INSERT INTO `sys_role_menu` VALUES ('534', '1', '133');
INSERT INTO `sys_role_menu` VALUES ('535', '1', '134');
INSERT INTO `sys_role_menu` VALUES ('536', '1', '-666666');

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user` (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `password` varchar(100) DEFAULT NULL COMMENT '密码',
  `salt` varchar(20) DEFAULT NULL COMMENT '盐',
  `email` varchar(100) DEFAULT NULL COMMENT '邮箱',
  `mobile` varchar(100) DEFAULT NULL COMMENT '手机号',
  `status` tinyint(4) DEFAULT NULL COMMENT '状态  0：禁用   1：正常',
  `create_user_id` bigint(20) DEFAULT NULL COMMENT '创建者ID',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COMMENT='系统用户';

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES ('1', 'admin', '0d346fb1d43a4d9e8c4fcbf2431d6d38f980148de7ffd9f2672a65afa8e3bcb0', 'YzcmCZNvbXocrsz9dm8e', 'root@renren.io', '13612345678', '1', '1', '2016-11-11 11:11:11');
INSERT INTO `sys_user` VALUES ('2', 'wsj', '2a17de705ed33ad229767b67d75479ade0310665f7ce9282988663ef4e27b426', 'CKDaBnrxf54oyaHEXJnX', '1623637010@qq.com', '18144625235', '1', '1', '2021-04-30 14:38:35');
INSERT INTO `sys_user` VALUES ('3', 'jfy', '7c796a2345fe1d72ddb6d2d2f367ff456523561601c1d79016f54262513a4ebe', 'p66Cfhhw5WCxZJS6CtFD', '12312312@qq.com', '18145642051', '1', '1', '2021-04-30 14:40:41');
INSERT INTO `sys_user` VALUES ('4', 'lyf', 'c5ea9ec499157c6da8b6950757136f1c202d390dfec95f9a174c7cb1c8fd3a8f', 'p66Cfhhw5WCxZJS6CtFD', '12312312@qq.com', '18145642052', '1', '1', '2021-04-30 14:40:41');
INSERT INTO `sys_user` VALUES ('5', 'xwj', '15925fd011388bbac240c94aa12477f4884d3a48296fa46b55d97438dae1931a', 'p66Cfhhw5WCxZJS6CtFD', '12312312@qq.com', '18145642053', '1', '1', '2021-04-30 14:40:41');
INSERT INTO `sys_user` VALUES ('6', 'lxh', '1ee8af8df4d01646a413a02507c4b497de59f0ffcca75e09ada1f8f096994f67', 'p66Cfhhw5WCxZJS6CtFD', '12312312@qq.com', '18145642054', '1', '1', '2021-04-30 14:40:41');
INSERT INTO `sys_user` VALUES ('7', 'cxj', 'cd8b6ad2f8ff53f2f8f66bb3c961277b85e32d8ccf342ff030b49e729d55f57c', 'p66Cfhhw5WCxZJS6CtFD', '12312312@qq.com', '18145642055', '1', '1', '2021-04-30 14:40:41');

-- ----------------------------
-- Table structure for sys_user_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_user_role`;
CREATE TABLE `sys_user_role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL COMMENT '用户ID',
  `role_id` bigint(20) DEFAULT NULL COMMENT '角色ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COMMENT='用户与角色对应关系';

-- ----------------------------
-- Records of sys_user_role
-- ----------------------------
INSERT INTO `sys_user_role` VALUES ('3', '2', '1');
INSERT INTO `sys_user_role` VALUES ('9', '5', '1');
INSERT INTO `sys_user_role` VALUES ('10', '4', '1');
INSERT INTO `sys_user_role` VALUES ('11', '6', '1');
INSERT INTO `sys_user_role` VALUES ('12', '7', '1');
INSERT INTO `sys_user_role` VALUES ('13', '3', '1');

-- ----------------------------
-- Table structure for sys_user_token
-- ----------------------------
DROP TABLE IF EXISTS `sys_user_token`;
CREATE TABLE `sys_user_token` (
  `user_id` bigint(20) NOT NULL,
  `token` varchar(100) NOT NULL COMMENT 'token',
  `expire_time` datetime DEFAULT NULL COMMENT '过期时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `token` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统用户Token';

-- ----------------------------
-- Records of sys_user_token
-- ----------------------------
INSERT INTO `sys_user_token` VALUES ('1', '7b07fc6f1a3c5240f326f63700b4f354', '2021-05-25 05:48:40', '2021-05-24 17:48:40');
INSERT INTO `sys_user_token` VALUES ('2', '9cd6d45c55b7abd7c4f3264ce727e3c5', '2021-05-17 20:55:09', '2021-05-17 08:55:09');
INSERT INTO `sys_user_token` VALUES ('3', 'bc2a5beb6edfc5552f8c3c8c052a94c6', '2021-05-17 21:32:45', '2021-05-17 09:32:45');
INSERT INTO `sys_user_token` VALUES ('4', '123a699943925870fe36df3ba3b3afce', '2021-05-18 02:09:40', '2021-05-17 14:09:40');
INSERT INTO `sys_user_token` VALUES ('5', 'a14da1d7d3b9f236e4b4b180d0f42bbf', '2021-05-25 02:32:35', '2021-05-24 14:32:35');
INSERT INTO `sys_user_token` VALUES ('6', 'dc1735715a1d4f098b32c28a212f223d', '2021-05-17 20:58:30', '2021-05-17 08:58:30');
INSERT INTO `sys_user_token` VALUES ('7', '0565f2b8ce350f3c1b0881bef7786443', '2021-05-25 06:27:22', '2021-05-24 18:27:22');

-- ----------------------------
-- Table structure for tb_cw_bed
-- ----------------------------
DROP TABLE IF EXISTS `tb_cw_bed`;
CREATE TABLE `tb_cw_bed` (
  `bed_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '床位id',
  `customer_id` int(11) DEFAULT NULL COMMENT '参照用户档案表，外键',
  `bed_check` int(11) NOT NULL DEFAULT '0' COMMENT '床位检查，清洁为1',
  `bed_clean` int(11) NOT NULL DEFAULT '0' COMMENT '床位是否需要清洁，清洁为1',
  `room_id` int(11) NOT NULL COMMENT '房间id参照房间表,外键',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `is_delete` int(11) NOT NULL DEFAULT '1' COMMENT '0表示已经删除',
  PRIMARY KEY (`bed_id`),
  KEY `customer_id` (`customer_id`),
  KEY `room_id` (`room_id`),
  CONSTRAINT `tb_cw_bed_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `tb_info_cusomer_records` (`id`),
  CONSTRAINT `tb_cw_bed_ibfk_2` FOREIGN KEY (`room_id`) REFERENCES `tb_cw_room` (`room_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_cw_bed
-- ----------------------------
INSERT INTO `tb_cw_bed` VALUES ('1', null, '0', '0', '1', '2021-05-06 16:32:39', '2021-05-09 11:35:04', '1');
INSERT INTO `tb_cw_bed` VALUES ('2', '2', '0', '0', '1', '2021-05-06 16:32:39', '2021-05-06 16:32:41', '1');
INSERT INTO `tb_cw_bed` VALUES ('3', '3', '0', '0', '1', '2021-05-06 16:32:39', '2021-05-06 16:32:41', '1');
INSERT INTO `tb_cw_bed` VALUES ('4', '4', '0', '0', '1', '2021-05-06 16:32:39', '2021-05-06 16:32:41', '1');
INSERT INTO `tb_cw_bed` VALUES ('5', '14', '0', '0', '1', '2021-05-06 16:32:39', '2021-05-12 10:25:14', '1');
INSERT INTO `tb_cw_bed` VALUES ('6', null, '0', '0', '1', '2021-05-06 16:32:39', '2021-05-17 12:17:33', '1');
INSERT INTO `tb_cw_bed` VALUES ('7', '1', '0', '0', '4', '2021-05-06 16:32:39', '2021-05-08 15:48:50', '1');

-- ----------------------------
-- Table structure for tb_cw_room
-- ----------------------------
DROP TABLE IF EXISTS `tb_cw_room`;
CREATE TABLE `tb_cw_room` (
  `room_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '房间id',
  `room_floor` int(11) NOT NULL DEFAULT '1' COMMENT '楼层1-7',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `is_delete` int(11) NOT NULL DEFAULT '1' COMMENT '删除为0',
  PRIMARY KEY (`room_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_cw_room
-- ----------------------------
INSERT INTO `tb_cw_room` VALUES ('1', '1', '2021-05-05 11:47:43', '2021-05-17 08:58:00', '1');
INSERT INTO `tb_cw_room` VALUES ('2', '2', '2021-05-17 09:16:55', '2021-05-17 09:16:55', '1');
INSERT INTO `tb_cw_room` VALUES ('3', '3', '2021-05-17 09:17:05', '2021-05-17 09:17:05', '1');
INSERT INTO `tb_cw_room` VALUES ('4', '4', '2021-05-17 09:17:05', '2021-05-17 09:29:02', '1');
INSERT INTO `tb_cw_room` VALUES ('5', '5', '2021-05-17 09:17:36', '2021-05-17 09:29:10', '0');
INSERT INTO `tb_cw_room` VALUES ('6', '4', '2021-05-17 13:38:21', '2021-05-17 13:38:48', '1');
INSERT INTO `tb_cw_room` VALUES ('7', '1', '2021-05-16 13:42:05', '2021-05-18 13:42:10', '0');
INSERT INTO `tb_cw_room` VALUES ('8', '7', '2021-05-17 13:41:50', '2021-05-17 13:41:50', '0');

-- ----------------------------
-- Table structure for tb_fy_order
-- ----------------------------
DROP TABLE IF EXISTS `tb_fy_order`;
CREATE TABLE `tb_fy_order` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '订单编号(主键，自动递增)',
  `customer_id` int(11) NOT NULL COMMENT '客户id：订单的源主',
  `order_type` varchar(10) NOT NULL COMMENT '订单类型[饮食、护理]',
  `order_name` varchar(10) NOT NULL COMMENT '订单项目名称:对应膳食名称或护理项目名称',
  `order_num` int(11) NOT NULL DEFAULT '1' COMMENT '订单数目：默认为1，对应所定项目的数量',
  `order_cost` double NOT NULL COMMENT '订单金额(单个项目的费用)',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `is_delete` int(11) NOT NULL DEFAULT '1' COMMENT '默认值为1,0表示已删除',
  PRIMARY KEY (`order_id`) USING BTREE,
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `tb_fy_order_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `tb_info_cusomer_records` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_fy_order
-- ----------------------------
INSERT INTO `tb_fy_order` VALUES ('1', '1', '护理', '护理一级', '1', '1500', '2021-05-07 13:04:47', '2021-05-08 09:04:53', '1');
INSERT INTO `tb_fy_order` VALUES ('2', '2', '饮食', '清真', '1', '1200', '2021-05-08 09:01:21', '2021-05-08 09:01:21', '1');

-- ----------------------------
-- Table structure for tb_fy_record
-- ----------------------------
DROP TABLE IF EXISTS `tb_fy_record`;
CREATE TABLE `tb_fy_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '缴费记录id：主键，自增',
  `costumer_id` int(11) NOT NULL COMMENT '客户ID',
  `order_id` int(11) DEFAULT NULL COMMENT '订单编号',
  `totalcost` double(10,2) NOT NULL COMMENT '费用总额',
  `pay_state` int(11) NOT NULL DEFAULT '0' COMMENT '缴费状态：默认值=0-未缴费，1-已缴费',
  `pay_time` datetime NOT NULL COMMENT '缴费时间',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `is_delete` int(11) NOT NULL DEFAULT '1' COMMENT '默认值为1,0表示删除',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `costumer_id` (`costumer_id`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `tb_fy_record_ibfk_1` FOREIGN KEY (`costumer_id`) REFERENCES `tb_info_cusomer_records` (`id`),
  CONSTRAINT `tb_fy_record_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `tb_fy_order` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_fy_record
-- ----------------------------
INSERT INTO `tb_fy_record` VALUES ('1', '1', '1', '1000.00', '1', '2021-05-08 10:01:23', '2021-05-08 10:01:23', '2021-05-08 10:01:23', '1');

-- ----------------------------
-- Table structure for tb_hl_health_record
-- ----------------------------
DROP TABLE IF EXISTS `tb_hl_health_record`;
CREATE TABLE `tb_hl_health_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '体检记录id：主键自增',
  `customer_id` int(10) NOT NULL COMMENT '客户id：外键，参照客户档案中的id',
  `do_time` datetime DEFAULT NULL COMMENT '体检时间',
  `liver_function` double(100,0) DEFAULT NULL COMMENT '肝功：正常（0-40）',
  `blood_sugar` double(255,0) DEFAULT NULL COMMENT '血糖：正常（3.9-6.0）',
  `heart_rate` double(255,0) DEFAULT NULL COMMENT '心率;正常（60-100)',
  `kidney_function` double(255,0) DEFAULT NULL COMMENT '肾功：正常（50-130)',
  `emp_id` int(11) DEFAULT NULL COMMENT '体检医生id：参照职工表',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `is_delete` int(11) NOT NULL DEFAULT '1' COMMENT '默认值为1,0表示已删除',
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  KEY `emp_id` (`emp_id`),
  CONSTRAINT `tb_hl_health_record_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `tb_info_cusomer_records` (`id`),
  CONSTRAINT `tb_hl_health_record_ibfk_2` FOREIGN KEY (`emp_id`) REFERENCES `tb_sys_employee` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_hl_health_record
-- ----------------------------
INSERT INTO `tb_hl_health_record` VALUES ('1', '2', '2021-05-12 16:27:13', '5', '60', '70', '40', null, '2021-05-13 16:28:14', '2021-05-14 16:28:17', '1');

-- ----------------------------
-- Table structure for tb_hl_level
-- ----------------------------
DROP TABLE IF EXISTS `tb_hl_level`;
CREATE TABLE `tb_hl_level` (
  `level_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '级别编号（主键自增）',
  `level_name` varchar(10) NOT NULL COMMENT '护理级别名称',
  `level_describe` varchar(255) DEFAULT NULL COMMENT '护理级别描述',
  `level_state` int(11) NOT NULL DEFAULT '1' COMMENT '级别状态，默认=1启用 0禁用',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `is_delete` int(11) NOT NULL DEFAULT '1' COMMENT '默认值为1，0表示已删除',
  PRIMARY KEY (`level_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_hl_level
-- ----------------------------
INSERT INTO `tb_hl_level` VALUES ('2', '一级', '特别严重', '1', '2021-04-29 19:41:41', '2021-04-29 19:41:46', '1');
INSERT INTO `tb_hl_level` VALUES ('3', '?', 'll', '1', '2021-05-24 14:32:59', '2021-05-24 14:32:59', '0');

-- ----------------------------
-- Table structure for tb_hl_nursing_record
-- ----------------------------
DROP TABLE IF EXISTS `tb_hl_nursing_record`;
CREATE TABLE `tb_hl_nursing_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '护理记录id：主键自增',
  `customer_id` int(10) NOT NULL COMMENT '客户id;外键，参照客户档案中的id',
  `nursing_time` datetime NOT NULL COMMENT '护理时间',
  `project_id` int(11) NOT NULL COMMENT '护理项目id：参照护理项目表中的id',
  `number` int(10) NOT NULL DEFAULT '1' COMMENT '数量',
  `level_id` int(11) NOT NULL COMMENT '护理等级id：参照护理等级',
  `emp_id` int(11) DEFAULT NULL COMMENT '护理人员：参照职工表中的id',
  `creat_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `is_delete` int(11) NOT NULL DEFAULT '1' COMMENT '默认值为1,0表示已删除',
  PRIMARY KEY (`id`),
  KEY `customer6` (`customer_id`),
  KEY `pid` (`project_id`),
  KEY `level_id` (`level_id`),
  KEY `emp_id` (`emp_id`),
  CONSTRAINT `customer6` FOREIGN KEY (`customer_id`) REFERENCES `tb_info_cusomer_records` (`id`),
  CONSTRAINT `pid` FOREIGN KEY (`project_id`) REFERENCES `tb_hl_project` (`project_id`),
  CONSTRAINT `tb_hl_nursing_record_ibfk_1` FOREIGN KEY (`level_id`) REFERENCES `tb_hl_level` (`level_id`),
  CONSTRAINT `tb_hl_nursing_record_ibfk_2` FOREIGN KEY (`emp_id`) REFERENCES `tb_sys_employee` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_hl_nursing_record
-- ----------------------------
INSERT INTO `tb_hl_nursing_record` VALUES ('1', '3', '2021-05-11 16:30:24', '1', '1', '2', null, '2021-05-13 16:30:38', '2021-05-14 16:30:42', '1');
INSERT INTO `tb_hl_nursing_record` VALUES ('2', '4', '2021-05-14 09:02:55', '1', '1', '2', null, '2021-05-15 09:03:12', '2021-05-16 09:03:17', '1');

-- ----------------------------
-- Table structure for tb_hl_plan
-- ----------------------------
DROP TABLE IF EXISTS `tb_hl_plan`;
CREATE TABLE `tb_hl_plan` (
  `plan_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '计划编号（主键自增）',
  `project_id` int(11) NOT NULL COMMENT '项目id: 参照护理项目表',
  `level_id` int(11) NOT NULL COMMENT '级别id：参照护理级别id',
  `custom_id` int(11) NOT NULL COMMENT '客户id：参照客户表',
  `emp_id` int(11) DEFAULT NULL COMMENT '护理师id：参照工作人员表',
  `plan_desc` varchar(50) NOT NULL COMMENT '护理计划描述',
  `plan_state` int(11) NOT NULL DEFAULT '1' COMMENT '计划状态默认=1启用 0禁用',
  `plan_cycle` int(11) NOT NULL DEFAULT '1' COMMENT '预计计划周期：(星期)1-5',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `is_delete` int(11) NOT NULL DEFAULT '1' COMMENT '默认值为1，0表示已删除',
  PRIMARY KEY (`plan_id`),
  KEY `project_id` (`project_id`),
  KEY `level_id` (`level_id`),
  KEY `custom_id` (`custom_id`),
  KEY `emp_id` (`emp_id`),
  CONSTRAINT `tb_hl_plan_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `tb_hl_project` (`project_id`),
  CONSTRAINT `tb_hl_plan_ibfk_2` FOREIGN KEY (`level_id`) REFERENCES `tb_hl_level` (`level_id`),
  CONSTRAINT `tb_hl_plan_ibfk_3` FOREIGN KEY (`custom_id`) REFERENCES `tb_info_cusomer_records` (`id`),
  CONSTRAINT `tb_hl_plan_ibfk_4` FOREIGN KEY (`emp_id`) REFERENCES `tb_sys_employee` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_hl_plan
-- ----------------------------
INSERT INTO `tb_hl_plan` VALUES ('1', '1', '2', '1', null, '不好', '1', '1', '2021-05-14 16:50:02', '2021-05-27 16:50:09', '1');

-- ----------------------------
-- Table structure for tb_hl_project
-- ----------------------------
DROP TABLE IF EXISTS `tb_hl_project`;
CREATE TABLE `tb_hl_project` (
  `project_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '项目编号（主键自增）',
  `project_name` varchar(10) NOT NULL COMMENT '护理项目名称',
  `project_describe` varchar(50) DEFAULT NULL COMMENT '护理项目描述',
  `project_state` int(11) NOT NULL DEFAULT '1' COMMENT '项目状态默认=1启用 0禁用',
  `project_price` double(10,2) NOT NULL COMMENT '护理项目价格',
  `project_note` varchar(50) DEFAULT NULL COMMENT '护理项目备注',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `is_delete` int(11) NOT NULL DEFAULT '1' COMMENT '默认值为1，0表示已删除',
  PRIMARY KEY (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_hl_project
-- ----------------------------
INSERT INTO `tb_hl_project` VALUES ('1', '穿衣', '穿衣穿衣', '0', '52.00', '穿衣', '2021-04-29 19:41:41', '2021-05-24 14:41:20', '1');

-- ----------------------------
-- Table structure for tb_hq_buy
-- ----------------------------
DROP TABLE IF EXISTS `tb_hq_buy`;
CREATE TABLE `tb_hq_buy` (
  `buy_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '采购记录id',
  `eq_name` varchar(50) NOT NULL COMMENT '设备名称',
  `buy_time` datetime NOT NULL COMMENT '采购时间',
  `buy_amount` int(11) NOT NULL DEFAULT '1' COMMENT '采购数量',
  `buy_price` double NOT NULL COMMENT '采购价格',
  `emp_id` int(10) DEFAULT NULL COMMENT '采购人  参照工作人员表id',
  `remarks` varchar(50) DEFAULT NULL COMMENT '备注',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `is_delete` int(11) NOT NULL DEFAULT '1' COMMENT '1  未删除    0  已删除',
  PRIMARY KEY (`buy_id`),
  KEY `emp_id` (`emp_id`),
  CONSTRAINT `tb_hq_buy_ibfk_1` FOREIGN KEY (`emp_id`) REFERENCES `tb_sys_employee` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_hq_buy
-- ----------------------------
INSERT INTO `tb_hq_buy` VALUES ('1', '血压仪', '2021-05-25 10:26:10', '1', '190', '1', null, '2021-05-16 10:26:19', '2021-05-17 11:01:08', '1');
INSERT INTO `tb_hq_buy` VALUES ('2', '雾化吸入器', '2021-05-07 19:25:49', '19', '500', '1', '5', '2021-05-17 11:01:06', '2021-05-17 11:41:05', '1');
INSERT INTO `tb_hq_buy` VALUES ('3', '艾灸仪', '2021-05-07 22:44:06', '6', '300', '1', '', '2021-05-17 11:01:02', '2021-05-08 13:49:41', '0');
INSERT INTO `tb_hq_buy` VALUES ('4', '吸痰器', '2021-05-15 19:26:19', '4', '240', '1', '', '2021-05-08 13:51:05', '2021-05-08 13:51:05', '0');
INSERT INTO `tb_hq_buy` VALUES ('5', '单人床', '2021-04-29 00:00:00', '10', '120', '1', '测试', '2021-05-17 11:02:55', '2021-05-17 11:05:46', '1');
INSERT INTO `tb_hq_buy` VALUES ('6', '2', '2021-05-17 11:03:29', '2', '223', '1', '测试', '2021-05-17 11:03:43', '2021-05-17 11:03:43', '1');

-- ----------------------------
-- Table structure for tb_hq_clean
-- ----------------------------
DROP TABLE IF EXISTS `tb_hq_clean`;
CREATE TABLE `tb_hq_clean` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '保洁记录id',
  `bed_id` int(100) DEFAULT NULL COMMENT '床位 id 参照床位表id',
  `emp_id` int(11) DEFAULT NULL COMMENT '保洁员  参照工作人员表id',
  `clean_time` datetime DEFAULT NULL COMMENT '清洁时间',
  `clean_status` int(11) NOT NULL DEFAULT '0' COMMENT '清洁状态   0 未清洁   1 已清洁',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `is_delete` int(11) NOT NULL DEFAULT '1' COMMENT '1  未删除    0  已删除',
  PRIMARY KEY (`id`),
  KEY `bed_id` (`bed_id`),
  KEY `emp_id` (`emp_id`),
  CONSTRAINT `tb_hq_clean_ibfk_1` FOREIGN KEY (`bed_id`) REFERENCES `tb_cw_bed` (`bed_id`),
  CONSTRAINT `tb_hq_clean_ibfk_2` FOREIGN KEY (`emp_id`) REFERENCES `tb_sys_employee` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_hq_clean
-- ----------------------------
INSERT INTO `tb_hq_clean` VALUES ('1', '5', null, '2021-05-16 10:25:45', '0', null, '2021-05-09 11:03:26', '1');
INSERT INTO `tb_hq_clean` VALUES ('2', '2', null, '2021-05-10 09:00:00', '1', null, '2021-05-09 11:03:15', '1');
INSERT INTO `tb_hq_clean` VALUES ('3', '5', null, '2021-05-24 10:25:45', '1', '2021-05-11 10:38:00', '2021-05-09 10:37:49', '1');
INSERT INTO `tb_hq_clean` VALUES ('4', '1', null, '2021-05-24 10:25:45', '0', null, '2021-05-09 13:31:01', '1');
INSERT INTO `tb_hq_clean` VALUES ('5', '5', null, '2021-05-08 20:05:44', '0', null, '2021-05-09 11:06:07', '1');
INSERT INTO `tb_hq_clean` VALUES ('6', '6', null, '2021-05-03 09:00:00', '1', null, '2021-05-17 10:53:03', '1');

-- ----------------------------
-- Table structure for tb_hq_service
-- ----------------------------
DROP TABLE IF EXISTS `tb_hq_service`;
CREATE TABLE `tb_hq_service` (
  `eq_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '设备id',
  `eq_name` varchar(10) NOT NULL COMMENT '设备名称',
  `check_status` int(11) NOT NULL DEFAULT '0' COMMENT '检修状态   0  未检修     1  已检修',
  `check_time` datetime DEFAULT NULL COMMENT '检修时间',
  `emp_id` int(11) DEFAULT NULL COMMENT '检修人员  参照工作人员表id',
  `check_result` varchar(50) DEFAULT NULL COMMENT '检修结果',
  `reason` varchar(50) DEFAULT NULL COMMENT '故障原因 ',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `is_delete` int(11) NOT NULL DEFAULT '1' COMMENT '1 未删除   0 已删除',
  PRIMARY KEY (`eq_id`),
  KEY `emp_id` (`emp_id`),
  CONSTRAINT `tb_hq_service_ibfk_1` FOREIGN KEY (`emp_id`) REFERENCES `tb_sys_employee` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_hq_service
-- ----------------------------
INSERT INTO `tb_hq_service` VALUES ('1', '血压仪', '1', '2021-05-07 10:23:39', '1', '', null, '2021-05-17 11:44:18', '2021-05-17 11:45:53', '1');
INSERT INTO `tb_hq_service` VALUES ('2', '血糖仪', '1', '2021-05-15 19:26:19', '1', '1', '1', '2021-05-17 11:44:15', '2021-05-17 11:45:58', '1');
INSERT INTO `tb_hq_service` VALUES ('3', '便携式心电图机', '0', '2021-05-07 13:57:50', null, '1', '1', '2021-05-17 11:44:12', '2021-05-17 11:44:21', '0');
INSERT INTO `tb_hq_service` VALUES ('4', '呼吸机', '1', '2021-05-06 22:57:50', '1', '', '', '2021-05-17 11:44:08', '2021-05-17 11:46:05', '1');
INSERT INTO `tb_hq_service` VALUES ('5', '紫外线消毒灯', '1', '2021-05-15 04:26:19', '1', '3', '3', '2021-05-17 11:44:00', '2021-05-17 11:46:45', '1');
INSERT INTO `tb_hq_service` VALUES ('6', '听诊器', '0', '2021-05-08 20:57:35', '1', '', '', '2021-05-17 11:43:56', '2021-05-17 11:46:17', '1');
INSERT INTO `tb_hq_service` VALUES ('7', '1', '0', '2021-05-13 00:00:00', '1', '', '', '2021-05-17 11:43:36', '2021-05-17 11:46:27', '1');

-- ----------------------------
-- Table structure for tb_info_check_in
-- ----------------------------
DROP TABLE IF EXISTS `tb_info_check_in`;
CREATE TABLE `tb_info_check_in` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '入住id: 主键自增长',
  `customer_id` int(11) NOT NULL COMMENT '客户id：参照客户档案中的id',
  `bed_id` int(11) NOT NULL COMMENT '床位id:参照床位表中的主键id',
  `start_time` datetime NOT NULL COMMENT '服务开始时间',
  `end_time` datetime NOT NULL COMMENT '服务结束时间',
  `valid_state` int(11) NOT NULL DEFAULT '1' COMMENT '客户状态: 默认值=1\r,1：在住客户\r0：退住客户',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `is_delete` int(11) NOT NULL DEFAULT '1' COMMENT '默认值为1,0表示已删除',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `customer2` (`customer_id`),
  KEY `bed` (`bed_id`),
  CONSTRAINT `bed` FOREIGN KEY (`bed_id`) REFERENCES `tb_cw_bed` (`bed_id`),
  CONSTRAINT `customer2` FOREIGN KEY (`customer_id`) REFERENCES `tb_info_cusomer_records` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of tb_info_check_in
-- ----------------------------
INSERT INTO `tb_info_check_in` VALUES ('1', '1', '1', '2021-05-06 16:33:01', '2021-06-11 16:33:07', '0', '2021-05-06 16:33:13', '2021-05-07 16:37:54', '1');
INSERT INTO `tb_info_check_in` VALUES ('2', '2', '2', '2021-05-05 16:33:01', '2021-07-01 16:33:07', '1', '2021-05-06 16:33:13', '2021-05-06 16:33:16', '1');
INSERT INTO `tb_info_check_in` VALUES ('3', '3', '3', '2021-05-25 16:33:01', '2021-06-09 16:33:07', '1', '2021-05-06 16:33:13', '2021-05-06 16:33:16', '1');
INSERT INTO `tb_info_check_in` VALUES ('4', '1', '1', '2022-05-12 00:00:00', '2024-05-16 00:00:00', '1', '2021-05-06 20:47:22', '2021-05-06 20:47:22', '0');
INSERT INTO `tb_info_check_in` VALUES ('5', '4', '4', '2021-04-15 00:00:00', '2021-05-06 20:48:02', '1', '2021-05-06 20:48:14', '2021-05-06 20:48:14', '1');
INSERT INTO `tb_info_check_in` VALUES ('6', '1', '1', '2021-05-08 00:00:00', '2022-05-07 00:00:00', '0', '2021-05-08 15:28:15', '2021-05-08 15:28:15', '1');
INSERT INTO `tb_info_check_in` VALUES ('7', '1', '1', '2021-05-19 00:00:00', '2021-06-23 00:00:00', '0', '2021-05-08 15:31:02', '2021-05-08 15:31:02', '1');
INSERT INTO `tb_info_check_in` VALUES ('8', '1', '7', '2021-06-08 00:00:00', '2021-09-30 00:00:00', '0', '2021-05-08 15:32:46', '2021-05-08 15:32:46', '1');
INSERT INTO `tb_info_check_in` VALUES ('9', '11', '6', '2021-05-14 00:00:00', '2021-05-22 00:00:00', '0', '2021-05-08 15:34:52', '2021-05-17 12:17:33', '1');
INSERT INTO `tb_info_check_in` VALUES ('10', '1', '7', '2021-06-30 00:00:00', '2022-06-29 00:00:00', '1', '2021-05-08 15:48:50', '2021-05-08 15:48:50', '1');
INSERT INTO `tb_info_check_in` VALUES ('11', '12', '6', '2021-05-18 00:00:00', '2021-05-28 02:00:00', '0', '2021-05-08 15:52:24', '2021-05-09 11:30:28', '1');
INSERT INTO `tb_info_check_in` VALUES ('12', '12', '1', '2021-05-13 00:00:00', '2021-05-28 00:00:00', '0', '2021-05-09 11:34:29', '2021-05-09 11:35:04', '1');
INSERT INTO `tb_info_check_in` VALUES ('13', '14', '5', '2021-05-12 10:25:05', '2021-05-14 00:00:00', '1', '2021-05-12 10:25:14', '2021-05-12 10:25:14', '1');

-- ----------------------------
-- Table structure for tb_info_check_out
-- ----------------------------
DROP TABLE IF EXISTS `tb_info_check_out`;
CREATE TABLE `tb_info_check_out` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '退住id：主键自增长',
  `cki_id` int(11) NOT NULL COMMENT '入住id: 参照入住登记表中的主键id',
  `check_out_type` int(11) NOT NULL DEFAULT '3' COMMENT '退住类型：1：合约到期 2：主动退住 3：其他',
  `check_out_time` datetime NOT NULL COMMENT '退住时间',
  `check_out_reason` varchar(100) DEFAULT NULL COMMENT '退住原因',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `is_delete` int(11) NOT NULL DEFAULT '1' COMMENT '默认值为1,0表示已删除',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `cki` (`cki_id`),
  CONSTRAINT `cki` FOREIGN KEY (`cki_id`) REFERENCES `tb_info_check_in` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of tb_info_check_out
-- ----------------------------
INSERT INTO `tb_info_check_out` VALUES ('1', '11', '2', '2021-05-10 00:00:00', '儿子回来了，让我搬回去住', '2021-05-09 11:30:28', '2021-05-09 11:43:11', '1');
INSERT INTO `tb_info_check_out` VALUES ('2', '12', '3', '2021-05-12 00:00:00', '故意不想住了，就是任性', '2021-05-09 11:35:04', '2021-05-09 11:44:19', '1');
INSERT INTO `tb_info_check_out` VALUES ('3', '9', '1', '2021-05-17 12:17:25', '1', '2021-05-17 12:17:33', '2021-05-17 12:17:33', '1');

-- ----------------------------
-- Table structure for tb_info_cusomer_records
-- ----------------------------
DROP TABLE IF EXISTS `tb_info_cusomer_records`;
CREATE TABLE `tb_info_cusomer_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '客户id：主键自增长',
  `name` varchar(10) NOT NULL COMMENT '客户姓名',
  `head_img_url` varchar(255) DEFAULT NULL COMMENT '客户头像',
  `gender` int(2) NOT NULL DEFAULT '1' COMMENT '客户性别: 1为男性,0为女性',
  `identity_number` varchar(18) NOT NULL COMMENT '身份证号码，唯一值',
  `birthday` date NOT NULL COMMENT '出生日期',
  `phone` varchar(11) NOT NULL COMMENT '手机号码',
  `blood_type` char(2) DEFAULT NULL COMMENT '血型: A/B/AB/O',
  `address` varchar(100) NOT NULL COMMENT '家庭地址',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `is_delete` int(11) NOT NULL DEFAULT '1' COMMENT '默认值为1,0表示已删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `identity_number` (`identity_number`) USING BTREE COMMENT '身份证号码唯一可用于索引'
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_info_cusomer_records
-- ----------------------------
INSERT INTO `tb_info_cusomer_records` VALUES ('1', '小明', 'https://tyj666-oss.oss-cn-beijing.aliyuncs.com/2021-05-06/27d95e00-413e-4a9e-88aa-e80d8112266c_20210316222543.jpg', '0', '510902199908021852', '1999-08-19', '18145462121', 'A', '浙江省/宁波市/江东区/百丈街道///', '2021-04-30 14:45:19', '2021-05-06 15:49:31', '1');
INSERT INTO `tb_info_cusomer_records` VALUES ('2', '小李', 'https://tyj666-oss.oss-cn-beijing.aliyuncs.com/2021-05-06/37c70f66-b865-429f-8a95-4fc12e76ae65_Hydrangeas.jpg', '1', '421902199908021852', '1999-08-02', '18145462151', 'AB', '山东省/济南市/市中区/杆石桥街道办事处/复兴小区/', '2021-04-30 14:45:19', '2021-05-06 15:44:40', '1');
INSERT INTO `tb_info_cusomer_records` VALUES ('3', '大乔', 'https://tyj666-oss.oss-cn-beijing.aliyuncs.com/2021-05-06/20ba72a9-78a3-4929-801f-98317ea029b2_Lighthouse.jpg', '0', '510902199906161812', '2021-05-06', '18144544444', 'AB', '天津市/市辖区/和平区/小白楼街道/不详', '2021-05-06 13:56:19', '2021-05-06 15:44:53', '1');
INSERT INTO `tb_info_cusomer_records` VALUES ('4', '小青', 'https://tyj666-oss.oss-cn-beijing.aliyuncs.com/2021-05-06/95bec2f2-60d6-44f8-8b01-c9f3bb0910a1_Chrysanthemum.jpg', '1', '211022199906211844', '2021-05-06', '17798895656', 'B', '辽宁省/本溪市/溪湖区/河西街道/不详', '2021-05-06 15:33:36', '2021-05-06 15:45:17', '1');
INSERT INTO `tb_info_cusomer_records` VALUES ('5', '小黄', 'https://tyj666-oss.oss-cn-beijing.aliyuncs.com/2021-05-07/1444ca34-cf34-4dce-85ae-793cae3bef66_Chrysanthemum.jpg', '0', '510902197512121622', '1972-12-12', '14777852368', 'AB', '山西省/阳泉市/矿区/沙坪街道办事处/12/12/12/12/12', '2021-05-07 14:14:31', '2021-05-07 15:02:50', '1');
INSERT INTO `tb_info_cusomer_records` VALUES ('6', '小刘', 'https://tyj666-oss.oss-cn-beijing.aliyuncs.com/2021-05-07/0f2ce3c9-8201-4125-8d47-f9ddb1ce9f32_20210316222543.jpg', '1', '510902199911011851', '2021-05-05', '18145642051', 'AB', '河北省/唐山市/路北区/缸窑街道办事处//////', '2021-05-07 15:00:32', '2021-05-07 15:00:32', '1');
INSERT INTO `tb_info_cusomer_records` VALUES ('7', '刘备', 'https://tyj666-oss.oss-cn-beijing.aliyuncs.com/2021-05-08/9dbbbd90-f964-4aa6-8477-0ab03004d654_Koala.jpg', '1', '510802197810011425', '1990-03-08', '18236370102', 'B', '辽宁省/丹东市/凤城市/沙里寨镇/不详', '2021-05-08 14:58:12', '2021-05-08 14:58:12', '1');
INSERT INTO `tb_info_cusomer_records` VALUES ('10', '关羽', 'https://tyj666-oss.oss-cn-beijing.aliyuncs.com/2021-05-08/9dbbbd90-f964-4aa6-8477-0ab03004d654_Koala.jpg', '1', '511802197710012825', '1990-03-08', '18236370102', 'B', '辽宁省/丹东市/凤城市/沙里寨镇/不详', '2021-05-08 15:03:00', '2021-05-08 15:03:00', '1');
INSERT INTO `tb_info_cusomer_records` VALUES ('11', '张飞', 'https://tyj666-oss.oss-cn-beijing.aliyuncs.com/2021-05-06/27d95e00-413e-4a9e-88aa-e80d8112266c_20210316222543.jpg', '1', '210902197804021662', '1978-04-02', '14789895666', 'AB', '广西壮族自治区/北海市/银海区/银滩镇/不详', '2021-05-08 15:34:52', '2021-05-08 15:34:52', '1');
INSERT INTO `tb_info_cusomer_records` VALUES ('12', '刘庆东', 'https://tyj666-oss.oss-cn-beijing.aliyuncs.com/2021-05-06/27d95e00-413e-4a9e-88aa-e80d8112266c_20210316222543.jpg', '1', '12345619880802122X', '1999-08-16', '13576768562', 'O', '浙江省/嘉兴市/海盐县/元通街道/不详', '2021-05-08 15:52:24', '2021-05-08 15:52:24', '1');
INSERT INTO `tb_info_cusomer_records` VALUES ('13', '李兆先', 'https://tyj666-oss.oss-cn-beijing.aliyuncs.com/2021-05-06/27d95e00-413e-4a9e-88aa-e80d8112266c_20210316222543.jpg', '1', '450566198808021856', '1999-08-10', '13595956562', 'A', '浙江省/嘉兴市/海盐县/元通街道/不详', '2021-05-08 15:52:24', '2021-05-08 15:52:24', '1');
INSERT INTO `tb_info_cusomer_records` VALUES ('14', '王晓', 'https://tyj666-oss.oss-cn-beijing.aliyuncs.com/2021-05-12/c67f32b2-b77d-4f6e-84f4-206cfd8b1c39_Tulips.jpg', '1', '421902196808122552', '1999-08-12', '18145462151', 'B', '山西省/长治市/襄垣县/侯堡镇/不详', '2021-05-12 10:25:14', '2021-05-12 10:25:14', '1');

-- ----------------------------
-- Table structure for tb_info_family_records
-- ----------------------------
DROP TABLE IF EXISTS `tb_info_family_records`;
CREATE TABLE `tb_info_family_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '家属id：主键自增',
  `customer_id` int(11) NOT NULL COMMENT '客户id: 参照客户档案中的主键id',
  `name` varchar(10) NOT NULL COMMENT '家属姓名',
  `relation` int(11) NOT NULL DEFAULT '1' COMMENT '1：与客户是子女关系\r2:与客户是夫妻关系\r3:与客户是同胞关系\r4:与客户是其他关系',
  `phone` varchar(11) NOT NULL COMMENT '家属联系电话',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `is_delete` int(11) NOT NULL DEFAULT '1' COMMENT '默认值为1,0表示已删除',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `customer` (`customer_id`),
  CONSTRAINT `customer` FOREIGN KEY (`customer_id`) REFERENCES `tb_info_cusomer_records` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of tb_info_family_records
-- ----------------------------
INSERT INTO `tb_info_family_records` VALUES ('1', '2', '王芳', '3', '13156562545', '2021-05-09 11:46:29', '2021-05-09 13:58:24', '1');
INSERT INTO `tb_info_family_records` VALUES ('2', '1', '黎明', '3', '13156562545', '2021-05-09 11:46:29', '2021-05-09 11:46:32', '1');
INSERT INTO `tb_info_family_records` VALUES ('3', '1', '刘兰兰', '2', '13156562545', '2021-05-09 11:46:29', '2021-05-09 11:46:32', '1');
INSERT INTO `tb_info_family_records` VALUES ('4', '1', '李小二', '4', '13156562545', '2021-05-09 11:46:29', '2021-05-09 11:46:32', '1');
INSERT INTO `tb_info_family_records` VALUES ('5', '5', '李保国', '4', '13156648525', '2021-05-09 13:36:22', '2021-05-09 13:36:22', '1');
INSERT INTO `tb_info_family_records` VALUES ('6', '6', '刘富强', '3', '15088456326', '2021-05-09 14:38:39', '2021-05-09 14:38:39', '1');

-- ----------------------------
-- Table structure for tb_info_other_records
-- ----------------------------
DROP TABLE IF EXISTS `tb_info_other_records`;
CREATE TABLE `tb_info_other_records` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '外来人员id',
  `name` varchar(10) NOT NULL COMMENT '外来人员姓名',
  `phone` varchar(11) NOT NULL COMMENT '外来人员电话',
  `access_time` datetime DEFAULT NULL COMMENT '到访时间',
  `leave_time` datetime DEFAULT NULL COMMENT '离开时间',
  `access_reason` varchar(100) DEFAULT NULL COMMENT '到访原因',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `is_delete` int(1) NOT NULL DEFAULT '1' COMMENT '1   未删除       0   已删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_info_other_records
-- ----------------------------
INSERT INTO `tb_info_other_records` VALUES ('1', '刘富贵', '13136565899', '2021-05-09 14:40:47', '2021-05-20 00:00:00', '看望家人', '2021-05-09 14:42:12', '2021-05-09 15:04:32', '1');
INSERT INTO `tb_info_other_records` VALUES ('2', '1', '1', '2021-05-09 14:57:13', null, '123', '2021-05-09 14:57:22', '2021-05-09 14:57:22', '0');
INSERT INTO `tb_info_other_records` VALUES ('3', '老牛', '13136565899', '2021-05-09 14:40:47', '2021-05-09 16:21:29', '看看老战友', '2021-05-09 14:42:12', '2021-05-09 16:21:34', '1');
INSERT INTO `tb_info_other_records` VALUES ('4', '王二', '15689895656', '2021-05-09 14:40:47', null, '就是来参观参观', '2021-05-09 14:42:12', '2021-05-09 14:42:14', '1');
INSERT INTO `tb_info_other_records` VALUES ('5', '王大锤', '18256588959', '2021-05-09 14:40:47', '2021-05-09 16:21:18', '维修空调', '2021-05-09 14:42:12', '2021-05-09 16:21:24', '1');
INSERT INTO `tb_info_other_records` VALUES ('6', '铁牛', '15692626545', '2021-05-09 14:40:47', null, '看望家人', '2021-05-09 14:42:12', '2021-05-09 14:42:14', '1');
INSERT INTO `tb_info_other_records` VALUES ('7', '刘国栋', '17708846502', '2021-05-09 16:07:18', '2021-05-09 17:07:22', '带点东西看看老战友', '2021-05-09 16:07:33', '2021-05-09 16:07:33', '1');

-- ----------------------------
-- Table structure for tb_info_out_records
-- ----------------------------
DROP TABLE IF EXISTS `tb_info_out_records`;
CREATE TABLE `tb_info_out_records` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '外出记录id',
  `customer_id` int(10) NOT NULL COMMENT '客户id 参照客户档案中的主键id',
  `with_who_name` varchar(10) DEFAULT NULL COMMENT '陪同人姓名',
  `with_who_phone` varchar(11) DEFAULT NULL COMMENT '陪同人电话',
  `relation` int(1) DEFAULT NULL COMMENT '与客户关系：      1 与客户子女关系   2 与客户夫妻关系   3 与客户同胞关系   4 与客户其他关系 ',
  `out_reason` varchar(100) DEFAULT NULL COMMENT '外出原因',
  `out_time` datetime NOT NULL COMMENT '外出时间',
  `ex_return_time` datetime NOT NULL COMMENT '预计返回时间',
  `real_return_time` datetime DEFAULT NULL COMMENT '实际返回时间',
  `state` int(1) NOT NULL DEFAULT '0' COMMENT '外出状态：      1外出已返回    0 外出未返回 ',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `is_delete` int(1) NOT NULL DEFAULT '1' COMMENT '1 未删除    0 已删除',
  PRIMARY KEY (`id`),
  KEY `customer4` (`customer_id`),
  CONSTRAINT `customer4` FOREIGN KEY (`customer_id`) REFERENCES `tb_info_cusomer_records` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_info_out_records
-- ----------------------------
INSERT INTO `tb_info_out_records` VALUES ('1', '1', '李小二', '17708845656', '1', '出去换个伙食', '2021-05-09 16:24:36', '2021-05-10 16:24:38', '2021-05-11 19:02:27', '1', '2021-05-09 16:24:54', '2021-05-11 19:02:37', '1');
INSERT INTO `tb_info_out_records` VALUES ('2', '2', '王二娃', '13156569292', '3', '出去吃饭', '2021-05-11 18:42:07', '2021-05-12 00:00:00', '2021-05-12 09:21:27', '1', '2021-05-11 18:42:36', '2021-05-12 09:23:04', '1');

-- ----------------------------
-- Table structure for tb_sys_employee
-- ----------------------------
DROP TABLE IF EXISTS `tb_sys_employee`;
CREATE TABLE `tb_sys_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '职工id: 主键自增长',
  `emp_name` varchar(10) NOT NULL COMMENT '职工姓名',
  `head_img_url` varchar(255) DEFAULT NULL COMMENT '职工头像',
  `emp_phone` varchar(11) NOT NULL COMMENT '职工电话',
  `emp_role_id` int(11) NOT NULL COMMENT '职工权限id：外键',
  `emp_address` varchar(50) DEFAULT NULL COMMENT '职工住址',
  `emp_identity` varchar(18) NOT NULL COMMENT '职工身份证,唯一值',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `is_delete` int(11) NOT NULL DEFAULT '1' COMMENT '默认值为1,0表示已删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idcard` (`emp_identity`) USING HASH,
  KEY `role2` (`emp_role_id`) USING HASH
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_sys_employee
-- ----------------------------
INSERT INTO `tb_sys_employee` VALUES ('1', '刘青松', null, '18145456666', '1', '不详', '412926197811011452', '2021-05-17 11:00:07', '2021-05-17 11:00:10', '1');
INSERT INTO `tb_sys_employee` VALUES ('2', '林伟翔', 'https://tyj666-oss.oss-cn-beijing.aliyuncs.com/2021-05-18/da5667ff-f52a-4ab7-8afa-5a7aa9a453a4_9d99fe36eaf79d70826c61a0fd610aef.jpeg', '18143999866', '2', '不详', '412926197411051452', '2021-05-17 11:00:07', '2021-05-18 08:37:46', '1');

-- ----------------------------
-- Table structure for tb_sys_role
-- ----------------------------
DROP TABLE IF EXISTS `tb_sys_role`;
CREATE TABLE `tb_sys_role` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '权限id',
  `role_name` varchar(10) NOT NULL COMMENT '权限名称',
  `role_level` int(1) NOT NULL DEFAULT '1' COMMENT '1  普通用户     2  在住客户    3  工作人员    4  系统人员',
  `role_desc` varchar(50) DEFAULT NULL COMMENT '描述权限',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `is_delete` int(1) NOT NULL DEFAULT '1' COMMENT '1  未删除    0  已删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_sys_role
-- ----------------------------
INSERT INTO `tb_sys_role` VALUES ('1', '采购员', '3', '负责后勤采购', '2021-05-17 10:58:35', '2021-05-17 10:58:38', '1');
INSERT INTO `tb_sys_role` VALUES ('2', '检修员', '3', '负责设备检修', '2021-05-17 10:58:35', '2021-05-17 10:58:38', '1');
INSERT INTO `tb_sys_role` VALUES ('3', '护理师', '3', '负责养护', '2021-05-18 08:24:39', '2021-05-18 08:24:39', '1');

-- ----------------------------
-- Table structure for tb_sys_user
-- ----------------------------
DROP TABLE IF EXISTS `tb_sys_user`;
CREATE TABLE `tb_sys_user` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '入住id',
  `username` varchar(16) NOT NULL COMMENT '用户名',
  `password` varchar(16) NOT NULL COMMENT '密码',
  `customer_id` int(10) DEFAULT NULL COMMENT '客户id',
  `role_id` int(10) DEFAULT NULL COMMENT '权限id   外键',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `is_delete` int(1) NOT NULL DEFAULT '1' COMMENT '1  未删除      0  已删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `account` (`username`) USING HASH,
  KEY `customer5` (`customer_id`),
  KEY `role` (`role_id`),
  CONSTRAINT `customer5` FOREIGN KEY (`customer_id`) REFERENCES `tb_info_cusomer_records` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_sys_user
-- ----------------------------

-- ----------------------------
-- Table structure for tb_user
-- ----------------------------
DROP TABLE IF EXISTS `tb_user`;
CREATE TABLE `tb_user` (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `mobile` varchar(20) NOT NULL COMMENT '手机号',
  `password` varchar(64) DEFAULT NULL COMMENT '密码',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='用户';

-- ----------------------------
-- Records of tb_user
-- ----------------------------
INSERT INTO `tb_user` VALUES ('1', 'mark', '13612345678', '8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918', '2017-03-23 22:37:41');

-- ----------------------------
-- Table structure for tb_ys_food_class
-- ----------------------------
DROP TABLE IF EXISTS `tb_ys_food_class`;
CREATE TABLE `tb_ys_food_class` (
  `classify_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '分类id',
  `classify_name` varchar(10) NOT NULL COMMENT '分类名称',
  `classify_desc` varchar(50) DEFAULT NULL COMMENT '分类描述',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `is_delete` int(255) NOT NULL DEFAULT '1' COMMENT '默认为1，0表示删除',
  PRIMARY KEY (`classify_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_ys_food_class
-- ----------------------------
INSERT INTO `tb_ys_food_class` VALUES ('1', '大荤', '各种各样的肉', '2021-04-29 19:39:44', '2021-05-17 08:52:12', '1');
INSERT INTO `tb_ys_food_class` VALUES ('2', '小荤', '肉不是很多', '2021-05-17 08:51:55', '2021-05-17 08:51:55', '1');

-- ----------------------------
-- Table structure for tb_ys_food_menu
-- ----------------------------
DROP TABLE IF EXISTS `tb_ys_food_menu`;
CREATE TABLE `tb_ys_food_menu` (
  `food_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '食品id',
  `food_name` varchar(255) NOT NULL COMMENT '食品名称',
  `classify_id` int(11) NOT NULL COMMENT '食品类别',
  `food_tag` varchar(50) NOT NULL COMMENT '食品标签',
  `food_price` double DEFAULT '0' COMMENT '食品价格',
  `food_qingzhen` int(11) NOT NULL DEFAULT '0' COMMENT '是否清真',
  `supply_week` int(11) NOT NULL DEFAULT '1' COMMENT '供应星期1-7（默认1）',
  `supply_kind` int(11) NOT NULL DEFAULT '1' COMMENT '供应类型1早餐2午餐3晚餐',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `is_delete` int(255) NOT NULL DEFAULT '1' COMMENT '默认为1，0表示删除',
  PRIMARY KEY (`food_id`),
  KEY `classify_id` (`classify_id`),
  CONSTRAINT `tb_ys_food_menu_ibfk_1` FOREIGN KEY (`classify_id`) REFERENCES `tb_ys_food_class` (`classify_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_ys_food_menu
-- ----------------------------
INSERT INTO `tb_ys_food_menu` VALUES ('1', '糖醋排骨', '1', '少糖', '18', '0', '1', '1', '2021-04-29 19:41:41', '2021-04-30 13:45:19', '1');
INSERT INTO `tb_ys_food_menu` VALUES ('2', '火爆小龙虾', '1', '超辣', '56', '0', '7', '3', '2021-04-29 19:46:56', '2021-04-29 20:46:56', '1');
INSERT INTO `tb_ys_food_menu` VALUES ('3', '火爆大头菜', '1', '正常辣', '15.62', '1', '3', '2', '2021-04-29 19:46:56', '2021-04-29 20:46:56', '1');
INSERT INTO `tb_ys_food_menu` VALUES ('4', '蒸饺', '1', '小荤', '13.5', '1', '4', '3', '2021-04-29 19:41:41', '2021-04-30 11:19:44', '1');
INSERT INTO `tb_ys_food_menu` VALUES ('5', '宫保鸡丁', '1', '甜辣', '25', '1', '5', '2', '2021-04-30 11:20:29', '2021-04-30 11:21:42', '1');
INSERT INTO `tb_ys_food_menu` VALUES ('6', '佛跳墙', '1', '清汤', '66', '1', '4', '2', '2021-04-30 11:22:26', '2021-05-06 14:00:48', '1');

-- ----------------------------
-- Table structure for tb_ys_food_plan
-- ----------------------------
DROP TABLE IF EXISTS `tb_ys_food_plan`;
CREATE TABLE `tb_ys_food_plan` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '膳食计划id：主键 自增',
  `customer_id` int(11) NOT NULL COMMENT '客户id：参照客户档案id',
  `food_id` int(11) NOT NULL COMMENT '饮食id：参照饮食菜单中id',
  `plan_day` int(11) NOT NULL DEFAULT '1' COMMENT '计划周期:(星期)1-7',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `is_delete` int(11) NOT NULL DEFAULT '1' COMMENT '默认为1，0表示删除',
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  KEY `food_id` (`food_id`),
  CONSTRAINT `tb_ys_food_plan_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `tb_info_cusomer_records` (`id`),
  CONSTRAINT `tb_ys_food_plan_ibfk_2` FOREIGN KEY (`food_id`) REFERENCES `tb_ys_food_menu` (`food_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_ys_food_plan
-- ----------------------------
INSERT INTO `tb_ys_food_plan` VALUES ('1', '1', '1', '2', '2021-05-14 15:48:23', '2021-05-17 09:48:46', '1');
INSERT INTO `tb_ys_food_plan` VALUES ('2', '2', '1', '2', '2021-05-17 10:17:53', '2021-05-17 10:17:53', '1');
