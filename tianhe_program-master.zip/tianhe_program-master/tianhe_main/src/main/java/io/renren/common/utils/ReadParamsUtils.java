package io.renren.common.utils;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import java.util.HashMap;
import java.util.Map;

/**
 * @Description:
 * @Author: tanyajun
 * @CreateTime: 2021/5/20
 * @Blog: https://tanyajun.top
 */
public class ReadParamsUtils<T>{
    public static final String  PAGE ="PAGE";
    public static final String  QW ="QW";
    public Page<T> getPage(Map<String, Object> params){
        long pageSize = Long.parseLong(params.get("limit") + "");
        long currPage = Long.parseLong(params.get("page") + "");
        Page<T> tPage = new Page<>(currPage,pageSize);
        return tPage;
    }
    public Map<String,Object> getPageAndQueryWrapper(Map<String, Object> params){
        Page<T> page = this.getPage(params);
        QueryWrapper<T> wrapper = new QueryWrapper<>();
        HashMap<String, Object> map = new HashMap<>();
        map.put(PAGE,page);
        map.put(QW,wrapper);
        return map;
    }
}
