package io.renren.common.utils;

/**
 * @Description:
 * @Author: tanyajun
 * @CreateTime: 2021/5/7
 * @Blog: https://tanyajun.top
 */
public class RegexpUtils {
    public static final String PHONE="^((13[0-9])|(14[5-8])|(15([0-3]|[5-9]))|(16[6])|(17[0|4|6|7|8])|(18[0-9])|(19[8-9]))\\d{8}$";
    public static final String BLOOD_TYPE="^AB|A|B|O$";
    public static final String IDNETITY="^(\\d{6})(19|20|21)(\\d{2})(1[0-2]|0[1-9])(0[1-9]|[1-2][0-9]|3[0-1])(\\d{3})(\\d|X|x)?$";
}
