package io.renren.modules.customer.controller;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import io.renren.modules.cw.entity.CwBedEntity;
import io.renren.modules.cw.service.CwBedService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.renren.modules.customer.entity.InfoCheckInEntity;
import io.renren.modules.customer.service.InfoCheckInService;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.R;



/**
 * 
 *
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-04-30 13:52:26
 */
@RestController
@RequestMapping("customer/infocheckin")
public class InfoCheckInController {
    @Autowired
    private InfoCheckInService infoCheckInService;
    @Autowired
    private CwBedService cwBedService;
    /**
     * 列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("customer:infocheckin:list")
    public R list(@RequestParam Map<String, Object> params){
        //PageUtils page = infoCheckInService.queryPage(params);
        PageUtils page = infoCheckInService.selectCheckInListVo(params);
        return R.ok().put("page", page);
    }

    @RequestMapping("/isCheckIn")
    public R isCheckIn(@RequestParam Map<String, Object> params){
        if(params.get("customerId")==null){
            return R.error("customerId未获取到");
        }
        QueryWrapper<InfoCheckInEntity> wrapper = new QueryWrapper<>();
        // SELECT * FROM tb_info_check_in where customer_id=? and valid_state=1 and is_delete=1
        wrapper.eq("customer_id",params.get("customerId")).eq("valid_state",1);
        List<InfoCheckInEntity> list = infoCheckInService.getBaseMapper().selectList(wrapper);
        if(list==null||list.size()==0){
            return R.ok().put("isCheckIn",false);
        }
        return R.ok().put("isCheckIn",true).put("bean",list.get(0));
    }

    /**
     * 信息
     */
    @RequestMapping("/info/{id}")
    @RequiresPermissions("customer:infocheckin:info")
    public R info(@PathVariable("id") Integer id){
		InfoCheckInEntity infoCheckIn = infoCheckInService.getById(id);

        return R.ok().put("infoCheckIn", infoCheckIn);
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    @RequiresPermissions("customer:infocheckin:save")
    @Transactional(rollbackFor = Exception.class)
    public R save(@RequestBody InfoCheckInEntity infoCheckIn){
        boolean save = infoCheckInService.save(infoCheckIn);
        if(save){
            // 修改对应床位上的id
            CwBedEntity cwBedEntity = cwBedService.getById(infoCheckIn.getBedId());
            cwBedEntity.setCustomerId(infoCheckIn.getCustomerId());
            cwBedEntity.setUpdateTime(null);
            cwBedService.updateById(cwBedEntity);
        }
        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    @RequiresPermissions("customer:infocheckin:update")
    @Transactional(rollbackFor=Exception.class)
    public R update(@RequestBody InfoCheckInEntity infoCheckIn){
        // 先获取原记录
        InfoCheckInEntity infoCheckInEntity = infoCheckInService.getById(infoCheckIn.getId());
        CwBedEntity cwBedEntity = cwBedService.getById(infoCheckInEntity.getBedId());
        cwBedEntity.setUpdateTime(new Date());
        UpdateWrapper<CwBedEntity> wrapper = new UpdateWrapper<>();
        wrapper.set("customer_id",null)
                .set("update_time",cwBedEntity.getUpdateTime())
                .eq("bed_id",cwBedEntity.getBedId());
        cwBedService.update(wrapper);
        boolean b = infoCheckInService.updateById(infoCheckIn);
        if(b){
            // 切换客户的住房信息
            CwBedEntity entity = cwBedService.getById(infoCheckIn.getBedId());
            entity.setUpdateTime(null);
            entity.setCustomerId(infoCheckIn.getCustomerId());
            cwBedService.updateById(entity);
        }

        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @RequiresPermissions("customer:infocheckin:delete")
    public R delete(@RequestBody Integer[] ids){
		infoCheckInService.removeByIds(Arrays.asList(ids));

        return R.ok();
    }

}
