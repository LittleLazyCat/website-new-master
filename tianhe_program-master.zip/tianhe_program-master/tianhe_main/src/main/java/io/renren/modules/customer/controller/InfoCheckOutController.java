package io.renren.modules.customer.controller;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import io.renren.modules.customer.entity.InfoCheckInEntity;
import io.renren.modules.customer.entity.vo.CheckOutCustomerVo;
import io.renren.modules.customer.service.InfoCheckInService;
import io.renren.modules.cw.entity.CwBedEntity;
import io.renren.modules.cw.service.CwBedService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.renren.modules.customer.entity.InfoCheckOutEntity;
import io.renren.modules.customer.service.InfoCheckOutService;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.R;



/**
 * 
 *
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-04-30 13:52:26
 */
@RestController
@RequestMapping("customer/infocheckout")
public class InfoCheckOutController {
    @Autowired
    private InfoCheckOutService infoCheckOutService;
    @Autowired
    private InfoCheckInService infoCheckInService;
    @Autowired
    private CwBedService cwBedService;
    /**
     * 列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("customer:infocheckout:list")
    public R list(@RequestParam Map<String, Object> params){
        //PageUtils page = infoCheckOutService.queryPage(params);
        PageUtils page = infoCheckOutService.selectPageVo(params);

        return R.ok().put("page", page);
    }


    /**
     * 信息
     */
    @RequestMapping("/info/{id}")
    @RequiresPermissions("customer:infocheckout:info")
    public R info(@PathVariable("id") Integer id){
		InfoCheckOutEntity infoCheckOut = infoCheckOutService.getById(id);

        return R.ok().put("infoCheckOut", infoCheckOut);
    }

    /**
     * 保存客户退住信息
     *  注意：应该修改入住表中的状态、置床位表中的该床位的customer_id为null
     *  这是一组事务
     */
    @RequestMapping("/save")
    @RequiresPermissions("customer:infocheckout:save")
    @Transactional(rollbackFor = Exception.class)
    public R save(@RequestBody CheckOutCustomerVo infoCheckOut){
        // 保存退住信息
        boolean flag = infoCheckOutService.save(infoCheckOut);
        if(flag){
            // 设置入住状态=0
            UpdateWrapper<InfoCheckInEntity> wrapper = new UpdateWrapper<>();
            wrapper.set("valid_state",0)
                    .set("update_time",new Date())
                    .eq("id",infoCheckOut.getCkiId());
            flag=infoCheckInService.update(wrapper)&&flag;
            // 设置对应床位上的客户id为null
            UpdateWrapper<CwBedEntity> cwWrapper = new UpdateWrapper<>();
            cwWrapper.set("customer_id",null)
                    .set("update_time",new Date())
                    .eq("bed_id",infoCheckOut.getBedId());
            flag=cwBedService.update(cwWrapper)&&flag;
        }

        return flag?R.ok():R.error();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    @RequiresPermissions("customer:infocheckout:update")
    public R update(@RequestBody InfoCheckOutEntity infoCheckOut){
		infoCheckOutService.updateById(infoCheckOut);

        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @RequiresPermissions("customer:infocheckout:delete")
    public R delete(@RequestBody Integer[] ids){
		infoCheckOutService.removeByIds(Arrays.asList(ids));

        return R.ok();
    }

    /**
     * 获取在住客户的基本信息
      * @return
     */
    @RequestMapping("/getCheckedCustomer")
    public R getCheckedCustomer(){
        List<CheckOutCustomerVo> list = infoCheckOutService.getCheckedCustomer();
        return R.ok().put("data",list);
    }
}
