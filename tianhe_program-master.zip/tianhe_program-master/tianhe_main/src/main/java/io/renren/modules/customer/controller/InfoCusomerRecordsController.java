package io.renren.modules.customer.controller;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.conditions.query.QueryChainWrapper;
import io.renren.common.validator.ValidatorUtils;
import io.renren.common.validator.group.AddGroup;
import io.renren.common.validator.group.UpdateGroup;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.renren.modules.customer.entity.InfoCusomerRecordsEntity;
import io.renren.modules.customer.service.InfoCusomerRecordsService;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.R;



/**
 * 
 *
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-04-30 13:52:26
 */
@RestController
@RequestMapping("customer/infocusomerrecords")
public class InfoCusomerRecordsController {
    @Autowired
    private InfoCusomerRecordsService infoCusomerRecordsService;

    /**
     * 列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("customer:infocusomerrecords:list")
    public R list(@RequestParam Map<String, Object> params){
        PageUtils page = infoCusomerRecordsService.queryPage(params);

        return R.ok().put("page", page);
    }

    /**
     * 列表
     */
    @RequestMapping("/customerlist")
    public R customerList(){
        List<InfoCusomerRecordsEntity> list = infoCusomerRecordsService.list();
        return R.ok().put("data", list);
    }


    /**
     * 信息
     */
    @RequestMapping("/info/{id}")
    @RequiresPermissions("customer:infocusomerrecords:info")
    public R info(@PathVariable("id") Integer id){
		InfoCusomerRecordsEntity infoCusomerRecords = infoCusomerRecordsService.getById(id);
        return R.ok().put("infoCusomerRecords", infoCusomerRecords);
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    @RequiresPermissions("customer:infocusomerrecords:save")
    public R save(@RequestBody @Validated(value = {AddGroup.class}) InfoCusomerRecordsEntity infoCusomerRecords){
//        ValidatorUtils.validateEntity(infoCusomerRecords, AddGroup.class);
		infoCusomerRecordsService.save(infoCusomerRecords);

        return R.ok();
    }
    /**
     * 保存
     */
    @RequestMapping("/addCustomer")
    public R addCustomer(@RequestBody @Validated(value = {AddGroup.class}) InfoCusomerRecordsEntity infoCusomerRecords){
        int insert = infoCusomerRecordsService.getBaseMapper().insert(infoCusomerRecords);
        if(insert!=1){
            return R.error("插入失败").put("errorBean",infoCusomerRecords);
        }
        return R.ok().put("customerId",infoCusomerRecords.getId());
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    @RequiresPermissions("customer:infocusomerrecords:update")
    public R update(@RequestBody @Validated(value = {UpdateGroup.class}) InfoCusomerRecordsEntity infoCusomerRecords){
		infoCusomerRecordsService.updateById(infoCusomerRecords);

        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @RequiresPermissions("customer:infocusomerrecords:delete")
    public R delete(@RequestBody Integer[] ids){
		infoCusomerRecordsService.removeByIds(Arrays.asList(ids));

        return R.ok();
    }

}
