package io.renren.modules.customer.controller;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import io.renren.modules.customer.entity.RecommendReason;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.renren.modules.customer.entity.InfoFamilyRecordsEntity;
import io.renren.modules.customer.service.InfoFamilyRecordsService;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.R;



/**
 * 
 *
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-04-30 13:52:26
 */
@RestController
@RequestMapping("customer/infofamilyrecords")
public class InfoFamilyRecordsController {
    @Autowired
    private InfoFamilyRecordsService infoFamilyRecordsService;

    /**
     * 列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("customer:infofamilyrecords:list")
    public R list(@RequestParam Map<String, Object> params){
        //PageUtils page = infoFamilyRecordsService.queryPage(params);
        PageUtils page = infoFamilyRecordsService.selectPageVo(params);

        return R.ok().put("page", page);
    }


    /**
     * 信息
     */
    @RequestMapping("/info/{id}")
    @RequiresPermissions("customer:infofamilyrecords:info")
    public R info(@PathVariable("id") Integer id){
		InfoFamilyRecordsEntity infoFamilyRecords = infoFamilyRecordsService.getById(id);

        return R.ok().put("infoFamilyRecords", infoFamilyRecords);
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    @RequiresPermissions("customer:infofamilyrecords:save")
    public R save(@RequestBody InfoFamilyRecordsEntity infoFamilyRecords){
		infoFamilyRecordsService.save(infoFamilyRecords);

        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    @RequiresPermissions("customer:infofamilyrecords:update")
    public R update(@RequestBody InfoFamilyRecordsEntity infoFamilyRecords){
		infoFamilyRecordsService.updateById(infoFamilyRecords);

        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @RequiresPermissions("customer:infofamilyrecords:delete")
    public R delete(@RequestBody Integer[] ids){
		infoFamilyRecordsService.removeByIds(Arrays.asList(ids));

        return R.ok();
    }

    @RequestMapping("/getRecommendReason")
    public R getRecommendReason(){
        List<RecommendReason> list=infoFamilyRecordsService.getRecommendReason();
        return R.ok().put("data",list);
    }
}
