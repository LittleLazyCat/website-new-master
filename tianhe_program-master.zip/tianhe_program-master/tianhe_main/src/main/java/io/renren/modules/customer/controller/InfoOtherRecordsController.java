package io.renren.modules.customer.controller;

import java.util.Arrays;
import java.util.Map;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.renren.modules.customer.entity.InfoOtherRecordsEntity;
import io.renren.modules.customer.service.InfoOtherRecordsService;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.R;



/**
 * 
 *
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-04-30 13:52:26
 */
@RestController
@RequestMapping("customer/infootherrecords")
public class InfoOtherRecordsController {
    @Autowired
    private InfoOtherRecordsService infoOtherRecordsService;

    /**
     * 列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("customer:infootherrecords:list")
    public R list(@RequestParam Map<String, Object> params){
        PageUtils page = infoOtherRecordsService.queryPage(params);

        return R.ok().put("page", page);
    }


    /**
     * 信息
     */
    @RequestMapping("/info/{id}")
    @RequiresPermissions("customer:infootherrecords:info")
    public R info(@PathVariable("id") Integer id){
		InfoOtherRecordsEntity infoOtherRecords = infoOtherRecordsService.getById(id);

        return R.ok().put("infoOtherRecords", infoOtherRecords);
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    @RequiresPermissions("customer:infootherrecords:save")
    public R save(@RequestBody InfoOtherRecordsEntity infoOtherRecords){
		infoOtherRecordsService.save(infoOtherRecords);

        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    @RequiresPermissions("customer:infootherrecords:update")
    public R update(@RequestBody InfoOtherRecordsEntity infoOtherRecords){
		infoOtherRecordsService.updateById(infoOtherRecords);

        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @RequiresPermissions("customer:infootherrecords:delete")
    public R delete(@RequestBody Integer[] ids){
		infoOtherRecordsService.removeByIds(Arrays.asList(ids));

        return R.ok();
    }

}
