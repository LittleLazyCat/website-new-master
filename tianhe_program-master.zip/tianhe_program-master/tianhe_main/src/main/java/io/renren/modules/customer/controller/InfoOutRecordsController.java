package io.renren.modules.customer.controller;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import io.renren.modules.customer.entity.vo.CanGoOutVo;
import io.renren.modules.customer.entity.vo.InfoOutEntityVo;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.renren.modules.customer.entity.InfoOutRecordsEntity;
import io.renren.modules.customer.service.InfoOutRecordsService;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.R;



/**
 * 
 *
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-04-30 13:52:26
 */
@RestController
@RequestMapping("customer/infooutrecords")
public class InfoOutRecordsController {
    @Autowired
    private InfoOutRecordsService infoOutRecordsService;

    /**
     * 列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("customer:infooutrecords:list")
    public R list(@RequestParam Map<String, Object> params){
        //PageUtils page = infoOutRecordsService.queryPage(params);
        PageUtils page = infoOutRecordsService.selectPageVo(params);

        return R.ok().put("page", page);
    }


    /**
     * 信息
     */
    @RequestMapping("/info/{id}")
    @RequiresPermissions("customer:infooutrecords:info")
    public R info(@PathVariable("id") Integer id){
		//InfoOutRecordsEntity infoOutRecords = infoOutRecordsService.getById(id);
        InfoOutEntityVo infoOutEntityVo = infoOutRecordsService.selectVoById(id);
        return R.ok().put("infoOutRecords", infoOutEntityVo);
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    @RequiresPermissions("customer:infooutrecords:save")
    public R save(@RequestBody InfoOutRecordsEntity infoOutRecords){
		infoOutRecordsService.save(infoOutRecords);

        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    @RequiresPermissions("customer:infooutrecords:update")
    public R update(@RequestBody InfoOutRecordsEntity infoOutRecords){
		//infoOutRecordsService.updateById(infoOutRecords);
        UpdateWrapper<InfoOutRecordsEntity> wrapper = new UpdateWrapper<>();
        if(infoOutRecords.getRealReturnTime()==null){
            wrapper.set("real_return_time",null);
        }
        wrapper.eq("id",infoOutRecords.getId());
        infoOutRecordsService.update(infoOutRecords,wrapper);
        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @RequiresPermissions("customer:infooutrecords:delete")
    public R delete(@RequestBody Integer[] ids){
		infoOutRecordsService.removeByIds(Arrays.asList(ids));

        return R.ok();
    }
    @RequestMapping("/getCanGoOutList")
    public R getCanGoOutList(){
        HashMap<String, Object> map = new HashMap<>();
        List<CanGoOutVo> list = infoOutRecordsService.getCanGoOutList();
        map.put("list",list);
        map.put("total",list.size());
        return R.ok().put("data",map);
    }
}
