package io.renren.modules.customer.dao;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.renren.modules.customer.entity.InfoCheckInEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import io.renren.modules.customer.entity.vo.InfoCheckInEntityVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 
 * 
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-04-30 13:52:26
 */
@Mapper
public interface InfoCheckInDao extends BaseMapper<InfoCheckInEntity> {
    IPage<InfoCheckInEntityVo> selectCheckInListVo(Page<InfoCheckInEntityVo>page, @Param(Constants.WRAPPER)QueryWrapper<InfoCheckInEntityVo>wrapper);
}
