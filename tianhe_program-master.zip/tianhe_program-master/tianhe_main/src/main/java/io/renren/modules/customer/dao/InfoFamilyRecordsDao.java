package io.renren.modules.customer.dao;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.renren.modules.customer.entity.InfoFamilyRecordsEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import io.renren.modules.customer.entity.RecommendReason;
import io.renren.modules.customer.entity.vo.InfoFamilyRecordsEntityVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * 
 * 
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-04-30 13:52:26
 */
@Mapper
public interface InfoFamilyRecordsDao extends BaseMapper<InfoFamilyRecordsEntity> {

    IPage<InfoFamilyRecordsEntityVo> selectPageVo(Page<InfoFamilyRecordsEntityVo> page, @Param(Constants.WRAPPER) QueryWrapper<InfoFamilyRecordsEntityVo> wrapper);

    @Select("SELECT\n" +
            "access_reason\n" +
            "FROM tb_info_other_records\n" +
            "WHERE is_delete=1 and access_reason IS NOT NULL GROUP BY access_reason ORDER BY COUNT(access_reason) DESC LIMIT 0,10 ")
    List<RecommendReason> getAccesReson();
}
