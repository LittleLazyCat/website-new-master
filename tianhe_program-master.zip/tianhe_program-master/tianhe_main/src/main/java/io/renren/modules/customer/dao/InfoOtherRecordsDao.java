package io.renren.modules.customer.dao;

import io.renren.modules.customer.entity.InfoOtherRecordsEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 
 * 
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-04-30 13:52:26
 */
@Mapper
public interface InfoOtherRecordsDao extends BaseMapper<InfoOtherRecordsEntity> {
	
}
