package io.renren.modules.customer.dao;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.renren.modules.customer.entity.InfoOutRecordsEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import io.renren.modules.customer.entity.vo.CanGoOutVo;
import io.renren.modules.customer.entity.vo.InfoOutEntityVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 
 * 
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-04-30 13:52:26
 */
@Mapper
public interface InfoOutRecordsDao extends BaseMapper<InfoOutRecordsEntity> {

	IPage<InfoOutEntityVo> selectPageVo(Page<InfoOutEntityVo> page, @Param(Constants.WRAPPER)QueryWrapper<InfoOutEntityVo> wrapper);

	@Select("select ci.id cki_id,ci.customer_id,cr.name customer_name,cr.identity_number,cr.phone customer_phone \n" +
			"FROM tb_info_check_in ci,tb_info_cusomer_records cr\n" +
			"where ci.is_delete=1 and ci.valid_state=1 and cr.id=ci.customer_id \n" +
			"and ci.customer_id not in (select customer_id from tb_info_out_records ore where ore.is_delete=1 and ore.state = 0)")
	List<CanGoOutVo> getCanGoOutList();

	InfoOutEntityVo selectVoById(Integer id);
	List<InfoOutEntityVo> selectVoByWrapper(@Param(Constants.WRAPPER) Wrapper<InfoOutEntityVo> ew);
}
