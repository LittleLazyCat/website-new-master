package io.renren.modules.customer.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 
 * 
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-04-30 13:52:26
 */
@Data
@TableName("tb_info_check_in")
public class InfoCheckInEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 入住id: 主键自增长
	 */
	@TableId
	private Integer id;
	/**
	 * 客户id：参照客户档案中的id
	 */
	private Integer customerId;
	/**
	 * 床位id:参照床位表中的主键id
	 */
	private Integer bedId;
	/**
	 * 服务开始时间
	 */
	private Date startTime;
	/**
	 * 服务结束时间
	 */
	private Date endTime;
	/**
	 * 客户状态: 默认值=1
				1：在住客户
				0：退住客户
	 */
	private Integer validState;
	/**
	 * 创建时间
	 */
	@TableField(fill = FieldFill.INSERT)
	private Date createTime;
	/**
	 * 更新时间
	 */
	@TableField(fill = FieldFill.INSERT_UPDATE)
	private Date updateTime;
	/**
	 * 默认值为1,0表示已删除
	 */
	@TableLogic
	private Integer isDelete;

}
