package io.renren.modules.customer.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 
 * 
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-04-30 13:52:26
 */
@Data
@TableName("tb_info_check_out")
public class InfoCheckOutEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 退住id：主键自增长
	 */
	@TableId
	private Integer id;
	/**
	 * 入住id: 参照入住登记表中的主键id
	 */
	private Integer ckiId;
	/**
	 * 退住类型：1：合约到期 2：主动退住 3：其他
	 */
	private Integer checkOutType;
	/**
	 * 退住时间
	 */
	private Date checkOutTime;
	/**
	 * 退住原因
	 */
	private String checkOutReason;
	/**
	 * 创建时间
	 */
	@TableField(fill = FieldFill.INSERT)
	private Date createTime;
	/**
	 * 更新时间
	 */
	@TableField(fill = FieldFill.INSERT_UPDATE)
	private Date updateTime;
	/**
	 * 默认值为1,0表示已删除
	 */
	@TableLogic
	private Integer isDelete;

}
