package io.renren.modules.customer.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import java.util.Date;

import io.renren.common.utils.RegexpUtils;
import io.renren.common.validator.group.AddGroup;
import io.renren.common.validator.group.UpdateGroup;
import lombok.Data;

import javax.validation.constraints.Pattern;

/**
 * 
 * 
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-04-30 13:52:26
 */
@Data
@TableName("tb_info_cusomer_records")
public class InfoCusomerRecordsEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 客户id：主键自增长
	 */
	@TableId
	private Integer id;
	/**
	 * 客户姓名
	 */
	private String name;
	/**
	 * 客户头像
	 */
	private String headImgUrl;
	/**
	 * 客户性别: 1为男性,0为女性
	 */
	private Integer gender;
	/**
	 * 身份证号码，唯一值
	 */
	@Pattern(regexp = RegexpUtils.IDNETITY,groups = {AddGroup.class, UpdateGroup.class},message = "身份证号格式有问题")
	private String identityNumber;
	/**
	 * 出生日期
	 */
	private Date birthday;
	/**
	 * 手机号码
	 */
	@Pattern(regexp = RegexpUtils.PHONE,groups = {AddGroup.class, UpdateGroup.class},message = "手机号格式有问题")
	private String phone;
	/**
	 * 血型: A/B/AB/O
	 */
	@Pattern(regexp = RegexpUtils.BLOOD_TYPE,groups = {AddGroup.class, UpdateGroup.class},message = "血型只能是A/B/AB/O型")
	private String bloodType;
	/**
	 * 家庭地址
	 */
	private String address;
	/**
	 * 创建时间
	 */
	@TableField(fill = FieldFill.INSERT)
	private Date createTime;
	/**
	 * 更新时间
	 */
	@TableField(fill = FieldFill.INSERT_UPDATE)
	private Date updateTime;
	/**
	 * 默认值为1,0表示已删除
	 */
	@TableLogic
	private Integer isDelete;

}
