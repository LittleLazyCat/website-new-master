package io.renren.modules.customer.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 
 * 
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-04-30 13:52:26
 */
@Data
@TableName("tb_info_family_records")
public class InfoFamilyRecordsEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 家属id：主键自增
	 */
	@TableId
	private Integer id;
	/**
	 * 客户id: 参照客户档案中的主键id
	 */
	private Integer customerId;
	/**
	 * 家属姓名
	 */
	private String name;
	/**
	 * 1：与客户是子女关系
2:与客户是夫妻关系
3:与客户是同胞关系
4:与客户是其他关系
	 */
	private Integer relation;
	/**
	 * 家属联系电话
	 */
	private String phone;
	/**
	 * 创建时间
	 */
	@TableField(fill = FieldFill.INSERT)
	private Date createTime;
	/**
	 * 更新时间
	 */
	@TableField(fill = FieldFill.INSERT_UPDATE)
	private Date updateTime;
	/**
	 * 默认值为1,0表示已删除
	 */
	@TableLogic
	private Integer isDelete;

}
