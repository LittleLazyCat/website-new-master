package io.renren.modules.customer.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 
 * 
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-04-30 13:52:26
 */
@Data
@TableName("tb_info_other_records")
public class InfoOtherRecordsEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 外来人员id
	 */
	@TableId
	private Integer id;
	/**
	 * 外来人员姓名
	 */
	private String name;
	/**
	 * 外来人员电话
	 */
	private String phone;
	/**
	 * 到访时间
	 */
	private Date accessTime;
	/**
	 * 离开时间
	 */
	private Date leaveTime;
	/**
	 * 到访原因
	 */
	private String accessReason;
	/**
	 * 创建时间
	 */
	@TableField(fill = FieldFill.INSERT)
	private Date createTime;
	/**
	 * 更新时间
	 */
	@TableField(fill = FieldFill.INSERT_UPDATE)
	private Date updateTime;
	/**
	 * 1   未删除      
0   已删除
	 */
	@TableLogic
	private Integer isDelete;

}
