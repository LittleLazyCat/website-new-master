package io.renren.modules.customer.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 
 * 
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-04-30 13:52:26
 */
@Data
@TableName("tb_info_out_records")
public class InfoOutRecordsEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 外出记录id
	 */
	@TableId
	private Integer id;
	/**
	 * 客户id 参照客户档案中的主键id
	 */
	private Integer customerId;
	/**
	 * 陪同人姓名
	 */
	private String withWhoName;
	/**
	 * 陪同人电话
	 */
	private String withWhoPhone;
	/**
	 * 与客户关系：     
1 与客户子女关系  
2 与客户夫妻关系  
3 与客户同胞关系  
4 与客户其他关系

	 */
	private Integer relation;
	/**
	 * 外出原因
	 */
	private String outReason;
	/**
	 * 外出时间
	 */
	private Date outTime;
	/**
	 * 预计返回时间
	 */
	private Date exReturnTime;
	/**
	 * 实际返回时间
	 */
	private Date realReturnTime;
	/**
	 * 外出状态：     
2 外出已返回   
1 外出未返回    
0 取消外出
	 */
	private Integer state;
	/**
	 * 创建时间
	 */
	@TableField(fill = FieldFill.INSERT)
	private Date createTime;
	/**
	 * 更新时间
	 */
	@TableField(fill = FieldFill.INSERT_UPDATE)
	private Date updateTime;
	/**
	 * 1 未删除   
0 已删除
	 */
	@TableLogic
	private Integer isDelete;

}
