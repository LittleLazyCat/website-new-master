package io.renren.modules.customer.entity;

import lombok.Data;

/**
 * @Description:
 * @Author: tanyajun
 * @CreateTime: 2021/5/9
 * @Blog: https://tanyajun.top
 */
@Data
public class RecommendReason {
    private String accessReason;
}
