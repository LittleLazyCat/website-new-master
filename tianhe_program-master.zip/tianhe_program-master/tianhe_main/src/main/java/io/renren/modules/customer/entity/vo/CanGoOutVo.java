package io.renren.modules.customer.entity.vo;

import lombok.Data;

/**
 * @Description:
 * @Author: tanyajun
 * @CreateTime: 2021/5/11
 * @Blog: https://tanyajun.top
 */
@Data
public class CanGoOutVo {
    private Integer ckiId;
    private Integer customerId;
    private String customerName;
    private String identityNumber;
    private String customerPhone;
}
