package io.renren.modules.customer.entity.vo;

import io.renren.modules.customer.entity.InfoCheckOutEntity;
import lombok.Data;

import java.util.Date;

/**
 * @Description:
 * @Author: tanyajun
 * @CreateTime: 2021/5/8
 * @Blog: https://tanyajun.top
 */
@Data
public class CheckOutCustomerVo extends InfoCheckOutEntity {
    private Integer bedId; // 入住记录中的床位id
    private Integer customerId; // 入住记录中的客户id
    private String customerName; // 该客户的姓名
    private String identityNumber; // 该客户的身份证号码
    private String headImgUrl; // 该客户的身份证号码

}
