package io.renren.modules.customer.entity.vo;

import io.renren.modules.customer.entity.InfoCheckInEntity;
import lombok.Data;

/**
 * @Description:
 * @Author: tanyajun
 * @CreateTime: 2021/5/6
 * @Blog: https://tanyajun.top
 */
@Data
public class InfoCheckInEntityVo extends InfoCheckInEntity {
    private String customerName;
    private String customerIdentity;
    private String customerPhone;
}
