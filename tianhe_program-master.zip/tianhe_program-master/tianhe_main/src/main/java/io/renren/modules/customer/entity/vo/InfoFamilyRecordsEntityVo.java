package io.renren.modules.customer.entity.vo;

import io.renren.modules.customer.entity.InfoFamilyRecordsEntity;
import lombok.Data;

import java.io.Serializable;

/**
 * @Description:
 * @Author: tanyajun
 * @CreateTime: 2021/5/9
 * @Blog: https://tanyajun.top
 */
@Data
public class InfoFamilyRecordsEntityVo extends InfoFamilyRecordsEntity implements Serializable {
    private static final long serialVersionUID = 2L;
    private String customerName;
    private String identityNumber;
}
