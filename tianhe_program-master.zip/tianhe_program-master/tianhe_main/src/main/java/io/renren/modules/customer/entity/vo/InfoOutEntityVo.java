package io.renren.modules.customer.entity.vo;

import io.renren.modules.customer.entity.InfoOutRecordsEntity;
import lombok.Data;

/**
 * @Description:
 * @Author: tanyajun
 * @CreateTime: 2021/5/9
 * @Blog: https://tanyajun.top
 */
@Data
public class InfoOutEntityVo extends InfoOutRecordsEntity {
    private String customerName;
    private String identityNumber;
}
