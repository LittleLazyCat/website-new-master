package io.renren.modules.customer.service;

import com.baomidou.mybatisplus.extension.service.IService;
import io.renren.common.utils.PageUtils;
import io.renren.modules.customer.entity.InfoCheckInEntity;

import java.util.Map;

/**
 * 
 *
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-04-30 13:52:26
 */
public interface InfoCheckInService extends IService<InfoCheckInEntity> {

    PageUtils queryPage(Map<String, Object> params);

    PageUtils selectCheckInListVo(Map<String, Object> params);
}

