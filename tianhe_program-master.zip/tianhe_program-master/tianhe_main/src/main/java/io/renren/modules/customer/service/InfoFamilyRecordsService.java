package io.renren.modules.customer.service;

import com.baomidou.mybatisplus.extension.service.IService;
import io.renren.common.utils.PageUtils;
import io.renren.modules.customer.entity.InfoFamilyRecordsEntity;
import io.renren.modules.customer.entity.RecommendReason;

import java.util.List;
import java.util.Map;

/**
 * 
 *
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-04-30 13:52:26
 */
public interface InfoFamilyRecordsService extends IService<InfoFamilyRecordsEntity> {

    PageUtils queryPage(Map<String, Object> params);
    PageUtils selectPageVo(Map<String, Object> params);

    List<RecommendReason> getRecommendReason();
}

