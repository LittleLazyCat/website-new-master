package io.renren.modules.customer.service;

import com.baomidou.mybatisplus.extension.service.IService;
import io.renren.common.utils.PageUtils;
import io.renren.modules.customer.entity.InfoOutRecordsEntity;
import io.renren.modules.customer.entity.vo.CanGoOutVo;
import io.renren.modules.customer.entity.vo.InfoOutEntityVo;

import java.util.List;
import java.util.Map;

/**
 * 
 *
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-04-30 13:52:26
 */
public interface InfoOutRecordsService extends IService<InfoOutRecordsEntity> {

    PageUtils queryPage(Map<String, Object> params);
    PageUtils selectPageVo(Map<String, Object> params);
    List<CanGoOutVo> getCanGoOutList();
    InfoOutEntityVo selectVoById(Integer id);
}

