package io.renren.modules.customer.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.renren.modules.customer.entity.vo.InfoCheckInEntityVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.Query;

import io.renren.modules.customer.dao.InfoCheckInDao;
import io.renren.modules.customer.entity.InfoCheckInEntity;
import io.renren.modules.customer.service.InfoCheckInService;


@Service("infoCheckInService")
public class InfoCheckInServiceImpl extends ServiceImpl<InfoCheckInDao, InfoCheckInEntity> implements InfoCheckInService {
    @Autowired
    InfoCheckInDao infoCheckInDao;
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        IPage<InfoCheckInEntity> page = this.page(
                new Query<InfoCheckInEntity>().getPage(params),
                new QueryWrapper<InfoCheckInEntity>()
        );

        return new PageUtils(page);
    }

    @Override
    public PageUtils selectCheckInListVo(Map<String, Object> params) {
        Integer pageSize = Integer.parseInt(params.get("limit")+"");
        Integer currPage = Integer.parseInt(params.get("page")+"");
        Page<InfoCheckInEntityVo> page = new Page<>(currPage,pageSize);
        QueryWrapper<InfoCheckInEntityVo> wrapper = new QueryWrapper<>();
        wrapper.eq("ci.is_delete",1);
        Object key = params.get("key");
        if(key!=null && key.toString().trim().length()>0){
            wrapper.in("ci.id",key.toString().trim().split(",|，|\\s"));
        }
        return new PageUtils(infoCheckInDao.selectCheckInListVo(page, wrapper));
    }

}