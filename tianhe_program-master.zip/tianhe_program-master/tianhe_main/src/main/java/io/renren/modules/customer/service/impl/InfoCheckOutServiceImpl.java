package io.renren.modules.customer.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.renren.modules.customer.entity.vo.CheckOutCustomerVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.Query;

import io.renren.modules.customer.dao.InfoCheckOutDao;
import io.renren.modules.customer.entity.InfoCheckOutEntity;
import io.renren.modules.customer.service.InfoCheckOutService;


@Service("infoCheckOutService")
public class InfoCheckOutServiceImpl extends ServiceImpl<InfoCheckOutDao, InfoCheckOutEntity> implements InfoCheckOutService {
    @Autowired
    InfoCheckOutDao infoCheckOutDao;
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        IPage<InfoCheckOutEntity> page = this.page(
                new Query<InfoCheckOutEntity>().getPage(params),
                new QueryWrapper<InfoCheckOutEntity>()
        );

        return new PageUtils(page);
    }

    @Override
    public PageUtils selectPageVo(Map<String, Object> params) {
        Long currPage = Long.parseLong(params.get("page")+"");
        Long pageSize = Long.parseLong(params.get("limit")+"");
        QueryWrapper<CheckOutCustomerVo> wrapper = new QueryWrapper<>();
        wrapper.eq("co.is_delete",1);
        Object key = params.get("key");
        if(key!=null && key.toString().trim().length()>0){
            wrapper.in("co.id",key.toString().trim().split(",|，|\\s"));
        }
        IPage<CheckOutCustomerVo> page = infoCheckOutDao.selectPageVo(new Page<CheckOutCustomerVo>(currPage, pageSize), wrapper);
        return new PageUtils(page);
    }

    @Override
    public List<CheckOutCustomerVo> getCheckedCustomer() {
        return infoCheckOutDao.getCheckedCustomer();
    }

}