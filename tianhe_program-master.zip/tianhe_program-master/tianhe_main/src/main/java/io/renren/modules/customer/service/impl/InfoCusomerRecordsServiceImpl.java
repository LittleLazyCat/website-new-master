package io.renren.modules.customer.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.Query;

import io.renren.modules.customer.dao.InfoCusomerRecordsDao;
import io.renren.modules.customer.entity.InfoCusomerRecordsEntity;
import io.renren.modules.customer.service.InfoCusomerRecordsService;


@Service("infoCusomerRecordsService")
public class InfoCusomerRecordsServiceImpl extends ServiceImpl<InfoCusomerRecordsDao, InfoCusomerRecordsEntity> implements InfoCusomerRecordsService {

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        QueryWrapper<InfoCusomerRecordsEntity> wrapper = new QueryWrapper<>();
        Object key = params.get("key");
        if(key!=null && key.toString().trim().length()>0){
            wrapper.in("id",key.toString().trim().split(",|，|\\s"));
        }
        IPage<InfoCusomerRecordsEntity> page = this.page(
                new Query<InfoCusomerRecordsEntity>().getPage(params),
                wrapper
        );

        return new PageUtils(page);
    }

}