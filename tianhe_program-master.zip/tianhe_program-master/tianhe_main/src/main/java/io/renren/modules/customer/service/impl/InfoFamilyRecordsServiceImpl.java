package io.renren.modules.customer.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.renren.common.utils.ReadParamsUtils;
import io.renren.modules.customer.entity.RecommendReason;
import io.renren.modules.customer.entity.vo.InfoFamilyRecordsEntityVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.Query;

import io.renren.modules.customer.dao.InfoFamilyRecordsDao;
import io.renren.modules.customer.entity.InfoFamilyRecordsEntity;
import io.renren.modules.customer.service.InfoFamilyRecordsService;


@Service("infoFamilyRecordsService")
public class InfoFamilyRecordsServiceImpl extends ServiceImpl<InfoFamilyRecordsDao, InfoFamilyRecordsEntity> implements InfoFamilyRecordsService {
    @Autowired
    InfoFamilyRecordsDao infoFamilyRecordsDao;
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        IPage<InfoFamilyRecordsEntity> page = this.page(
                new Query<InfoFamilyRecordsEntity>().getPage(params),
                new QueryWrapper<InfoFamilyRecordsEntity>()
        );

        return new PageUtils(page);
    }

    @Override
    public PageUtils selectPageVo(Map<String, Object> params) {
        Page<InfoFamilyRecordsEntityVo> page = new ReadParamsUtils<InfoFamilyRecordsEntityVo>().getPage(params);
        QueryWrapper<InfoFamilyRecordsEntityVo> wrapper = new QueryWrapper<>();
        wrapper.eq("fr.is_delete",1);
        Object key = params.get("key");
        if(key!=null&&key.toString().trim().length()>0){
            wrapper.in("fr.id",key.toString().trim().split(",|，|\\s"));
        }
        wrapper.orderByAsc("fr.customer_id");
        return new PageUtils(infoFamilyRecordsDao.selectPageVo(page, wrapper));
    }

    @Override
    public List<RecommendReason> getRecommendReason() {
        return infoFamilyRecordsDao.getAccesReson();
    }

}