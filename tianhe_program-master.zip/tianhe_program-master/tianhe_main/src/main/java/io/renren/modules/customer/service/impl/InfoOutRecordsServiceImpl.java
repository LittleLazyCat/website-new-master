package io.renren.modules.customer.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.renren.common.utils.ReadParamsUtils;
import io.renren.modules.customer.entity.vo.CanGoOutVo;
import io.renren.modules.customer.entity.vo.InfoOutEntityVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.Query;

import io.renren.modules.customer.dao.InfoOutRecordsDao;
import io.renren.modules.customer.entity.InfoOutRecordsEntity;
import io.renren.modules.customer.service.InfoOutRecordsService;


@Service("infoOutRecordsService")
public class InfoOutRecordsServiceImpl extends ServiceImpl<InfoOutRecordsDao, InfoOutRecordsEntity> implements InfoOutRecordsService {
    @Autowired
    InfoOutRecordsDao infoOutRecordsDao;
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        IPage<InfoOutRecordsEntity> page = this.page(
                new Query<InfoOutRecordsEntity>().getPage(params),
                new QueryWrapper<InfoOutRecordsEntity>()
        );

        return new PageUtils(page);
    }

    @Override
    public PageUtils selectPageVo(Map<String, Object> params) {
        Page<InfoOutEntityVo> page = new ReadParamsUtils<InfoOutEntityVo>().getPage(params);
        QueryWrapper<InfoOutEntityVo> wrapper = new QueryWrapper<>();
        wrapper.eq("ore.is_delete",1);
        Object key = params.get("key");
        if(key!=null && key.toString().trim().length()>0){
            wrapper.in("ore.id",key.toString().trim().split(",|，|\\s"));
        }
        return new PageUtils(infoOutRecordsDao.selectPageVo(page, wrapper));
    }

    @Override
    public List<CanGoOutVo> getCanGoOutList() {
        return infoOutRecordsDao.getCanGoOutList();
    }

    @Override
    public InfoOutEntityVo selectVoById(Integer id) {
        return infoOutRecordsDao.selectVoById(id);
    }

}