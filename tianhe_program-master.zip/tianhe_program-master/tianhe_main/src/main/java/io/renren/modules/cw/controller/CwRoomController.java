package io.renren.modules.cw.controller;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.renren.modules.cw.entity.CwRoomEntity;
import io.renren.modules.cw.service.CwRoomService;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.R;



/**
 * 
 *
 * @author wangshijun
 * @email 3088916141@qq.com
 * @date 2021-05-06 13:40:14
 */
@RestController
@RequestMapping("cw/cwroom")
public class CwRoomController {
    @Autowired
    private CwRoomService cwRoomService;

    /**
     * 列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("cw:cwroom:list")
    public R list(@RequestParam Map<String, Object> params){
        PageUtils page = cwRoomService.queryPage(params);

        return R.ok().put("page", page);
    }


    /**
     * 信息
     */
    @RequestMapping("/info/{roomId}")
    @RequiresPermissions("cw:cwroom:info")
    public R info(@PathVariable("roomId") Integer roomId){
		CwRoomEntity cwRoom = cwRoomService.getById(roomId);

        return R.ok().put("cwRoom", cwRoom);
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    @RequiresPermissions("cw:cwroom:save")
    public R save(@RequestBody CwRoomEntity cwRoom){
		cwRoomService.save(cwRoom);

        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    @RequiresPermissions("cw:cwroom:update")
    public R update(@RequestBody CwRoomEntity cwRoom){
		cwRoomService.updateById(cwRoom);

        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @RequiresPermissions("cw:cwroom:delete")
    public R delete(@RequestBody Integer[] roomIds){
		cwRoomService.removeByIds(Arrays.asList(roomIds));

        return R.ok();
    }
    @RequestMapping("/getRoomList")
    public R getRoomList(){
        List<CwRoomEntity> list = cwRoomService.list();
        return R.ok().put("data", list);
    }
}
