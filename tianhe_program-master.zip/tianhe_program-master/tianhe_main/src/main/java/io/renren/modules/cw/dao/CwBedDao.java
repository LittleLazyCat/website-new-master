package io.renren.modules.cw.dao;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.renren.modules.cw.entity.CwBedEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import io.renren.modules.cw.entity.vo.CwBedEntityVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * 
 * 
 * @author wangshijun
 * @email 3088916141@qq.com
 * @date 2021-05-06 13:40:14
 */
@Mapper
public interface CwBedDao extends BaseMapper<CwBedEntity> {
	IPage<CwBedEntityVo> selectPageVo(Page<CwBedEntityVo>page, @Param(Constants.WRAPPER)QueryWrapper<CwBedEntityVo>wrapper);
}
