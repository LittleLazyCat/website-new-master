package io.renren.modules.cw.dao;

import io.renren.modules.cw.entity.CwRoomEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 
 * 
 * @author wangshijun
 * @email 3088916141@qq.com
 * @date 2021-05-06 13:40:14
 */
@Mapper
public interface CwRoomDao extends BaseMapper<CwRoomEntity> {
	
}
