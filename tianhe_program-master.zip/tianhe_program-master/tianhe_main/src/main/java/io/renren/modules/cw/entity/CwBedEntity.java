package io.renren.modules.cw.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 
 * 
 * @author wangshijun
 * @email 3088916141@qq.com
 * @date 2021-05-06 13:40:14
 */
@Data
@TableName("tb_cw_bed")
public class CwBedEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 床位id
	 */
	@TableId
	private Integer bedId;
	/**
	 * 参照用户档案表，外键
	 */
	private Integer customerId;
	/**
	 * 床位检查，清洁为1
	 */
	private Integer bedCheck;
	/**
	 * 床位是否需要清洁，清洁为1
	 */
	private Integer bedClean;
	/**
	 * 房间id参照房间表,外键
	 */
	private Integer roomId;
	/**
	 * 创建时间
	 */
	@TableField(fill = FieldFill.INSERT)
	private Date createTime;
	/**
	 * 更新时间
	 */
	@TableField(fill = FieldFill.INSERT_UPDATE)
	private Date updateTime;
	/**
	 * 0表示已经删除
	 */
	@TableLogic
	private Integer isDelete;

}
