package io.renren.modules.cw.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 
 * 
 * @author wangshijun
 * @email 3088916141@qq.com
 * @date 2021-05-06 13:40:14
 */
@Data
@TableName("tb_cw_room")
public class CwRoomEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 房间id
	 */
	@TableId
	private Integer roomId;
	/**
	 * 楼层1-7
	 */
	private Integer roomFloor;
	/**
	 * 创建时间
	 */
	@TableField(fill = FieldFill.INSERT)
	private Date createTime;
	/**
	 * 更新时间
	 */
	@TableField(fill = FieldFill.INSERT_UPDATE)
	private Date updateTime;
	/**
	 * 0表示已经删除
	 */
	@TableLogic
	private Integer isDelete;
}
