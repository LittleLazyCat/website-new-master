package io.renren.modules.cw.entity.vo;

import io.renren.modules.cw.entity.CwBedEntity;
import lombok.Data;

/**
 * @Description:
 * @Author: tanyajun
 * @CreateTime: 2021/5/21
 * @Blog: https://tanyajun.top
 */
@Data
public class CwBedEntityVo extends CwBedEntity {
    private Integer roomFloor;
    private String customerName;
    private String identityNumber;
    private String customerPhone;
}
