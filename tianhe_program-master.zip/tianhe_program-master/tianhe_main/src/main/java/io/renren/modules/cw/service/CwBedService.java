package io.renren.modules.cw.service;

import com.baomidou.mybatisplus.extension.service.IService;
import io.renren.common.utils.PageUtils;
import io.renren.modules.cw.entity.CwBedEntity;

import java.util.Map;

/**
 * 
 *
 * @author wangshijun
 * @email 3088916141@qq.com
 * @date 2021-05-06 13:40:14
 */
public interface CwBedService extends IService<CwBedEntity> {

    PageUtils queryPage(Map<String, Object> params);
    PageUtils selectPageVo(Map<String, Object> params);
}

