package io.renren.modules.cw.service;

import com.baomidou.mybatisplus.extension.service.IService;
import io.renren.common.utils.PageUtils;
import io.renren.modules.cw.entity.CwRoomEntity;

import java.util.Map;

/**
 * 
 *
 * @author wangshijun
 * @email 3088916141@qq.com
 * @date 2021-05-06 13:40:14
 */
public interface CwRoomService extends IService<CwRoomEntity> {

    PageUtils queryPage(Map<String, Object> params);
}

