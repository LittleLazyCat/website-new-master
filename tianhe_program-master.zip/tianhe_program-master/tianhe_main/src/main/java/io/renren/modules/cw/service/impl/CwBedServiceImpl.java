package io.renren.modules.cw.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.renren.common.utils.ReadParamsUtils;
import io.renren.modules.cw.entity.vo.CwBedEntityVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Map;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.Query;

import io.renren.modules.cw.dao.CwBedDao;
import io.renren.modules.cw.entity.CwBedEntity;
import io.renren.modules.cw.service.CwBedService;


@Service("cwBedService")
public class CwBedServiceImpl extends ServiceImpl<CwBedDao, CwBedEntity> implements CwBedService {
    @Autowired
    CwBedDao cwBedDao;
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        QueryWrapper<CwBedEntity> wrapper = new QueryWrapper<>();
        if(params.get("key")!=null&&params.get("key").toString().trim().length()>0){
            wrapper.in("bed_id",params.get("key").toString().trim().split(",|，|\\s"));
        }
        IPage<CwBedEntity> page = this.page(
                new Query<CwBedEntity>().getPage(params),
                wrapper
        );

        return new PageUtils(page);
    }

    @Override
    public PageUtils selectPageVo(Map<String, Object> params) {
        Page<CwBedEntityVo> page = new ReadParamsUtils<CwBedEntityVo>().getPage(params);
        QueryWrapper<CwBedEntityVo> wrapper = new QueryWrapper<>();
        /*
        WHERE
        cwb.is_delete=1
        ORDER BY
        cwr.room_floor ASC,cwb.bed_id ASC
         */
        wrapper.eq("cwb.is_delete",1).orderByAsc("cwr.room_floor","cwb.bed_id");
        if(params.get("key")!=null&&params.get("key").toString().trim().length()>0){
            wrapper.in("cwb.bed_id",params.get("key").toString().trim().split(",|，|\\s"));
        }
        return new PageUtils(cwBedDao.selectPageVo(page,wrapper));
    }

}