package io.renren.modules.cw.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.Query;

import io.renren.modules.cw.dao.CwRoomDao;
import io.renren.modules.cw.entity.CwRoomEntity;
import io.renren.modules.cw.service.CwRoomService;


@Service("cwRoomService")
public class CwRoomServiceImpl extends ServiceImpl<CwRoomDao, CwRoomEntity> implements CwRoomService {

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        QueryWrapper<CwRoomEntity> wrapper = new QueryWrapper<>();
        if(params.get("key")!=null&&params.get("key").toString().trim().length()>0){
            wrapper.in("room_id",params.get("key").toString().trim().split(",|，|\\s"));
        }
        IPage<CwRoomEntity> page = this.page(
                new Query<CwRoomEntity>().getPage(params),
                wrapper
        );

        return new PageUtils(page);
    }

}