package io.renren.modules.fy.controller;

import java.util.Arrays;
import java.util.Map;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.renren.modules.fy.entity.FyOrderEntity;
import io.renren.modules.fy.service.FyOrderService;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.R;



/**
 * 
 *
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-05-07 11:02:42
 */
@RestController
@RequestMapping("fy/fyorder")
public class FyOrderController {
    @Autowired
    private FyOrderService fyOrderService;

    /**
     * 列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("fy:fyorder:list")
    public R list(@RequestParam Map<String, Object> params){
        //PageUtils page = fyOrderService.queryPage(params);
        PageUtils page = fyOrderService.selectPageVo(params);

        return R.ok().put("page", page);
    }


    /**
     * 信息
     */
    @RequestMapping("/info/{orderId}")
    @RequiresPermissions("fy:fyorder:info")
    public R info(@PathVariable("orderId") Integer orderId){
		FyOrderEntity fyOrder = fyOrderService.getById(orderId);

        return R.ok().put("fyOrder", fyOrder);
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    @RequiresPermissions("fy:fyorder:save")
    public R save(@RequestBody FyOrderEntity fyOrder){
		fyOrderService.save(fyOrder);

        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    @RequiresPermissions("fy:fyorder:update")
    public R update(@RequestBody FyOrderEntity fyOrder){
		fyOrderService.updateById(fyOrder);

        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @RequiresPermissions("fy:fyorder:delete")
    public R delete(@RequestBody Integer[] orderIds){
		fyOrderService.removeByIds(Arrays.asList(orderIds));

        return R.ok();
    }

}
