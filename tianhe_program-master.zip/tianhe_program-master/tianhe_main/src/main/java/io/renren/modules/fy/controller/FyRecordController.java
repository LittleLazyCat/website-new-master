package io.renren.modules.fy.controller;

import java.util.Arrays;
import java.util.Map;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.renren.modules.fy.entity.FyRecordEntity;
import io.renren.modules.fy.service.FyRecordService;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.R;



/**
 * 
 *
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-05-07 11:02:42
 */
@RestController
@RequestMapping("fy/fyrecord")
public class FyRecordController {
    @Autowired
    private FyRecordService fyRecordService;

    /**
     * 列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("fy:fyrecord:list")
    public R list(@RequestParam Map<String, Object> params){
        PageUtils page = fyRecordService.queryPage(params);

        return R.ok().put("page", page);
    }


    /**
     * 信息
     */
    @RequestMapping("/info/{id}")
    @RequiresPermissions("fy:fyrecord:info")
    public R info(@PathVariable("id") Integer id){
		FyRecordEntity fyRecord = fyRecordService.getById(id);

        return R.ok().put("fyRecord", fyRecord);
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    @RequiresPermissions("fy:fyrecord:save")
    public R save(@RequestBody FyRecordEntity fyRecord){
		fyRecordService.save(fyRecord);

        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    @RequiresPermissions("fy:fyrecord:update")
    public R update(@RequestBody FyRecordEntity fyRecord){
		fyRecordService.updateById(fyRecord);

        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @RequiresPermissions("fy:fyrecord:delete")
    public R delete(@RequestBody Integer[] ids){
		fyRecordService.removeByIds(Arrays.asList(ids));

        return R.ok();
    }

}
