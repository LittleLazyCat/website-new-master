package io.renren.modules.fy.dao;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.renren.modules.fy.entity.FyOrderEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import io.renren.modules.fy.entity.vo.FyOrderEntityVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * 
 * 
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-05-07 11:02:42
 */
@Mapper
public interface FyOrderDao extends BaseMapper<FyOrderEntity> {
	IPage<FyOrderEntityVo> selectPageVo(Page<FyOrderEntityVo>page, @Param(Constants.WRAPPER)QueryWrapper<FyOrderEntityVo>wrapper);
}
