package io.renren.modules.fy.dao;

import io.renren.modules.fy.entity.FyRecordEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 
 * 
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-05-07 11:02:42
 */
@Mapper
public interface FyRecordDao extends BaseMapper<FyRecordEntity> {
	
}
