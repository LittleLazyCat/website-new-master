package io.renren.modules.fy.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 
 * 
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-05-07 11:02:42
 */
@Data
@TableName("tb_fy_order")
public class FyOrderEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 订单编号(主键，自动递增)
	 */
	@TableId
	private Integer orderId;
	/**
	 * 客户id：订单的源主
	 */
	private Integer customerId;
	/**
	 * 订单类型[饮食、护理]
	 */
	private String orderType;
	/**
	 * 订单项目名称:对应膳食名称或护理项目名称
	 */
	private String orderName;
	/**
	 * 订单数目：默认为1，对应所定项目的数量
	 */
	private Integer orderNum;
	/**
	 * 订单金额(单个项目的费用)
	 */
	private Double orderCost;
	/**
	 * 支付状态：默认0表示未支付
	 */
	private Integer payState;
	/**
	 * 创建时间
	 */
	@TableField(fill = FieldFill.INSERT)
	private Date createTime;
	/**
	 * 更新时间
	 */
	@TableField(fill = FieldFill.INSERT_UPDATE)
	private Date updateTime;
	/**
	 * 0表示已经删除
	 */
	@TableLogic
	private Integer isDelete;

}
