package io.renren.modules.fy.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 
 * 
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-05-07 11:02:42
 */
@Data
@TableName("tb_fy_record")
public class FyRecordEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 缴费记录id：主键，自增
	 */
	@TableId
	private Integer id;
	/**
	 * 客户ID
	 */
	private Integer costumerId;
	/**
	 * 订单编号
	 */
	private Integer orderId;
	/**
	 * 费用总额
	 */
	private Double totalcost;
	/**
	 * 缴费状态：默认值=0-未缴费，1-已缴费
	 */
	private Integer payState;
	/**
	 * 缴费时间
	 */
	private Date payTime;
	/**
	 * 创建时间
	 */
	@TableField(fill = FieldFill.INSERT)
	private Date createTime;
	/**
	 * 更新时间
	 */
	@TableField(fill = FieldFill.INSERT_UPDATE)
	private Date updateTime;
	/**
	 * 0表示已经删除
	 */
	@TableLogic
	private Integer isDelete;

}
