package io.renren.modules.fy.entity.vo;

import io.renren.modules.fy.entity.FyOrderEntity;
import lombok.Data;

/**
 * @Description:
 * @Author: tanyajun
 * @CreateTime: 2021/5/19
 * @Blog: https://tanyajun.top
 */
@Data
public class FyOrderEntityVo extends FyOrderEntity {
    private String customerName;
    private String identityNumber;
    private String customerPhone;
}
