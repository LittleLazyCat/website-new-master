package io.renren.modules.fy.service;

import com.baomidou.mybatisplus.extension.service.IService;
import io.renren.common.utils.PageUtils;
import io.renren.modules.fy.entity.FyRecordEntity;

import java.util.Map;

/**
 * 
 *
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-05-07 11:02:42
 */
public interface FyRecordService extends IService<FyRecordEntity> {

    PageUtils queryPage(Map<String, Object> params);
}

