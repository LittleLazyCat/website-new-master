package io.renren.modules.fy.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.renren.common.utils.ReadParamsUtils;
import io.renren.modules.fy.entity.vo.FyOrderEntityVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Map;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.Query;

import io.renren.modules.fy.dao.FyOrderDao;
import io.renren.modules.fy.entity.FyOrderEntity;
import io.renren.modules.fy.service.FyOrderService;


@Service("fyOrderService")
public class FyOrderServiceImpl extends ServiceImpl<FyOrderDao, FyOrderEntity> implements FyOrderService {
    @Autowired
    FyOrderDao fyOrderDao;
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        IPage<FyOrderEntity> page = this.page(
                new Query<FyOrderEntity>().getPage(params),
                new QueryWrapper<FyOrderEntity>()
        );

        return new PageUtils(page);
    }

    @Override
    public PageUtils selectPageVo(Map<String, Object> params) {
        Page<FyOrderEntityVo> page = new ReadParamsUtils<FyOrderEntityVo>().getPage(params);
        QueryWrapper<FyOrderEntityVo> wrapper = new QueryWrapper<>();
        wrapper.eq("fyo.is_delete",1);
        if(params.get("key")!=null&&params.get("key").toString().trim().length()>0){
            wrapper.in("fyo.order_id",params.get("key").toString().trim().split(",|，|\\s"));
        }
        return new PageUtils(fyOrderDao.selectPageVo(page,wrapper));
    }

}