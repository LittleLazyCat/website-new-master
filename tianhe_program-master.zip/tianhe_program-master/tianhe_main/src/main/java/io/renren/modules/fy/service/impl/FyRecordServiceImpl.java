package io.renren.modules.fy.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.Query;

import io.renren.modules.fy.dao.FyRecordDao;
import io.renren.modules.fy.entity.FyRecordEntity;
import io.renren.modules.fy.service.FyRecordService;


@Service("fyRecordService")
public class FyRecordServiceImpl extends ServiceImpl<FyRecordDao, FyRecordEntity> implements FyRecordService {

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        QueryWrapper<FyRecordEntity> wrapper = new QueryWrapper<>();
        if(params.get("key")!=null&&params.get("key").toString().trim().length()>0){
            wrapper.in("id",params.get("key").toString().trim().split(",|，|\\s"));
        }
        IPage<FyRecordEntity> page = this.page(
                new Query<FyRecordEntity>().getPage(params),
                wrapper
        );

        return new PageUtils(page);
    }

}