package io.renren.modules.hl.controller;

import java.util.Arrays;
import java.util.Map;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.renren.modules.hl.entity.HlHealthRecordEntity;
import io.renren.modules.hl.service.HlHealthRecordService;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.R;



/**
 * 
 *
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-05-07 10:58:07
 */
@RestController
@RequestMapping("hl/hlhealthrecord")
public class HlHealthRecordController {
    @Autowired
    private HlHealthRecordService hlHealthRecordService;

    /**
     * 列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("hl:hlhealthrecord:list")
    public R list(@RequestParam Map<String, Object> params){
        //PageUtils page = hlHealthRecordService.queryPage(params);
        PageUtils page = hlHealthRecordService.selectPageVo(params);

        return R.ok().put("page", page);
    }


    /**
     * 信息
     */
    @RequestMapping("/info/{id}")
    @RequiresPermissions("hl:hlhealthrecord:info")
    public R info(@PathVariable("id") Integer id){
		HlHealthRecordEntity hlHealthRecord = hlHealthRecordService.getById(id);

        return R.ok().put("hlHealthRecord", hlHealthRecord);
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    @RequiresPermissions("hl:hlhealthrecord:save")
    public R save(@RequestBody HlHealthRecordEntity hlHealthRecord){
		hlHealthRecordService.save(hlHealthRecord);

        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    @RequiresPermissions("hl:hlhealthrecord:update")
    public R update(@RequestBody HlHealthRecordEntity hlHealthRecord){
		hlHealthRecordService.updateById(hlHealthRecord);

        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @RequiresPermissions("hl:hlhealthrecord:delete")
    public R delete(@RequestBody Integer[] ids){
		hlHealthRecordService.removeByIds(Arrays.asList(ids));

        return R.ok();
    }

}
