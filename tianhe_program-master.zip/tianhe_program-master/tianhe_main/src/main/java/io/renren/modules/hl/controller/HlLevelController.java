package io.renren.modules.hl.controller;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.renren.modules.hl.entity.HlLevelEntity;
import io.renren.modules.hl.service.HlLevelService;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.R;



/**
 * 
 *
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-05-07 10:58:07
 */
@RestController
@RequestMapping("hl/hllevel")
public class HlLevelController {
    @Autowired
    private HlLevelService hlLevelService;

    /**
     * 列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("hl:hllevel:list")
    public R list(@RequestParam Map<String, Object> params){
        PageUtils page = hlLevelService.queryPage(params);

        return R.ok().put("page", page);
    }


    /**
     * 信息
     */
    @RequestMapping("/info/{levelId}")
    @RequiresPermissions("hl:hllevel:info")
    public R info(@PathVariable("levelId") Integer levelId){
		HlLevelEntity hlLevel = hlLevelService.getById(levelId);

        return R.ok().put("hlLevel", hlLevel);
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    @RequiresPermissions("hl:hllevel:save")
    public R save(@RequestBody HlLevelEntity hlLevel){
		hlLevelService.save(hlLevel);

        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    @RequiresPermissions("hl:hllevel:update")
    public R update(@RequestBody HlLevelEntity hlLevel){
		hlLevelService.updateById(hlLevel);

        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @RequiresPermissions("hl:hllevel:delete")
    public R delete(@RequestBody Integer[] levelIds){
		hlLevelService.removeByIds(Arrays.asList(levelIds));

        return R.ok();
    }
    /**
     * 获取已启用的护理级别列表
     */
    @RequestMapping("/getAvailableHlLevelList")
    public R getAvailableHlLevelList(){
        QueryWrapper<HlLevelEntity> wrapper = new QueryWrapper<>();
        wrapper.eq("level_state",1);
        List<HlLevelEntity> list = hlLevelService.list(wrapper);
        return R.ok().put("data",list);
    }
}
