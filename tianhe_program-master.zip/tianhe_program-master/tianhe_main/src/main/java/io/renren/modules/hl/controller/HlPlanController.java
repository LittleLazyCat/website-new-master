package io.renren.modules.hl.controller;

import java.util.Arrays;
import java.util.Map;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.renren.modules.hl.entity.HlPlanEntity;
import io.renren.modules.hl.service.HlPlanService;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.R;



/**
 * 
 *
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-05-07 10:58:07
 */
@RestController
@RequestMapping("hl/hlplan")
public class HlPlanController {
    @Autowired
    private HlPlanService hlPlanService;

    /**
     * 列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("hl:hlplan:list")
    public R list(@RequestParam Map<String, Object> params){
        //PageUtils page = hlPlanService.queryPage(params);
        PageUtils page = hlPlanService.selectPageVo(params);

        return R.ok().put("page", page);
    }


    /**
     * 信息
     */
    @RequestMapping("/info/{planId}")
    @RequiresPermissions("hl:hlplan:info")
    public R info(@PathVariable("planId") Integer planId){
		HlPlanEntity hlPlan = hlPlanService.getById(planId);

        return R.ok().put("hlPlan", hlPlan);
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    @RequiresPermissions("hl:hlplan:save")
    public R save(@RequestBody HlPlanEntity hlPlan){
		hlPlanService.save(hlPlan);

        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    @RequiresPermissions("hl:hlplan:update")
    public R update(@RequestBody HlPlanEntity hlPlan){
		hlPlanService.updateById(hlPlan);

        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @RequiresPermissions("hl:hlplan:delete")
    public R delete(@RequestBody Integer[] planIds){
		hlPlanService.removeByIds(Arrays.asList(planIds));

        return R.ok();
    }

}
