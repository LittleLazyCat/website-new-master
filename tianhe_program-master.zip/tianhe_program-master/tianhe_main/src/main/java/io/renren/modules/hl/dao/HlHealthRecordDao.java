package io.renren.modules.hl.dao;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.renren.modules.hl.entity.HlHealthRecordEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import io.renren.modules.hl.entity.vo.HlHealthRecordEntityVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * 
 * 
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-05-07 10:58:07
 */
@Mapper
public interface HlHealthRecordDao extends BaseMapper<HlHealthRecordEntity> {
	IPage<HlHealthRecordEntityVo> selectPageVo(Page<HlHealthRecordEntityVo>page, @Param(Constants.WRAPPER) QueryWrapper<HlHealthRecordEntityVo>wrapper);
}
