package io.renren.modules.hl.dao;

import io.renren.modules.hl.entity.HlLevelEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 
 * 
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-05-07 10:58:07
 */
@Mapper
public interface HlLevelDao extends BaseMapper<HlLevelEntity> {
	
}
