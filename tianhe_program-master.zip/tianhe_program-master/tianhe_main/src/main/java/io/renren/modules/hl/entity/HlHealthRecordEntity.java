package io.renren.modules.hl.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 
 * 
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-05-07 10:58:07
 */
@Data
@TableName("tb_hl_health_record")
public class HlHealthRecordEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 体检记录id：主键自增
	 */
	@TableId
	private Integer id;
	/**
	 * 客户id：外键，参照客户档案中的id
	 */
	private Integer customerId;
	/**
	 * 体检时间
	 */
	private Date doTime;
	/**
	 * 肝功：正常（0-40）
	 */
	private Double liverFunction;
	/**
	 * 血糖：正常（3.9-6.0）
	 */
	private Double bloodSugar;
	/**
	 * 心率;正常（60-100)
	 */
	private Double heartRate;
	/**
	 * 肾功：正常（50-130)
	 */
	private Double kidneyFunction;
	/**
	 * 体检医生id：参照职工表
	 */
	private Integer empId;
	/**
	 * 创建时间
	 */
	@TableField(fill = FieldFill.INSERT)
	private Date createTime;
	/**
	 * 更新时间
	 */
	@TableField(fill = FieldFill.INSERT_UPDATE)
	private Date updateTime;
	/**
	 * 0表示已经删除
	 */
	@TableLogic
	private Integer isDelete;

}
