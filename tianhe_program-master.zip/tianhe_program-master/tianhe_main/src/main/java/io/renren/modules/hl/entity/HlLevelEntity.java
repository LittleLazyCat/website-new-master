package io.renren.modules.hl.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 
 * 
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-05-07 10:58:07
 */
@Data
@TableName("tb_hl_level")
public class HlLevelEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 级别编号（主键自增）
	 */
	@TableId
	private Integer levelId;
	/**
	 * 护理级别名称
	 */
	private String levelName;
	/**
	 * 护理级别描述
	 */
	private String levelDescribe;
	/**
	 * 级别状态，默认=1启用 0禁用
	 */
	private Integer levelState;
	/**
	 * 创建时间
	 */
	@TableField(fill = FieldFill.INSERT)
	private Date createTime;
	/**
	 * 更新时间
	 */
	@TableField(fill = FieldFill.INSERT_UPDATE)
	private Date updateTime;
	/**
	 * 0表示已经删除
	 */
	@TableLogic
	private Integer isDelete;


}
