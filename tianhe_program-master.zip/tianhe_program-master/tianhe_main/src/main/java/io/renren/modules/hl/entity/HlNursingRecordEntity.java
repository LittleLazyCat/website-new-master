package io.renren.modules.hl.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 
 * 
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-05-07 10:58:07
 */
@Data
@TableName("tb_hl_nursing_record")
public class HlNursingRecordEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 护理记录id：主键自增
	 */
	@TableId
	private Integer id;
	/**
	 * 客户id;外键，参照客户档案中的id
	 */
	private Integer customerId;
	/**
	 * 护理时间
	 */
	private Date nursingTime;
	/**
	 * 护理项目id：参照护理项目表中的id
	 */
	private Integer projectId;
	/**
	 * 数量
	 */
	private Integer number;
	/**
	 * 护理等级id：参照护理等级
	 */
	private Integer levelId;
	/**
	 * 护理人员：参照职工表中的id
	 */
	private Integer empId;
	/**
	 * 创建时间
	 */
	@TableField(fill = FieldFill.INSERT)
	private Date createTime;
	/**
	 * 更新时间
	 */
	@TableField(fill = FieldFill.INSERT_UPDATE)
	private Date updateTime;
	/**
	 * 0表示已经删除
	 */
	@TableLogic
	private Integer isDelete;

}
