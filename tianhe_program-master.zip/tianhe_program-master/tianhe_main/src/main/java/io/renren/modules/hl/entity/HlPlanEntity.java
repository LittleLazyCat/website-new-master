package io.renren.modules.hl.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 
 * 
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-05-07 10:58:07
 */
@Data
@TableName("tb_hl_plan")
public class HlPlanEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 计划编号（主键自增）
	 */
	@TableId
	private Integer planId;
	/**
	 * 项目id: 参照护理项目表
	 */
	private Integer projectId;
	/**
	 * 级别id：参照护理级别id
	 */
	private Integer levelId;
	/**
	 * 客户id：参照客户表
	 */
	private Integer customId;
	/**
	 * 护理师id：参照工作人员表
	 */
	private Integer empId;
	/**
	 * 护理计划描述
	 */
	private String planDesc;
	/**
	 * 计划状态默认=1启用 0禁用
	 */
	private Integer planState;
	/**
	 * 预计计划周期：(星期)1-5
	 */
	private Integer planCycle;
	/**
	 * 创建时间
	 */
	@TableField(fill = FieldFill.INSERT)
	private Date createTime;
	/**
	 * 更新时间
	 */
	@TableField(fill = FieldFill.INSERT_UPDATE)
	private Date updateTime;
	/**
	 * 0表示已经删除
	 */
	@TableLogic
	private Integer isDelete;
}
