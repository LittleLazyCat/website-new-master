package io.renren.modules.hl.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 
 * 
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-05-07 10:58:07
 */
@Data
@TableName("tb_hl_project")
public class HlProjectEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 项目编号（主键自增）
	 */
	@TableId
	private Integer projectId;
	/**
	 * 护理项目名称
	 */
	private String projectName;
	/**
	 * 护理项目描述
	 */
	private String projectDescribe;
	/**
	 * 项目状态默认=1启用 0禁用
	 */
	private Integer projectState;
	/**
	 * 护理项目价格
	 */
	private Double projectPrice;
	/**
	 * 护理项目备注
	 */
	private String projectNote;
	/**
	 * 创建时间
	 */
	@TableField(fill = FieldFill.INSERT)
	private Date createTime;
	/**
	 * 更新时间
	 */
	@TableField(fill = FieldFill.INSERT_UPDATE)
	private Date updateTime;
	/**
	 * 0表示已经删除
	 */
	@TableLogic
	private Integer isDelete;
}
