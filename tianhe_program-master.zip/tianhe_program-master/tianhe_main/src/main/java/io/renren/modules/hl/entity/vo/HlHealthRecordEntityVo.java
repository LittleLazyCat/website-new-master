package io.renren.modules.hl.entity.vo;

import io.renren.modules.hl.entity.HlHealthRecordEntity;
import lombok.Data;

/**
 * @Description:
 * @Author: tanyajun
 * @CreateTime: 2021/5/19
 * @Blog: https://tanyajun.top
 */
@Data
public class HlHealthRecordEntityVo extends HlHealthRecordEntity {
    private String customerName;
    private String identityNumber;
    private String empName;
    private String empPhone;
}
