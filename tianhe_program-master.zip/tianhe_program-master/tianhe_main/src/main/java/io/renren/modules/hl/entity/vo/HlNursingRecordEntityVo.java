package io.renren.modules.hl.entity.vo;

import io.renren.modules.hl.entity.HlNursingRecordEntity;
import lombok.Data;

/**
 * @Description:
 * @Author: tanyajun
 * @CreateTime: 2021/5/19
 * @Blog: https://tanyajun.top
 */
@Data
public class HlNursingRecordEntityVo extends HlNursingRecordEntity {
    private String customerName;
    private String customerPhone;
    private String levelName;
    private String levelDesc;
    private String empName;
    private String empPhone;
    private String projectDesc;
    private String projectName;
}
