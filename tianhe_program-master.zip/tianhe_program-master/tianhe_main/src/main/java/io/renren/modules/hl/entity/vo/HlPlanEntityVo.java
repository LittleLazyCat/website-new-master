package io.renren.modules.hl.entity.vo;

import io.renren.modules.hl.entity.HlPlanEntity;
import lombok.Data;

/**
 * @Description:
 * @Author: tanyajun
 * @CreateTime: 2021/5/19
 * @Blog: https://tanyajun.top
 */
@Data
public class HlPlanEntityVo extends HlPlanEntity {
    private String customerName;
    private String customerPhone;
    private Integer customerBed;
    private String levelName;
    private String levelDesc;
    private String empName;
    private String empPhone;
    private String projectDesc;
    private String projectName;
}
