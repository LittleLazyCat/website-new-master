package io.renren.modules.hl.service;

import com.baomidou.mybatisplus.extension.service.IService;
import io.renren.common.utils.PageUtils;
import io.renren.modules.hl.entity.HlHealthRecordEntity;

import java.util.Map;

/**
 * 
 *
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-05-07 10:58:07
 */
public interface HlHealthRecordService extends IService<HlHealthRecordEntity> {

    PageUtils queryPage(Map<String, Object> params);
    PageUtils selectPageVo(Map<String, Object> params);
}

