package io.renren.modules.hl.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.renren.common.utils.ReadParamsUtils;
import io.renren.modules.hl.entity.vo.HlHealthRecordEntityVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Map;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.Query;

import io.renren.modules.hl.dao.HlHealthRecordDao;
import io.renren.modules.hl.entity.HlHealthRecordEntity;
import io.renren.modules.hl.service.HlHealthRecordService;


@Service("hlHealthRecordService")
public class HlHealthRecordServiceImpl extends ServiceImpl<HlHealthRecordDao, HlHealthRecordEntity> implements HlHealthRecordService {
    @Autowired
    HlHealthRecordDao hlHealthRecordDao;
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        IPage<HlHealthRecordEntity> page = this.page(
                new Query<HlHealthRecordEntity>().getPage(params),
                new QueryWrapper<HlHealthRecordEntity>()
        );

        return new PageUtils(page);
    }

    @Override
    public PageUtils selectPageVo(Map<String, Object> params) {
        Page<HlHealthRecordEntityVo> page = new ReadParamsUtils<HlHealthRecordEntityVo>().getPage(params);
        QueryWrapper<HlHealthRecordEntityVo> wrapper = new QueryWrapper<>();
        wrapper.eq("hr.is_delete",1);
        if(params.get("key")!=null&&params.get("key").toString().trim().length()>0){
            wrapper.in("hr.id",params.get("key").toString().trim().split(",|，|\\s"));
        }
        return new PageUtils(hlHealthRecordDao.selectPageVo(page,wrapper));
    }

}