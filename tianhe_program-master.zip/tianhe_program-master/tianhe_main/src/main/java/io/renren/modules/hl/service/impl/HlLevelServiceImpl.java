package io.renren.modules.hl.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.Query;

import io.renren.modules.hl.dao.HlLevelDao;
import io.renren.modules.hl.entity.HlLevelEntity;
import io.renren.modules.hl.service.HlLevelService;


@Service("hlLevelService")
public class HlLevelServiceImpl extends ServiceImpl<HlLevelDao, HlLevelEntity> implements HlLevelService {

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        QueryWrapper<HlLevelEntity> wrapper = new QueryWrapper<>();
        if(params.get("key")!=null&&params.get("key").toString().trim().length()>0){
            wrapper.in("level_id",params.get("key").toString().trim().split(",|，|\\s"));
        }
        IPage<HlLevelEntity> page = this.page(
                new Query<HlLevelEntity>().getPage(params),
                wrapper
        );

        return new PageUtils(page);
    }

}