package io.renren.modules.hl.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.renren.common.utils.ReadParamsUtils;
import io.renren.modules.hl.entity.vo.HlNursingRecordEntityVo;
import io.renren.modules.hl.entity.vo.HlPlanEntityVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Map;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.Query;

import io.renren.modules.hl.dao.HlNursingRecordDao;
import io.renren.modules.hl.entity.HlNursingRecordEntity;
import io.renren.modules.hl.service.HlNursingRecordService;


@Service("hlNursingRecordService")
public class HlNursingRecordServiceImpl extends ServiceImpl<HlNursingRecordDao, HlNursingRecordEntity> implements HlNursingRecordService {
    @Autowired
    HlNursingRecordDao hlNursingRecordDao;
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        IPage<HlNursingRecordEntity> page = this.page(
                new Query<HlNursingRecordEntity>().getPage(params),
                new QueryWrapper<HlNursingRecordEntity>()
        );

        return new PageUtils(page);
    }

    @Override
    public PageUtils selectPageVo(Map<String, Object> params) {
        Page<HlNursingRecordEntityVo> page = new ReadParamsUtils<HlNursingRecordEntityVo>().getPage(params);
        QueryWrapper<HlNursingRecordEntityVo> wrapper = new QueryWrapper<>();
        wrapper.eq("hnr.is_delete",1);
        if(params.get("key")!=null&&params.get("key").toString().trim().length()>0){
            wrapper.in("hnr.id",params.get("key").toString().trim().split(",|，|\\s"));
        }
        return new PageUtils(hlNursingRecordDao.selectPageVo(page,wrapper));
    }

}