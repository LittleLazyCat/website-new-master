package io.renren.modules.hl.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.renren.common.utils.ReadParamsUtils;
import io.renren.modules.hl.entity.vo.HlHealthRecordEntityVo;
import io.renren.modules.hl.entity.vo.HlPlanEntityVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Map;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.Query;

import io.renren.modules.hl.dao.HlPlanDao;
import io.renren.modules.hl.entity.HlPlanEntity;
import io.renren.modules.hl.service.HlPlanService;


@Service("hlPlanService")
public class HlPlanServiceImpl extends ServiceImpl<HlPlanDao, HlPlanEntity> implements HlPlanService {
    @Autowired
    HlPlanDao hlPlanDao;
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        IPage<HlPlanEntity> page = this.page(
                new Query<HlPlanEntity>().getPage(params),
                new QueryWrapper<HlPlanEntity>()
        );

        return new PageUtils(page);
    }

    @Override
    public PageUtils selectPageVo(Map<String, Object> params) {
        Page<HlPlanEntityVo> page = new ReadParamsUtils<HlPlanEntityVo>().getPage(params);
        QueryWrapper<HlPlanEntityVo> wrapper = new QueryWrapper<>();
        /*
        WHERE
        hp.is_delete=1
        AND
        ci.valid_state=1
        AND
        ci.is_delete=1
         */
        wrapper.eq("hp.is_delete",1).eq("ci.valid_state",1).eq("ci.is_delete",1);
        if(params.get("key")!=null&&params.get("key").toString().trim().length()>0){
            wrapper.in("hp.plan_id",params.get("key").toString().trim().split(",|，|\\s"));
        }
        return new PageUtils(hlPlanDao.selectPageVo(page,wrapper));
    }

}