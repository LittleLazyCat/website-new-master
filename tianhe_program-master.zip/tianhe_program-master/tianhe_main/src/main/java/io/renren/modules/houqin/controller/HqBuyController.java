package io.renren.modules.houqin.controller;

import java.util.Arrays;
import java.util.Map;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.renren.modules.houqin.entity.HqBuyEntity;
import io.renren.modules.houqin.service.HqBuyService;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.R;



/**
 * 
 *
 * @author chenshun
 * @email sunlightcs@gmail.com
 * @date 2021-04-30 14:43:14
 */
@RestController
@RequestMapping("houqin/hqbuy")
public class HqBuyController {
    @Autowired
    private HqBuyService hqBuyService;

    /**
     * 列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("houqin:hqbuy:list")
    public R list(@RequestParam Map<String, Object> params){
        //PageUtils page = hqBuyService.queryPage(params);
        PageUtils page = hqBuyService.selectPageVo(params);

        return R.ok().put("page", page);
    }


    /**
     * 信息
     */
    @RequestMapping("/info/{buyId}")
    @RequiresPermissions("houqin:hqbuy:info")
    public R info(@PathVariable("buyId") Integer buyId){
		HqBuyEntity hqBuy = hqBuyService.getById(buyId);

        return R.ok().put("hqBuy", hqBuy);
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    @RequiresPermissions("houqin:hqbuy:save")
    public R save(@RequestBody HqBuyEntity hqBuy){
		hqBuyService.save(hqBuy);

        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    @RequiresPermissions("houqin:hqbuy:update")
    public R update(@RequestBody HqBuyEntity hqBuy){
		hqBuyService.updateById(hqBuy);

        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @RequiresPermissions("houqin:hqbuy:delete")
    public R delete(@RequestBody Integer[] buyIds){
		hqBuyService.removeByIds(Arrays.asList(buyIds));

        return R.ok();
    }

}
