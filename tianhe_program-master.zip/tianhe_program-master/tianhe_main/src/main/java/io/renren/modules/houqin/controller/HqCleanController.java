package io.renren.modules.houqin.controller;

import java.util.Arrays;
import java.util.Map;

import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import io.renren.modules.cw.entity.CwBedEntity;
import io.renren.modules.cw.service.CwBedService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.renren.modules.houqin.entity.HqCleanEntity;
import io.renren.modules.houqin.service.HqCleanService;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.R;



/**
 * 
 *
 * @author chenshun
 * @email sunlightcs@gmail.com
 * @date 2021-04-30 14:43:14
 */
@RestController
@RequestMapping("houqin/hqclean")
public class HqCleanController {
    @Autowired
    private HqCleanService hqCleanService;
    @Autowired
    private CwBedService cwBedService;
    /**
     * 列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("houqin:hqclean:list")
    public R list(@RequestParam Map<String, Object> params){
        //PageUtils page = hqCleanService.queryPage(params);
        PageUtils page = hqCleanService.selectPageVo(params);

        return R.ok().put("page", page);
    }


    /**
     * 信息
     */
    @RequestMapping("/info/{id}")
    @RequiresPermissions("houqin:hqclean:info")
    public R info(@PathVariable("id") Integer id){
		HqCleanEntity hqClean = hqCleanService.getById(id);

        return R.ok().put("hqClean", hqClean);
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    @RequiresPermissions("houqin:hqclean:save")
    @Transactional(rollbackFor = Exception.class)
    public R save(@RequestBody HqCleanEntity hqClean){
        boolean isSave = hqCleanService.save(hqClean);
        //如果新增清理床位且清理状态未0，就需要设置床位的清洁状态
        if(isSave){
            UpdateWrapper<CwBedEntity> wrapper = new UpdateWrapper<>();
            wrapper.set("bed_clean",hqClean.getCleanStatus()==0?1:0).eq("bed_id",hqClean.getBedId());
            cwBedService.update(wrapper);
        }

        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    @RequiresPermissions("houqin:hqclean:update")
    @Transactional(rollbackFor = Exception.class)
    public R update(@RequestBody HqCleanEntity hqClean){
        //boolean isUpdate = hqCleanService.updateById(hqClean);
        UpdateWrapper<HqCleanEntity> updateWrapper = new UpdateWrapper<>();
        if(hqClean.getCleanStatus()==0){
            updateWrapper.set("clean_time",null);
        }
        updateWrapper.eq("id",hqClean.getId());
        boolean isUpdate = hqCleanService.getBaseMapper().update(hqClean,updateWrapper)==1;
        if(isUpdate){
            UpdateWrapper<CwBedEntity> wrapper = new UpdateWrapper<>();
            // 设置已清洁(1)->床位清洁状态为0
            wrapper.set("bed_clean",hqClean.getCleanStatus()==0?1:0).eq("bed_id",hqClean.getBedId());
            cwBedService.update(wrapper);
        }
        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @RequiresPermissions("houqin:hqclean:delete")
    public R delete(@RequestBody Integer[] ids){
		hqCleanService.removeByIds(Arrays.asList(ids));

        return R.ok();
    }

}
