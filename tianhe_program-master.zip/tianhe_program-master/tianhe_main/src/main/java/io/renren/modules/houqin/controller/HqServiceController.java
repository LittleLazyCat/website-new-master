package io.renren.modules.houqin.controller;

import java.util.Arrays;
import java.util.Map;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.renren.modules.houqin.entity.HqServiceEntity;
import io.renren.modules.houqin.service.HqServiceService;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.R;



/**
 * 
 *
 * @author chenshun
 * @email sunlightcs@gmail.com
 * @date 2021-04-30 14:43:14
 */
@RestController
@RequestMapping("houqin/hqservice")
public class HqServiceController {
    @Autowired
    private HqServiceService hqServiceService;

    /**
     * 列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("houqin:hqservice:list")
    public R list(@RequestParam Map<String, Object> params){
       // PageUtils page = hqServiceService.queryPage(params);
        PageUtils page = hqServiceService.selectPageVo(params);

        return R.ok().put("page", page);
    }


    /**
     * 信息
     */
    @RequestMapping("/info/{eqId}")
    @RequiresPermissions("houqin:hqservice:info")
    public R info(@PathVariable("eqId") Integer eqId){
		HqServiceEntity hqService = hqServiceService.getById(eqId);

        return R.ok().put("hqService", hqService);
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    @RequiresPermissions("houqin:hqservice:save")
    public R save(@RequestBody HqServiceEntity hqService){
        hqServiceService.save(hqService);

        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    @RequiresPermissions("houqin:hqservice:update")
    public R update(@RequestBody HqServiceEntity hqService){
		hqServiceService.updateById(hqService);

        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @RequiresPermissions("houqin:hqservice:delete")
    public R delete(@RequestBody Integer[] eqIds){
		hqServiceService.removeByIds(Arrays.asList(eqIds));

        return R.ok();
    }

}
