package io.renren.modules.houqin.dao;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.renren.modules.houqin.entity.HqCleanEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import io.renren.modules.houqin.entity.vo.HqCleanEntityVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * 
 * 
 * @author chenshun
 * @email sunlightcs@gmail.com
 * @date 2021-04-30 14:43:14
 */
@Mapper
public interface HqCleanDao extends BaseMapper<HqCleanEntity> {
    IPage<HqCleanEntityVo> selectPageVo(Page<HqCleanEntityVo> page, @Param(Constants.WRAPPER) QueryWrapper<HqCleanEntityVo> wrapper);

}
