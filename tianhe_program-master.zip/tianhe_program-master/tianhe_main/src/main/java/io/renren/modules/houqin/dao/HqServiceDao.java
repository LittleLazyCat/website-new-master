package io.renren.modules.houqin.dao;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.renren.modules.houqin.entity.HqServiceEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import io.renren.modules.houqin.entity.vo.HqServiceEntityVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * 
 * 
 * @author chenshun
 * @email sunlightcs@gmail.com
 * @date 2021-04-30 14:43:14
 */
@Mapper
public interface HqServiceDao extends BaseMapper<HqServiceEntity> {
    IPage<HqServiceEntityVo> selectPageVo(Page<HqServiceEntityVo> page, @Param(Constants.WRAPPER) QueryWrapper<HqServiceEntityVo> wrapper);


}
