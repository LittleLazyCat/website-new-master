package io.renren.modules.houqin.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 
 * 
 * @author chenshun
 * @email sunlightcs@gmail.com
 * @date 2021-04-30 14:43:14
 */
@Data
@TableName("tb_hq_buy")
public class HqBuyEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 采购记录id
	 */
	@TableId
	private Integer buyId;
	/**
	 * 设备名称
	 */
	private String eqName;
	/**
	 * 采购时间
	 */
	private Date buyTime;
	/**
	 * 采购数量
	 */
	private Integer buyAmount;
	/**
	 * 采购价格
	 */
	private Double buyPrice;
	/**
	 * 采购人  参照工作人员表id
	 */
	private Integer empId;
	/**
	 * 备注
	 */
	private String remarks;
	/**
	 * 创建时间
	 */
	@TableField(fill = FieldFill.INSERT)
	private Date createTime;
	/**
	 * 更新时间
	 */
	@TableField(fill = FieldFill.INSERT_UPDATE)
	private Date updateTime;
	/**
	 * 1  未删除   
0  已删除
	 */
	@TableLogic
	private Integer isDelete;

}
