package io.renren.modules.houqin.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 
 * 
 * @author chenshun
 * @email sunlightcs@gmail.com
 * @date 2021-04-30 14:43:14
 */
@Data
@TableName("tb_hq_clean")
public class HqCleanEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 保洁记录id
	 */
	@TableId
	private Integer id;
	/**
	 * 床位 id 参照床位表id
	 */
	private Integer bedId;
	/**
	 * 保洁员  参照工作人员表id
	 */
	private Integer empId;
	/**
	 * 清洁时间
	 */
	private Date cleanTime;
	/**
	 * 清洁状态   0 未清洁  
1 已清洁
	 */
	private Integer cleanStatus;
	/**
	 * 创建时间
	 */
	@TableField(fill = FieldFill.INSERT)
	private Date createTime;
	/**
	 * 更新时间
	 */
	@TableField(fill = FieldFill.INSERT_UPDATE)
	private Date updateTime;
	/**
	 * 1  未删除   
0  已删除
	 */
	@TableLogic
	private Integer isDelete;

}
