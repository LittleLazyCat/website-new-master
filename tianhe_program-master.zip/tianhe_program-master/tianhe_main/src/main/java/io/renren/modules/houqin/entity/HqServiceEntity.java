package io.renren.modules.houqin.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 
 * 
 * @author chenshun
 * @email sunlightcs@gmail.com
 * @date 2021-04-30 14:43:14
 */
@Data
@TableName("tb_hq_service")
public class HqServiceEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 设备id
	 */
	@TableId
	private Integer eqId;
	/**
	 * 设备名称
	 */
	private String eqName;
	/**
	 * 检修状态  
0  未检修    
1  已检修
	 */
	private Integer checkStatus;
	/**
	 * 检修时间
	 */
	private Date checkTime;
	/**
	 * 检修人员  参照工作人员表id
	 */
	private Integer empId;
	/**
	 * 检修结果
	 */
	private String checkResult;
	/**
	 * 故障原因 
	 */
	private String reason;
	/**
	 * 创建时间
	 */
	@TableField(fill = FieldFill.INSERT)
	private Date createTime;
	/**
	 * 更新时间
	 */
	@TableField(fill = FieldFill.INSERT_UPDATE)
	private Date updateTime;
	/**
	 * 1 未删除  
0 已删除
	 */
	@TableLogic
	private Integer isDelete;

}
