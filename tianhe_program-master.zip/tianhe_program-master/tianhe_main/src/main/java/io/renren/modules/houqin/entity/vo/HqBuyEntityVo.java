package io.renren.modules.houqin.entity.vo;

import io.renren.modules.houqin.entity.HqBuyEntity;
import lombok.Data;

/**
 * @Description:
 * @Author: tanyajun
 * @CreateTime: 2021/5/18
 * @Blog: https://tanyajun.top
 */
@Data
public class HqBuyEntityVo extends HqBuyEntity {
    private String empName;
    private String empIdentity;
    private String empPhone;
}
