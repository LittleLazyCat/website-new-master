package io.renren.modules.houqin.entity.vo;

import io.renren.modules.houqin.entity.HqCleanEntity;
import lombok.Data;

/**
 * @Description:
 * @Author: tanyajun
 * @CreateTime: 2021/5/18
 * @Blog: https://tanyajun.top
 */
@Data
public class HqCleanEntityVo extends HqCleanEntity {
    private String empName;
    private String empIdentity;
    private String empPhone;
}
