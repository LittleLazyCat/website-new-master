package io.renren.modules.houqin.entity.vo;

import io.renren.modules.houqin.entity.HqServiceEntity;
import lombok.Data;

@Data
public class HqServiceEntityVo extends HqServiceEntity {
    private String empName;
    private String empIdentity;
    private String empPhone;
}
