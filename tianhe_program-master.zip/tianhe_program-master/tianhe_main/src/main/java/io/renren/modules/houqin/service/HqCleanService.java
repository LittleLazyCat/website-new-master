package io.renren.modules.houqin.service;

import com.baomidou.mybatisplus.extension.service.IService;
import io.renren.common.utils.PageUtils;
import io.renren.modules.houqin.entity.HqCleanEntity;

import java.util.Map;

/**
 * 
 *
 * @author chenshun
 * @email sunlightcs@gmail.com
 * @date 2021-04-30 14:43:14
 */
public interface HqCleanService extends IService<HqCleanEntity> {

    PageUtils queryPage(Map<String, Object> params);
    PageUtils selectPageVo(Map<String, Object> params);
}

