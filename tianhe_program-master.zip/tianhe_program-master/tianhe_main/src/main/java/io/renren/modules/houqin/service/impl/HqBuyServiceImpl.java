package io.renren.modules.houqin.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.renren.common.utils.ReadParamsUtils;
import io.renren.modules.houqin.entity.vo.HqBuyEntityVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Map;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.Query;

import io.renren.modules.houqin.dao.HqBuyDao;
import io.renren.modules.houqin.entity.HqBuyEntity;
import io.renren.modules.houqin.service.HqBuyService;


@Service("hqBuyService")
public class HqBuyServiceImpl extends ServiceImpl<HqBuyDao, HqBuyEntity> implements HqBuyService {

    @Autowired
    HqBuyDao hqBuyDao;
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        IPage<HqBuyEntity> page = this.page(
                new Query<HqBuyEntity>().getPage(params),
                new QueryWrapper<HqBuyEntity>()
        );

        return new PageUtils(page);
    }

    @Override
    public PageUtils selectPageVo(Map<String, Object> params) {
        Page<HqBuyEntityVo> page = new ReadParamsUtils<HqBuyEntityVo>().getPage(params);
        QueryWrapper<HqBuyEntityVo> wrapper = new QueryWrapper<>();
        wrapper.eq("hb.is_delete",1);
        if(params.get("key")!=null&&params.get("key").toString().trim().length()>0){
            wrapper.in("hb.buy_id",params.get("key").toString().trim().split(",|，|\\s"));
        }
        return new PageUtils(hqBuyDao.selectPageVo(page,wrapper));
    }

}