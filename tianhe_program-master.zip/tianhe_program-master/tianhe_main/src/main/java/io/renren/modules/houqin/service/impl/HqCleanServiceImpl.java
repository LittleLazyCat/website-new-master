package io.renren.modules.houqin.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.renren.common.utils.ReadParamsUtils;
import io.renren.modules.houqin.entity.vo.HqCleanEntityVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Map;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.Query;

import io.renren.modules.houqin.dao.HqCleanDao;
import io.renren.modules.houqin.entity.HqCleanEntity;
import io.renren.modules.houqin.service.HqCleanService;


@Service("hqCleanService")
public class HqCleanServiceImpl extends ServiceImpl<HqCleanDao, HqCleanEntity> implements HqCleanService {
    @Autowired
    HqCleanDao hqCleanDao;
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        IPage<HqCleanEntity> page = this.page(
                new Query<HqCleanEntity>().getPage(params),
                new QueryWrapper<HqCleanEntity>()
        );

        return new PageUtils(page);
    }

    @Override
    public PageUtils selectPageVo(Map<String, Object> params) {
        Page<HqCleanEntityVo> page = new ReadParamsUtils<HqCleanEntityVo>().getPage(params);
        QueryWrapper<HqCleanEntityVo> wrapper = new QueryWrapper<>();
        wrapper.eq("hc.is_delete",1);
        if(params.get("key")!=null&&params.get("key").toString().trim().length()>0){
            wrapper.in("hc.id",params.get("key").toString().trim().split(",|，|\\s"));
        }
        return new PageUtils(hqCleanDao.selectPageVo(page,wrapper));
    }

}