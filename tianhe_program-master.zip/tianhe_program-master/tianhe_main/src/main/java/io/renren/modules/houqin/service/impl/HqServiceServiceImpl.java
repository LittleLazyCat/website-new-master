package io.renren.modules.houqin.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.renren.common.utils.ReadParamsUtils;
import io.renren.modules.houqin.entity.vo.HqServiceEntityVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Map;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.Query;

import io.renren.modules.houqin.dao.HqServiceDao;
import io.renren.modules.houqin.entity.HqServiceEntity;
import io.renren.modules.houqin.service.HqServiceService;


@Service("hqServiceService")
public class HqServiceServiceImpl extends ServiceImpl<HqServiceDao, HqServiceEntity> implements HqServiceService {
    @Autowired
    HqServiceDao hqServiceDao;

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        IPage<HqServiceEntity> page = this.page(
                new Query<HqServiceEntity>().getPage(params),
                new QueryWrapper<HqServiceEntity>()
        );

        return new PageUtils(page);
    }

    @Override
    public PageUtils selectPageVo(Map<String, Object> params) {
        Page<HqServiceEntityVo> page = new ReadParamsUtils<HqServiceEntityVo>().getPage(params);
        QueryWrapper<HqServiceEntityVo> wrapper = new QueryWrapper<>();
        wrapper.eq("hs.is_delete", 1);
        if (params.get("key") != null && params.get("key").toString().trim().length() > 0) {
            wrapper.in("hs.eq_id", params.get("key").toString().trim().split(",|，|\\s"));
        }
        return new PageUtils(hqServiceDao.selectPageVo(page, wrapper));
    }
}