package io.renren.modules.mysys.controller;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.renren.modules.mysys.entity.MySysEmployeeEntity;
import io.renren.modules.mysys.service.MySysEmployeeService;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.R;



/**
 * 
 *
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-05-17 13:34:13
 */
@RestController
@RequestMapping("mysys/sysemployee")
public class MySysEmployeeController {
    @Autowired
    private MySysEmployeeService sysEmployeeService;

    /**
     * 列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("mysys:sysemployee:list")
    public R list(@RequestParam Map<String, Object> params){
        //PageUtils page = sysEmployeeService.queryPage(params);
        PageUtils page = sysEmployeeService.selectPageVo(params);

        return R.ok().put("page", page);
    }


    /**
     * 信息
     */
    @RequestMapping("/info/{id}")
    @RequiresPermissions("mysys:sysemployee:info")
    public R info(@PathVariable("id") Integer id){
		MySysEmployeeEntity sysEmployee = sysEmployeeService.getById(id);

        return R.ok().put("sysEmployee", sysEmployee);
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    @RequiresPermissions("mysys:sysemployee:save")
    public R save(@RequestBody MySysEmployeeEntity sysEmployee){
		sysEmployeeService.save(sysEmployee);

        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    @RequiresPermissions("mysys:sysemployee:update")
    public R update(@RequestBody MySysEmployeeEntity sysEmployee){
		sysEmployeeService.updateById(sysEmployee);

        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @RequiresPermissions("mysys:sysemployee:delete")
    public R delete(@RequestBody Integer[] ids){
		sysEmployeeService.removeByIds(Arrays.asList(ids));

        return R.ok();
    }

    /**
     * 获取相同权限的职工列表
     */
    @RequestMapping("/getEmpListByRole/{roleId}")
    public R getEmpListByRole(@PathVariable("roleId")Integer roleId){
        if(roleId!=null){
            QueryWrapper<MySysEmployeeEntity> wrapper = new QueryWrapper<>();
            wrapper.eq("emp_role_id",roleId);
            List<MySysEmployeeEntity> list = sysEmployeeService.list(wrapper);
            return R.ok().put("data",list);
        }
        return R.error().put("roleId",roleId);
    }
}
