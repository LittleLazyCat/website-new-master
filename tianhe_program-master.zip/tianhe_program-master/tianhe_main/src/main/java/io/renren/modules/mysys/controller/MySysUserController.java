package io.renren.modules.mysys.controller;

import java.util.Arrays;
import java.util.Map;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.renren.modules.mysys.entity.MySysUserEntity;
import io.renren.modules.mysys.service.MySysUserService;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.R;



/**
 * 
 *
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-05-17 13:34:13
 */
@RestController
@RequestMapping("mysys/sysuser")
public class MySysUserController {
    @Autowired
    private MySysUserService sysUserService;

    /**
     * 列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("mysys:sysuser:list")
    public R list(@RequestParam Map<String, Object> params){
        PageUtils page = sysUserService.queryPage(params);

        return R.ok().put("page", page);
    }


    /**
     * 信息
     */
    @RequestMapping("/info/{id}")
    @RequiresPermissions("mysys:sysuser:info")
    public R info(@PathVariable("id") Integer id){
		MySysUserEntity sysUser = sysUserService.getById(id);

        return R.ok().put("sysUser", sysUser);
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    @RequiresPermissions("mysys:sysuser:save")
    public R save(@RequestBody MySysUserEntity sysUser){
		sysUserService.save(sysUser);

        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    @RequiresPermissions("mysys:sysuser:update")
    public R update(@RequestBody MySysUserEntity sysUser){
		sysUserService.updateById(sysUser);

        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @RequiresPermissions("mysys:sysuser:delete")
    public R delete(@RequestBody Integer[] ids){
		sysUserService.removeByIds(Arrays.asList(ids));

        return R.ok();
    }

}
