package io.renren.modules.mysys.dao;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import io.renren.modules.mysys.entity.MySysEmployeeEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import io.renren.modules.mysys.entity.vo.MySysEmployeeEntityVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

/**
 * 
 * 
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-05-17 13:34:13
 */
@Mapper
public interface MySysEmployeeDao extends BaseMapper<MySysEmployeeEntity> {
	IPage<MySysEmployeeEntityVo> selectPageVo(Page<MySysEmployeeEntityVo> page, @Param(Constants.WRAPPER)QueryWrapper<MySysEmployeeEntityVo> wrapper);
}
