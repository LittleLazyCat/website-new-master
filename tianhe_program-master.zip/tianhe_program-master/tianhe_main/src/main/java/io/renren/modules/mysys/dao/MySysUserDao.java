package io.renren.modules.mysys.dao;

import io.renren.modules.mysys.entity.MySysUserEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 
 * 
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-05-17 13:34:13
 */
@Mapper
public interface MySysUserDao extends BaseMapper<MySysUserEntity> {
	
}
