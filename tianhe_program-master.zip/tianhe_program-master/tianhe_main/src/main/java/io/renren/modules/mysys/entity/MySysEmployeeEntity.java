package io.renren.modules.mysys.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 
 * 
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-05-17 13:34:13
 */
@Data
@TableName("tb_sys_employee")
public class MySysEmployeeEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 职工id: 主键自增长
	 */
	@TableId
	private Integer id;
	/**
	 * 职工姓名
	 */
	private String empName;
	/**
	 * 职工头像
	 */
	private String headImgUrl;
	/**
	 * 职工电话
	 */
	private String empPhone;
	/**
	 * 职工权限id：外键
	 */
	private Integer empRoleId;
	/**
	 * 职工住址
	 */
	private String empAddress;
	/**
	 * 职工身份证,唯一值
	 */
	private String empIdentity;
	/**
	 * 创建时间
	 */
	@TableField(fill = FieldFill.INSERT)
	private Date createTime;
	/**
	 * 更新时间
	 */
	@TableField(fill = FieldFill.INSERT_UPDATE)
	private Date updateTime;
	/**
	 * 默认值为1,0表示已删除
	 */
	@TableLogic
	private Integer isDelete;

}
