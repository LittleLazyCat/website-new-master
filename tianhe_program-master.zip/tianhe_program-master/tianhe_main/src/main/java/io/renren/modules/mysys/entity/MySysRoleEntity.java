package io.renren.modules.mysys.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 
 * 
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-05-17 13:34:13
 */
@Data
@TableName("tb_sys_role")
public class MySysRoleEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 权限id
	 */
	@TableId
	private Integer id;
	/**
	 * 权限名称
	 */
	private String roleName;
	/**
	 * 1  普通用户    
2  在住客户   
3  工作人员   
4  系统人员
	 */
	private Integer roleLevel;
	/**
	 * 描述权限
	 */
	private String roleDesc;
	/**
	 * 创建时间
	 */
	@TableField(fill = FieldFill.INSERT)
	private Date createTime;
	/**
	 * 更新时间
	 */
	@TableField(fill = FieldFill.INSERT_UPDATE)
	private Date updateTime;
	/**
	 * 默认值为1,0表示已删除
	 */
	@TableLogic
	private Integer isDelete;

}
