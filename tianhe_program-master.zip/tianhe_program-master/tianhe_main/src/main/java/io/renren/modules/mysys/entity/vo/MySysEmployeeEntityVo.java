package io.renren.modules.mysys.entity.vo;

import io.renren.modules.mysys.entity.MySysEmployeeEntity;
import lombok.Data;

/**
 * @Description:
 * @Author: tanyajun
 * @CreateTime: 2021/5/18
 * @Blog: https://tanyajun.top
 */
@Data
public class MySysEmployeeEntityVo extends MySysEmployeeEntity {
    private String roleName;
    private String roleDesc;
    private String roleLevel;
}
