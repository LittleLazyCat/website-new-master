package io.renren.modules.mysys.service;

import com.baomidou.mybatisplus.extension.service.IService;
import io.renren.common.utils.PageUtils;
import io.renren.modules.mysys.entity.MySysRoleEntity;

import java.util.Map;

/**
 * 
 *
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-05-17 13:34:13
 */
public interface MySysRoleService extends IService<MySysRoleEntity> {

    PageUtils queryPage(Map<String, Object> params);
}

