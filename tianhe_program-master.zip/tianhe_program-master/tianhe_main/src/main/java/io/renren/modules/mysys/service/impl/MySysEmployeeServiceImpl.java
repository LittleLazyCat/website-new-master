package io.renren.modules.mysys.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.renren.common.utils.ReadParamsUtils;
import io.renren.modules.mysys.entity.vo.MySysEmployeeEntityVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Map;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.Query;

import io.renren.modules.mysys.dao.MySysEmployeeDao;
import io.renren.modules.mysys.entity.MySysEmployeeEntity;
import io.renren.modules.mysys.service.MySysEmployeeService;


@Service("mySysEmployeeService")
public class MySysEmployeeServiceImpl extends ServiceImpl<MySysEmployeeDao, MySysEmployeeEntity> implements MySysEmployeeService {
    @Autowired
    MySysEmployeeDao mySysEmployeeDao;
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        IPage<MySysEmployeeEntity> page = this.page(
                new Query<MySysEmployeeEntity>().getPage(params),
                new QueryWrapper<MySysEmployeeEntity>()
        );

        return new PageUtils(page);
    }

    @Override
    public PageUtils selectPageVo(Map<String, Object> params) {
        Page<MySysEmployeeEntityVo> page = new ReadParamsUtils<MySysEmployeeEntityVo>().getPage(params);
        QueryWrapper<MySysEmployeeEntityVo> wrapper = new QueryWrapper<>();
        wrapper.eq("se.is_delete",1);
        if(params.get("key")!=null&&params.get("key").toString().trim().length()>0){
            wrapper.in("se.id",params.get("key").toString().trim().split(",|，|\\s"));
        }
        wrapper.orderByAsc("se.emp_role_id").orderByDesc("se.create_time");
        return new PageUtils(mySysEmployeeDao.selectPageVo(page, wrapper));
    }

}