package io.renren.modules.mysys.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.Query;

import io.renren.modules.mysys.dao.MySysRoleDao;
import io.renren.modules.mysys.entity.MySysRoleEntity;
import io.renren.modules.mysys.service.MySysRoleService;


@Service("mySysRoleService")
public class MySysRoleServiceImpl extends ServiceImpl<MySysRoleDao, MySysRoleEntity> implements MySysRoleService {

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        QueryWrapper<MySysRoleEntity> wrapper = new QueryWrapper<>();
        if(params.get("key")!=null&&params.get("key").toString().trim().length()>0){
            wrapper.in("id",params.get("key").toString().trim().split(",|，|\\s"));
        }
        IPage<MySysRoleEntity> page = this.page(
                new Query<MySysRoleEntity>().getPage(params),
                wrapper
        );

        return new PageUtils(page);
    }

}