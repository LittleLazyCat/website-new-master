package io.renren.modules.oss.entity;

import lombok.Data;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * @Description:
 * @Author: tanyajun
 * @CreateTime: 2021/5/6
 * @Blog: https://tanyajun.top
 */
@Data
@ConfigurationProperties(prefix = "oss")
public class AliOssEntity implements InitializingBean {
    private String accessId;
    public static String ACCESS_ID;
    private String accessKey;
    public static String ACCESS_KEY;
    private String endpoint;
    public static String ENDPOINT;
    private String bucket;
    public static String BUCKET;
    public static String HOST;


    @Override
    public void afterPropertiesSet() throws Exception {
        ACCESS_ID=this.accessId;
        ACCESS_KEY=this.accessKey;
        ENDPOINT=this.endpoint;
        BUCKET=this.bucket;
        HOST="https://" + BUCKET + "." + ENDPOINT;
    }
}
