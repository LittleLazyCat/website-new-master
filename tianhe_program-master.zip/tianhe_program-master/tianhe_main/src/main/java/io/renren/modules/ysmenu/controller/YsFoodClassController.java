package io.renren.modules.ysmenu.controller;

import java.util.Arrays;
import java.util.Map;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.renren.modules.ysmenu.entity.YsFoodClassEntity;
import io.renren.modules.ysmenu.service.YsFoodClassService;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.R;



/**
 * 
 *
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-05-07 10:26:43
 */
@RestController
@RequestMapping("ysmenu/ysfoodclass")
public class YsFoodClassController {
    @Autowired
    private YsFoodClassService ysFoodClassService;

    /**
     * 列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("ysmenu:ysfoodclass:list")
    public R list(@RequestParam Map<String, Object> params){
        PageUtils page = ysFoodClassService.queryPage(params);

        return R.ok().put("page", page);
    }


    /**
     * 信息
     */
    @RequestMapping("/info/{classifyId}")
    @RequiresPermissions("ysmenu:ysfoodclass:info")
    public R info(@PathVariable("classifyId") Integer classifyId){
		YsFoodClassEntity ysFoodClass = ysFoodClassService.getById(classifyId);

        return R.ok().put("ysFoodClass", ysFoodClass);
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    @RequiresPermissions("ysmenu:ysfoodclass:save")
    public R save(@RequestBody YsFoodClassEntity ysFoodClass){
		ysFoodClassService.save(ysFoodClass);

        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    @RequiresPermissions("ysmenu:ysfoodclass:update")
    public R update(@RequestBody YsFoodClassEntity ysFoodClass){
		ysFoodClassService.updateById(ysFoodClass);

        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @RequiresPermissions("ysmenu:ysfoodclass:delete")
    public R delete(@RequestBody Integer[] classifyIds){
		ysFoodClassService.removeByIds(Arrays.asList(classifyIds));

        return R.ok();
    }

}
