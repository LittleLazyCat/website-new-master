package io.renren.modules.ysmenu.controller;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.renren.modules.ysmenu.entity.YsFoodMenuEntity;
import io.renren.modules.ysmenu.service.YsFoodMenuService;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.R;



/**
 * 
 *
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-04-29 19:15:41
 */
@RestController
@RequestMapping("ysmenu/ysfoodmenu")
public class YsFoodMenuController {
    @Autowired
    private YsFoodMenuService ysFoodMenuService;

    /**
     * 列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("ysmenu:ysfoodmenu:list")
    public R list(@RequestParam Map<String, Object> params){
        PageUtils page = ysFoodMenuService.queryPage(params);

        return R.ok().put("page", page);
    }


    /**
     * 信息
     */
    @RequestMapping("/info/{foodId}")
    @RequiresPermissions("ysmenu:ysfoodmenu:info")
    public R info(@PathVariable("foodId") Integer foodId){
		YsFoodMenuEntity ysFoodMenu = ysFoodMenuService.getById(foodId);

        return R.ok().put("ysFoodMenu", ysFoodMenu);
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    @RequiresPermissions("ysmenu:ysfoodmenu:save")
    public R save(@RequestBody YsFoodMenuEntity ysFoodMenu){
		ysFoodMenuService.save(ysFoodMenu);

        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    @RequiresPermissions("ysmenu:ysfoodmenu:update")
    public R update(@RequestBody YsFoodMenuEntity ysFoodMenu){
		ysFoodMenuService.updateById(ysFoodMenu);

        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @RequiresPermissions("ysmenu:ysfoodmenu:delete")
    public R delete(@RequestBody Integer[] foodIds){
		ysFoodMenuService.removeByIds(Arrays.asList(foodIds));

        return R.ok();
    }
    @RequestMapping("/list_no_page")
    public R getFoodMenu(){
        List<YsFoodMenuEntity> data = ysFoodMenuService.list();

        return R.ok().put("data",data);
    }
}
