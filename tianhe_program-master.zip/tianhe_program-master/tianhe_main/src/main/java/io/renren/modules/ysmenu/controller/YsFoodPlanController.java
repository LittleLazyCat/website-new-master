package io.renren.modules.ysmenu.controller;

import java.util.Arrays;
import java.util.Map;

import io.renren.modules.fy.entity.FyOrderEntity;
import io.renren.modules.fy.service.FyOrderService;
import io.renren.modules.hl.entity.HlProjectEntity;
import io.renren.modules.ysmenu.entity.YsFoodMenuEntity;
import io.renren.modules.ysmenu.service.YsFoodMenuService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.renren.modules.ysmenu.entity.YsFoodPlanEntity;
import io.renren.modules.ysmenu.service.YsFoodPlanService;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.R;



/**
 * 
 *
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-05-07 10:26:43
 */
@RestController
@RequestMapping("ysmenu/ysfoodplan")
public class YsFoodPlanController {
    @Autowired
    private YsFoodPlanService ysFoodPlanService;
    @Autowired
    private YsFoodMenuService ysFoodMenuService;
    @Autowired
    private FyOrderService fyOrderService;
    /**
     * 列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("ysmenu:ysfoodplan:list")
    public R list(@RequestParam Map<String, Object> params){
        //PageUtils page = ysFoodPlanService.queryPage(params);
        PageUtils page = ysFoodPlanService.selectPageVo(params);

        return R.ok().put("page", page);
    }


    /**
     * 信息
     */
    @RequestMapping("/info/{id}")
    @RequiresPermissions("ysmenu:ysfoodplan:info")
    public R info(@PathVariable("id") Integer id){
		YsFoodPlanEntity ysFoodPlan = ysFoodPlanService.getById(id);

        return R.ok().put("ysFoodPlan", ysFoodPlan);
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    @RequiresPermissions("ysmenu:ysfoodplan:save")
    public R save(@RequestBody YsFoodPlanEntity ysFoodPlan){
        boolean isSave = ysFoodPlanService.save(ysFoodPlan);
        if(isSave){
            // 开立护理记录之后生成对应的费用订单entity
            FyOrderEntity fyOrderEntity = new FyOrderEntity();
            // 客户id
            fyOrderEntity.setCustomerId(ysFoodPlan.getCustomerId());
            // 订单类型
            fyOrderEntity.setOrderType("饮食");
            // 订单数量
            fyOrderEntity.setOrderNum(1);
            // 根据所选项目id得到项目信息
            YsFoodMenuEntity project = ysFoodMenuService.getById(ysFoodPlan.getFoodId());
            // 设置项目名称
            fyOrderEntity.setOrderName(project.getFoodName());
            // 设置总价
            fyOrderEntity.setOrderCost(fyOrderEntity.getOrderNum()*project.getFoodPrice());
            fyOrderEntity.setPayState(0);
            // 写入
            boolean save = fyOrderService.save(fyOrderEntity);
            System.out.println(save?"开立饮食项目成功":"开立饮食项目失败");
        }
        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    @RequiresPermissions("ysmenu:ysfoodplan:update")
    public R update(@RequestBody YsFoodPlanEntity ysFoodPlan){
		ysFoodPlanService.updateById(ysFoodPlan);

        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @RequiresPermissions("ysmenu:ysfoodplan:delete")
    public R delete(@RequestBody Integer[] ids){
		ysFoodPlanService.removeByIds(Arrays.asList(ids));

        return R.ok();
    }

}
