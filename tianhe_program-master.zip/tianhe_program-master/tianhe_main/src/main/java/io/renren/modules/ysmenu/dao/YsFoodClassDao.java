package io.renren.modules.ysmenu.dao;

import io.renren.modules.ysmenu.entity.YsFoodClassEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 
 * 
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-05-07 10:26:43
 */
@Mapper
public interface YsFoodClassDao extends BaseMapper<YsFoodClassEntity> {
	
}
