package io.renren.modules.ysmenu.dao;

import io.renren.modules.ysmenu.entity.YsFoodMenuEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 
 * 
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-04-29 19:15:41
 */
@Mapper
public interface YsFoodMenuDao extends BaseMapper<YsFoodMenuEntity> {
	
}
