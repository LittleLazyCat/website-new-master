package io.renren.modules.ysmenu.dao;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.renren.modules.ysmenu.entity.YsFoodPlanEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import io.renren.modules.ysmenu.entity.vo.YsFoodPlanEntityVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * 
 * 
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-05-07 10:26:43
 */
@Mapper
public interface YsFoodPlanDao extends BaseMapper<YsFoodPlanEntity> {
	IPage<YsFoodPlanEntityVo> selectPageVo(Page<YsFoodPlanEntityVo> page, @Param(Constants.WRAPPER)QueryWrapper<YsFoodPlanEntityVo>wrapper);
}
