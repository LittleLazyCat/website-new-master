package io.renren.modules.ysmenu.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 
 * 
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-05-07 10:26:43
 */
@Data
@TableName("tb_ys_food_class")
public class YsFoodClassEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 分类id
	 */
	@TableId
	private Integer classifyId;
	/**
	 * 分类名称
	 */
	private String classifyName;
	/**
	 * 分类描述
	 */
	private String classifyDesc;
	/**
	 * 创建时间
	 */
	@TableField(fill = FieldFill.INSERT)
	private Date createTime;
	/**
	 * 更新时间
	 */
	@TableField(fill = FieldFill.INSERT_UPDATE)
	private Date updateTime;
	/**
	 * 默认为1，0表示删除
	 */
	@TableLogic
	private Integer isDelete;

}
