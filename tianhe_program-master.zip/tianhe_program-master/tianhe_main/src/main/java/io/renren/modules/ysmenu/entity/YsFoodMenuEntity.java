package io.renren.modules.ysmenu.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 
 * 
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-04-29 19:15:41
 */
@Data
@TableName("tb_ys_food_menu")
public class YsFoodMenuEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 食品id
	 */
	@TableId
	private Integer foodId;
	/**
	 * 食品名称
	 */
	private String foodName;
	/**
	 * 食品类别
	 */
	private Integer classifyId;
	/**
	 * 食品标签
	 */
	private String foodTag;
	/**
	 * 食品价格
	 */
	private Double foodPrice;
	/**
	 * 是否清真
	 */
	private Integer foodQingzhen;
	/**
	 * 供应星期1-7（默认1）
	 */
	private Integer supplyWeek;
	/**
	 * 供应类型1早餐2午餐3晚餐
	 */
	private Integer supplyKind;
	/**
	 * 创建时间
	 */
	@TableField(fill = FieldFill.INSERT)
	private Date createTime;
	/**
	 * 更新时间
	 */
	@TableField(fill = FieldFill.INSERT_UPDATE)
	private Date updateTime;
	/**
	 * 默认为1，0表示删除
	 */
	@TableLogic
	private Integer isDelete;

}
