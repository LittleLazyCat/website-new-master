package io.renren.modules.ysmenu.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 
 * 
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-05-07 10:26:43
 */
@Data
@TableName("tb_ys_food_plan")
public class YsFoodPlanEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 膳食计划id：主键 自增
	 */
	@TableId
	private Integer id;
	/**
	 * 客户id：参照客户档案id
	 */
	private Integer customerId;
	/**
	 * 饮食id：参照饮食菜单中id
	 */
	private Integer foodId;
	/**
	 * 计划周期:(星期)1-7
	 */
	private Integer planDay;
	/**
	 * 创建时间
	 */
	@TableField(fill = FieldFill.INSERT)
	private Date createTime;
	/**
	 * 更新时间
	 */
	@TableField(fill = FieldFill.INSERT_UPDATE)
	private Date updateTime;
	/**
	 * 默认为1，0表示删除
	 */
	@TableLogic
	private Integer isDelete;

}
