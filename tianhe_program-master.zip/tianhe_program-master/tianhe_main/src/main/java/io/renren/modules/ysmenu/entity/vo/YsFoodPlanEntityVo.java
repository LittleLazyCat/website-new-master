package io.renren.modules.ysmenu.entity.vo;

import io.renren.modules.ysmenu.entity.YsFoodPlanEntity;
import lombok.Data;

/**
 * @Description:
 * @Author: tanyajun
 * @CreateTime: 2021/5/17
 * @Blog: https://tanyajun.top
 */
@Data
public class YsFoodPlanEntityVo extends YsFoodPlanEntity {
    private Integer ckiId;
    private String customerName;
    private String identityNumber;
    private String foodName;
    private Double foodPrice;
}
