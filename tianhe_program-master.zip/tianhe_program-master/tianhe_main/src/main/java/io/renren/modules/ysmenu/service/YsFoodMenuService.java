package io.renren.modules.ysmenu.service;

import com.baomidou.mybatisplus.extension.service.IService;
import io.renren.common.utils.PageUtils;
import io.renren.modules.ysmenu.entity.YsFoodMenuEntity;

import java.util.Map;

/**
 * 
 *
 * @author tanyajun
 * @email tan82692586@gmail.com
 * @date 2021-04-29 19:15:41
 */
public interface YsFoodMenuService extends IService<YsFoodMenuEntity> {

    PageUtils queryPage(Map<String, Object> params);
}

