package io.renren.modules.ysmenu.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.Query;

import io.renren.modules.ysmenu.dao.YsFoodClassDao;
import io.renren.modules.ysmenu.entity.YsFoodClassEntity;
import io.renren.modules.ysmenu.service.YsFoodClassService;


@Service("ysFoodClassService")
public class YsFoodClassServiceImpl extends ServiceImpl<YsFoodClassDao, YsFoodClassEntity> implements YsFoodClassService {

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        QueryWrapper<YsFoodClassEntity> wrapper = new QueryWrapper<>();
        if(params.get("key")!=null&&params.get("key").toString().trim().length()>0){
            wrapper.in("classify_id",params.get("key").toString().trim().split(",|，|\\s"));
        }
        IPage<YsFoodClassEntity> page = this.page(
                new Query<YsFoodClassEntity>().getPage(params),
                wrapper
        );

        return new PageUtils(page);
    }

}