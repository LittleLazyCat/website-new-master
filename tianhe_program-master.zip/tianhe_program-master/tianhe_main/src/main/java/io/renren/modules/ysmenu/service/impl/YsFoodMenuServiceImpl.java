package io.renren.modules.ysmenu.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.Query;

import io.renren.modules.ysmenu.dao.YsFoodMenuDao;
import io.renren.modules.ysmenu.entity.YsFoodMenuEntity;
import io.renren.modules.ysmenu.service.YsFoodMenuService;


@Service("ysFoodMenuService")
public class YsFoodMenuServiceImpl extends ServiceImpl<YsFoodMenuDao, YsFoodMenuEntity> implements YsFoodMenuService {

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        QueryWrapper<YsFoodMenuEntity> wrapper = new QueryWrapper<>();
        if(params.get("key")!=null&&params.get("key").toString().trim().length()>0){
            wrapper.in("food_id",params.get("key").toString().trim().split(",|，|\\s"));
        }
        IPage<YsFoodMenuEntity> page = this.page(
                new Query<YsFoodMenuEntity>().getPage(params),
                wrapper
        );

        return new PageUtils(page);
    }

}