package io.renren.modules.ysmenu.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.renren.common.utils.ReadParamsUtils;
import io.renren.modules.ysmenu.entity.vo.YsFoodPlanEntityVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Map;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.Query;

import io.renren.modules.ysmenu.dao.YsFoodPlanDao;
import io.renren.modules.ysmenu.entity.YsFoodPlanEntity;
import io.renren.modules.ysmenu.service.YsFoodPlanService;


@Service("ysFoodPlanService")
public class YsFoodPlanServiceImpl extends ServiceImpl<YsFoodPlanDao, YsFoodPlanEntity> implements YsFoodPlanService {
    @Autowired
    YsFoodPlanDao ysFoodPlanDao;
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        IPage<YsFoodPlanEntity> page = this.page(
                new Query<YsFoodPlanEntity>().getPage(params),
                new QueryWrapper<YsFoodPlanEntity>()
        );

        return new PageUtils(page);
    }

    @Override
    public PageUtils selectPageVo(Map<String, Object> params) {
        Page<YsFoodPlanEntityVo> page = new ReadParamsUtils<YsFoodPlanEntityVo>().getPage(params);
        QueryWrapper<YsFoodPlanEntityVo> wrapper = new QueryWrapper<>();
        wrapper.eq("fp.is_delete",1).eq("ci.is_delete",1).eq("ci.valid_state",1);
        if(params.get("key")!=null&&params.get("key").toString().trim().length()>0){
            wrapper.in("fp.id",params.get("key").toString().trim().split(",|，|\\s"));
        }
        IPage<YsFoodPlanEntityVo> iPage = ysFoodPlanDao.selectPageVo(page,wrapper);
        return new PageUtils(iPage);
    }

}