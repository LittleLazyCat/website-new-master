package io.renren;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import io.renren.modules.customer.dao.InfoOutRecordsDao;
import io.renren.modules.customer.entity.vo.InfoOutEntityVo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

/**
 * @Description:
 * @Author: tanyajun
 * @CreateTime: 2021/5/12
 * @Blog: https://tanyajun.top
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class Test01 {
    @Autowired
    InfoOutRecordsDao infoOutRecordsDao;
    @Test
    public void test(){
        // this is a JUnit test method
        /*InfoOutEntityVo entityVo = infoOutRecordsDao.selectVoById(1);
        System.out.println(entityVo);*/
        QueryWrapper<InfoOutEntityVo> wrapper = new QueryWrapper<>();
        List<InfoOutEntityVo> infoOutEntityVos = infoOutRecordsDao.selectVoByWrapper(wrapper);
        System.out.println(infoOutEntityVos);
    }
}
