<template>
  <transition name="fade">
    <router-view></router-view>
  </transition>
</template>

<script>
  export default {
    methods:{}
  }
</script>
<style>
  @import url("./assets/myfont/font1.css");
  @import url("./assets/myfont/font2.css");
  @import url("./assets/myfont/font3.css");
</style>
