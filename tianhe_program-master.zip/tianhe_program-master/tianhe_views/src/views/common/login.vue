<template>
    <div class="site-wrapper site-page--login"  @mousemove="getMosueLoc">
      <div class="site-content__wrapper">
        <div class="site-content">
          <div class="brand-info">
            <p class="brand-info__text">颐养天<span style="font-size: 256px;">和</span></p>
            <p class="brand-info__intro">我们对长者的照护与陪伴充满热忱，并以介护为职者，持有一个温暖的心，致力于为长者创造安心、安全、舒适的生活环境。</p>
          </div>
          <div class="login-main">
            <h3 class="login-title">管理员登录</h3>
            <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" status-icon>
              <el-form-item prop="userName">
                <el-input v-model="dataForm.userName" placeholder="帐号"></el-input>
              </el-form-item>
              <el-form-item prop="password">
                <el-input v-model="dataForm.password" type="password" placeholder="密码"></el-input>
              </el-form-item>
              <el-form-item prop="captcha">
                <el-row :gutter="20">
                  <el-col :span="14">
                    <el-input v-model="dataForm.captcha" placeholder="验证码">
                    </el-input>
                  </el-col>
                  <el-col :span="10" class="login-captcha">
                    <img :src="captchaPath" @click="getCaptcha()" alt="">
                  </el-col>
                </el-row>
              </el-form-item>
              <el-form-item>
                <el-button class="login-btn-submit" type="primary" @click="dataFormSubmit()">登录</el-button>
              </el-form-item>
            </el-form>
          </div>
        </div>
      </div>
      <canvas id="Mycanvas"></canvas>
    </div>
</template>

<script>
  import { getUUID } from '@/utils'
  export default {
    data () {
      return {
        context:{},
        width:0,
        height:0,
        point:50,
        circleArr:[],
        dataForm: {
          userName: 'admin',
          password: '789789',
          uuid: '',
          captcha: ''
        },
        dataRule: {
          userName: [
            { required: true, message: '帐号不能为空', trigger: 'blur' }
          ],
          password: [
            { required: true, message: '密码不能为空', trigger: 'blur' }
          ],
          captcha: [
            { required: true, message: '验证码不能为空', trigger: 'blur' }
          ]
        },
        captchaPath: ''
      }
    },
    mounted() {
      this.width=window.innerWidth
      this.height=window.innerHeight
      const canvas = document.querySelector('#Mycanvas')
      canvas.width = this.width
      canvas.height = this.height
      this.context = canvas.getContext('2d')
      this.context.strokeStyle = 'rgba(250,250,250,0.45)',
      this.context.strokeWidth = 1,
      this.context.fillStyle = 'rgb(255,255,255)';
      console.log(this.context,this.width,this.height);
      this.init()
      setInterval(()=>{
        for (let i = 0; i < this.point; i++) {
        	let cir = this.circleArr[i];
        	cir.x += cir.moveX;
        	cir.y += cir.moveY;
        	if (cir.x > this.width) cir.x = 0;
        	else if (cir.x < 0) cir.x = this.width;
        	if (cir.y > this.height) cir.y = 0;
        	else if (cir.y < 0) cir.y = this.height;
        }
        this.draw();
      },5)
    },
    created () {
      this.getCaptcha()
    },
    methods: {
      // 提交表单
      dataFormSubmit () {
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            this.$http({
              url: this.$http.adornUrl('/sys/login'),
              method: 'post',
              data: this.$http.adornData({
                'username': this.dataForm.userName,
                'password': this.dataForm.password,
                'uuid': this.dataForm.uuid,
                'captcha': this.dataForm.captcha
              })
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.$cookie.set('token', data.token)
                this.$router.replace({ name: 'home' })
              } else {
                this.getCaptcha()
                this.$message.error(data.msg)
              }
            })
          }
        })
      },
      // 获取验证码
      getCaptcha () {
        this.dataForm.uuid = getUUID()
        this.captchaPath = this.$http.adornUrl(`/captcha.jpg?uuid=${this.dataForm.uuid}`)
      },
    //初始化生成原点
      init () {
        this.circleArr = [];
        for (let i = 0; i < this.point; i++) {
          this.circleArr.push(this.drawCricle(this.context, this.num(this.width), this.num(this.height), this.num(2, 2), this.num(10, -10)/40, this.num(10, -10)/40));
        }
        //draw();
      },
      // 绘制原点
      drawCricle (cxt, x, y, r, moveX, moveY) {
      	let circle = {x,y,r,moveX,moveY}
      	cxt.beginPath()
      	cxt.arc(circle.x, circle.y, circle.r, 0, 2*Math.PI)
      	cxt.closePath()
      	cxt.fill();
      	return circle;
      },
      //生成max和min之间的随机数
      num (max, _min) {
      	let min = arguments[1] || 0;
      	return Math.floor(Math.random()*(max-min+1)+min);
      },
      //每帧绘制
      draw () {
      	this.context.clearRect(0,0,this.width, this.height);
      	for (let i = 0; i < this.point; i++) {
      		this.drawCricle(this.context, this.circleArr[i].x, this.circleArr[i].y, this.circleArr[i].r);
      	}
      	for (let i = 0; i < this.point; i++) {
      		for (let j = 0; j < this.point; j++) {
      			if (i + j < this.point) {
      				let A = Math.abs(this.circleArr[i+j].x - this.circleArr[i].x),
      					B = Math.abs(this.circleArr[i+j].y - this.circleArr[i].y);
      				let lineLength = Math.sqrt(A*A + B*B);
      				let C = 1/lineLength*7-0.009;
      				let lineOpacity = C > 0.5 ? 0.5 : C;
      				if (lineOpacity > 0) {
      					this.drawLine(this.context, this.circleArr[i].x, this.circleArr[i].y, this.circleArr[i+j].x, this.circleArr[i+j].y, lineOpacity);
      				}
      			}
      		}
      	}
      },
      //绘制线条
      drawLine (cxt, x, y, _x, _y, o) {
      	var line = {beginX : x, beginY : y, closeX : _x, closeY : _y, o : o}
      	cxt.beginPath()
      	cxt.strokeStyle = 'rgba(255,255,255,'+ o +')'
      	cxt.moveTo(line.beginX, line.beginY)
      	cxt.lineTo(line.closeX, line.closeY)
      	cxt.closePath()
      	cxt.stroke();
      },
      getRGBA(){
        let R=Math.floor(Math.random()*255)
        let G=Math.floor(Math.random()*255)
        let B=Math.floor(Math.random()*255)
        return 'rgba('+R+','+G+','+B+',0.5)';
      },
      getMosueLoc(e){
      }
    }
  }
</script>

<style lang="scss">
  .site-wrapper.site-page--login {
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    background-color: rgba(38, 50, 56, .6);
    overflow: hidden;
    &:before {
      position: fixed;
      top: 0;
      left: 0;
      z-index: -1;
      width: 100%;
      height: 100%;
      content: "";
      background-image: linear-gradient(to bottom ,#4a9dd4,#de5d5f);
      background-size: cover;
    }
    .site-content__wrapper {
      position: absolute;
      top: 0;
      right: 0;
      bottom: 0;
      left: 0;
      padding: 0;
      margin: 0;
      overflow-x: hidden;
      overflow-y: auto;
      background-color: transparent;
    }
    .site-content {
      min-height: 100%;
      padding: 20px 500px 30px 30px;
    }
    .brand-info {
      margin: 220px 100px 0 90px;
      color: #fff;
    }
    .brand-info__text {
      margin:  0 0 22px 0;
      font-size: 48px;
      font-weight: 400;
      text-transform : uppercase;
      font-family: chineseC;
      font-size: 128px;
    }
    .brand-info__intro {
      margin: 10px 0;
      line-height: 1.58;
      opacity: .6;
      font-family: chineseA;
      font-size: 32px;
    }
    .login-main {
      position: absolute;
      top: 0;
      right: 0;
      padding: 60px 60px 0px;
      margin-top: 10%;
      width: 470px;
      min-height: 50%;
      border-radius: 20px;
      background-color: rgba(255,255,255,0.5);
      /*添加毛玻璃*/
      backdrop-filter: saturate(200%) blur(5px);
    }
    .login-title {
      font-size: 20px;
      color: #fff;
      font-family: chineseB;
    }
    .login-captcha {
      overflow: hidden;
      > img {
        width: 100%;
        cursor: pointer;
      }
    }
    .login-btn-submit {
      width: 100%;
      margin-top: 38px;
      background-image: linear-gradient(to right,#4a9dd4,#63dede);
    }
  }
</style>
