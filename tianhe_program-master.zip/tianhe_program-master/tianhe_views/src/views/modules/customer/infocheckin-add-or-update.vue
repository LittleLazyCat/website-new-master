<template>
  <el-dialog
    :title="!dataForm.id ? '新增' : '修改'"
    :close-on-click-modal="false"
    :visible.sync="visible"
    @open="handlerDialogOpen"
    width="30%">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="80px">
    <el-form-item label="床位编号" prop="bedId">
      <el-select v-model="dataForm.bedId" placeholder="请选择床位">
        <el-option
          v-for="item in bedList"
          :key="item.bedId"
          :label="'编号: '+item.bedId"
          :value="item.bedId">
        </el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="开始时间" prop="startTime">
      <!-- <el-input v-model="dataForm.startTime" placeholder="服务开始时间"></el-input> -->
      <el-date-picker
        v-model="dataForm.startTime"
        format="yyyy-MM-dd HH:mm:ss"
        value-format="yyyy-MM-dd HH:mm:ss"
        align="right"
        type="datetime"
        placeholder="选择服务开始时间">
      </el-date-picker>
    </el-form-item>
    <el-form-item label="结束时间" prop="endTime">
      <!-- <el-input v-model="dataForm.endTime" placeholder="服务结束时间"></el-input> -->
      <el-date-picker
        v-model="dataForm.endTime"
        format="yyyy-MM-dd HH:mm:ss"
        value-format="yyyy-MM-dd HH:mm:ss"
        align="right"
        type="datetime"
        placeholder="选择服务结束时间">
      </el-date-picker>
    </el-form-item>
    <el-form-item label="客户状态" prop="validState">
      <el-radio-group v-model="dataForm.validState=1" size="small">
        <el-radio-button label="1">在住</el-radio-button>
        <el-radio-button label="0" :disabled="!dataForm.id">退住</el-radio-button>
      </el-radio-group>
    </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
  export default {
    data () {
      return {
        visible: false,
        bedList:[],
        dataForm: {
          id: 0,
          customerId: '',
          customerIdentity:'',
          bedId: '',
          startTime: '',
          endTime: '',
          validState: '',
        },
        dataRule: {
          customerIdentity: [
            { required: true, message: '身份证号码不能为空', trigger: 'blur' }
          ],
          bedId: [
            { required: true, message: '床位id:参照床位表中的主键id不能为空', trigger: 'blur' }
          ],
          startTime: [
            { required: true, message: '服务开始时间不能为空', trigger: 'blur' }
          ],
          endTime: [
            { required: true, message: '服务结束时间不能为空', trigger: 'blur' }
          ],
          validState: [
            { required: true, message: '客户状态:', trigger: 'blur' }
          ]
        }
      }
    },
    methods: {
      handlerDialogOpen(){
        this.getBedList();
      },
      getBedList() {
        // 获取已在籍的顾客档案信息
        this.$http({
          url: this.$http.adornUrl('/cw/cwbed/getBedList'),
          method: 'get',
        }).then(({
          data
        }) => {
          if (data && data.code === 0) {
            this.bedList = data.data
          } else {
            this.bedList = []
          }
        })
      },
      init (id) {
        this.dataForm.id = id || 0
        this.visible = true
        this.$nextTick(() => {
          this.$refs['dataForm'].resetFields()
          if (this.dataForm.id) {
            this.$http({
              url: this.$http.adornUrl(`/customer/infocheckin/info/${this.dataForm.id}`),
              method: 'get',
              params: this.$http.adornParams()
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.dataForm.customerId = data.infoCheckIn.customerId
                this.dataForm.bedId = data.infoCheckIn.bedId
                this.dataForm.startTime = data.infoCheckIn.startTime
                this.dataForm.endTime = data.infoCheckIn.endTime
                this.dataForm.validState = data.infoCheckIn.validState
              }
            })
          }
        })
      },
      // 表单提交
      dataFormSubmit () {
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            this.$http({
              url: this.$http.adornUrl(`/customer/infocheckin/update`),
              method: 'post',
              data: this.$http.adornData({
                'id': this.dataForm.id,
                'customerId': this.dataForm.customerId,
                'bedId': this.dataForm.bedId,
                'startTime': this.dataForm.startTime,
                'endTime': this.dataForm.endTime,
                'validState': this.dataForm.validState,
              })
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.$message({
                  message: '操作成功',
                  type: 'success',
                  duration: 1500,
                  onClose: () => {
                    this.visible = false
                    this.$emit('refreshDataList')
                  }
                })
              } else {
                this.$message.error(data.msg)
              }
            })
          }
        })
      }
    }
  }
</script>
