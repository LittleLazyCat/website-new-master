<template>
  <el-dialog
    :title="!dataForm.id ? '新增' : '修改'"
    :close-on-click-modal="false"
    :visible.sync="visible" @open="handleDialogOpen">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="80px">
    <el-form-item label="入住记录" prop="ckiId" >
      <el-select v-model="dataForm.ckiId" placeholder="选择退住客户" :disabled="dataForm.id?true:false" @change="handleSelect">
        <el-option
          v-for="item in checkedCustList"
          :key="item.ckiId"
          :label="item.customerName"
          :value="item.customerId">
          <template sloe-scope="{item}" >
            <el-row>
              <el-col :span="5" style="padding: 3px 0px;"><el-image :src="item.headImgUrl" style="width: 25px;height: 25px;border-radius: 50%;"></el-image></el-col>
              <el-col :span="7">{{item.customerName}}</el-col>
              <el-col :span="7" style="font-size: 12px;color: silver;">({{item.identityNumber.substring(0,8)+'...'}})</el-col>
            </el-row>
          </template>
        </el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="退住类型" prop="checkOutType">
      <el-select v-model="dataForm.checkOutType" placeholder="退住类型">
        <el-option
          v-for="item in checkOutTypeList"
          :key="item.value"
          :label="item.label"
          :value="item.value">
        </el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="退住时间" prop="checkOutTime">
      <el-date-picker
        v-model="dataForm.checkOutTime"
        format="yyyy-MM-dd HH:mm:ss"
        value-format="yyyy-MM-dd HH:mm:ss"
        align="right"
        type="datetime"
        :default-value="new Date()"
        placeholder="选择服务开始时间">
      </el-date-picker>
    </el-form-item>
    <el-form-item label="退住原因" prop="checkOutReason">
      <el-input v-model="dataForm.checkOutReason" placeholder="退住原因"></el-input>
    </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
  export default {
    data () {
      return {
        checkOutTypeList:[
          {value:1,label:"合约到期"},
          {value:2,label:"主动退住"},
          {value:3,label:"其他"}
        ],
        checkedCustList:[],
        visible: false,
        dataForm: {
          id: 0,
          ckiId: '',
          checkOutType: 1,
          checkOutTime: "",
          checkOutReason: ''
        },
        dataRule: {
          ckiId: [
            { required: true, message: '入住id不能为空', trigger: 'blur' }
          ],
          checkOutType: [
            { required: true, message: '退住类型不能为空', trigger: 'blur' }
          ],
          checkOutTime: [
            { required: true, message: '退住时间不能为空', trigger: 'blur' }
          ],
          checkOutReason: [
            { required: true, message: '退住原因不能为空', trigger: 'blur' }
          ]
        }
      }
    },
    methods: {
      handleSelect(ckiId){
        this.checkedCustList.forEach((v,i)=>{
          if(v.ckiId===ckiId){
            this.dataForm.bedId=v.bedId;
          }
        })
      },
      init (id) {
        this.dataForm.id = id || 0
        this.visible = true
        this.$nextTick(() => {
          this.$refs['dataForm'].resetFields()
          if (this.dataForm.id) {
            this.$http({
              url: this.$http.adornUrl(`/customer/infocheckout/info/${this.dataForm.id}`),
              method: 'get',
              params: this.$http.adornParams()
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.dataForm.ckiId = data.infoCheckOut.ckiId
                this.dataForm.checkOutType = data.infoCheckOut.checkOutType
                this.dataForm.checkOutTime = data.infoCheckOut.checkOutTime
                this.dataForm.checkOutReason = data.infoCheckOut.checkOutReason
              }
            })
          }
        })
      },
      // 表单提交
      dataFormSubmit () {
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            if(this.dataForm.id){
              // update
              this.commitForUpdate();
            }else{
              // save
              this.commitForSave();
            }
          }
        })
      },
      commitForSave(){
        this.$http({
          url: this.$http.adornUrl(`/customer/infocheckout/save`),
          method: 'post',
          data: this.$http.adornData({
            'id': undefined,
            'ckiId': this.dataForm.ckiId,
            'checkOutType': this.dataForm.checkOutType,
            'checkOutTime': this.dataForm.checkOutTime,
            'checkOutReason': this.dataForm.checkOutReason,
            'bedId': this.dataForm.bedId,
          })
        }).then(({data}) => {
          if (data && data.code === 0) {
            this.$message({
              message: '操作成功',
              type: 'success',
              duration: 1500,
              onClose: () => {
                this.visible = false
                this.$emit('refreshDataList')
              }
            })
          } else {
            this.$message.error(data.msg)
          }
        })
      },
      commitForUpdate(){
        this.$http({
          url: this.$http.adornUrl(`/customer/infocheckout/update`),
          method: 'post',
          data: this.$http.adornData({
            'id': this.dataForm.id,
            'ckiId': this.dataForm.ckiId,
            'checkOutType': this.dataForm.checkOutType,
            'checkOutTime': this.dataForm.checkOutTime,
            'checkOutReason': this.dataForm.checkOutReason,
          })
        }).then(({data}) => {
          if (data && data.code === 0) {
            this.$message({
              message: '操作成功',
              type: 'success',
              duration: 1500,
              onClose: () => {
                this.visible = false
                this.$emit('refreshDataList')
              }
            })
          } else {
            this.$message.error(data.msg)
          }
        })
      },
      getCheckedCustList(){
        this.$http({
          url: this.$http.adornUrl(`/customer/infocheckout/getCheckedCustomer`),
          method: 'get',
        }).then(({data})=>{
          if (data && data.code === 0) {
            this.checkedCustList=data.data;
          }
        })
      },
      handleDialogOpen(){
        this.getCheckedCustList();
      }
    }
  }
</script>
