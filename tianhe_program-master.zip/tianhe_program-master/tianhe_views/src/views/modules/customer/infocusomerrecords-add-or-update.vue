<template>
  <el-dialog
    :title="!dataForm.id ? '新增' : '修改'"
    :close-on-click-modal="false"
    :visible.sync="visible">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="80px">
    <el-form-item label="客户姓名" prop="name">
      <el-input v-model="dataForm.name" placeholder="客户姓名"></el-input>
    </el-form-item>
    <el-form-item label="客户头像" prop="headImgUrl">
      <!-- <el-input v-model="dataForm.headImgUrl" placeholder="客户头像"></el-input> -->
      <single-upload v-model="dataForm.headImgUrl"></single-upload>
    </el-form-item>
    <el-form-item label="客户性别" prop="gender">
      <el-radio-group v-model="dataForm.gender" size="small">
        <el-radio-button label="1">男</el-radio-button>
        <el-radio-button label="0">女</el-radio-button>
      </el-radio-group>
    </el-form-item>
    <el-form-item label="身份证" prop="identityNumber">
      <el-input v-model="dataForm.identityNumber" placeholder="身份证"></el-input>
    </el-form-item>
    <el-form-item label="出生日期" prop="birthday">
      <!-- <el-input v-model="dataForm.birthday" placeholder="出生日期"></el-input> -->
      <el-date-picker
        v-model="dataForm.birthday"
        format="yyyy 年 MM 月 dd 日"
        value-format="yyyy-MM-dd HH:mm:ss"
        align="right"
        type="date"
        placeholder="选择日期"
        :picker-options="pickerOptions">
      </el-date-picker>
    </el-form-item>
    <el-form-item label="手机号码" prop="phone">
      <el-input v-model="dataForm.phone" placeholder="手机号码"></el-input>
    </el-form-item>
    <el-form-item label="血型" prop="bloodType">
      <el-select placeholder="请选择供应血型" v-model="dataForm.bloodType">
        <el-option
          v-for="item in bloodType"
          :key="item.value"
          :label="item.label"
          :value="item.value">
        </el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="家庭地址" prop="address">
      <el-row>
         <el-col :span="12"><select-address @fromComponentAddress="fromComponentAddress" :Address="address"></select-address></el-col>
         <el-col :span="12"><el-input v-model="addressFloor" placeholder="请输入详细楼牌(此处选填)" :disabled="address.length===0"></el-input></el-col>
      </el-row>
    </el-form-item>

    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
  import selectAddress from "../../../components/select-address/SelectAddress.vue"
  import singleUpload from "../../../components/upload/singleUpload.vue"
  export default {
    components:{
      selectAddress,
      singleUpload
    },
    data () {
      return {
        address:[],
        addressFloor:'',
        disable:true,
        visible: false,
        bloodType:[
          {value:"A",label:"A型"},
          {value:"B",label:"B型"},
          {value:"AB",label:"AB型"},
          {value:"O",label:"O型"}
        ],
        dataForm: {
          id: 0,
          name: '',
          headImgUrl: '',
          gender: '',
          identityNumber: '',
          birthday: '',
          phone: '',
          bloodType: '',
          address: '',
          createTime: '',
          updateTime: '',
          isDelete: ''
        },
        dataRule: {
          name: [
            { required: true, message: '客户姓名不能为空', trigger: 'blur' }
          ],
          headImgUrl: [
            { required: true, message: '客户头像不能为空', trigger: 'blur' }
          ],
          gender: [
            { required: true, message: '客户性别不能为空', trigger: 'blur' }
          ],
          identityNumber: [
            { required: true, message: '身份证号码不能为空', trigger: 'blur' }
          ],
          birthday: [
            { required: true, message: '出生日期不能为空', trigger: 'blur' }
          ],
          phone: [
            { required: true, message: '手机号码不能为空', trigger: 'blur' }
          ],
          bloodType: [
            { required: true, message: '血型不能为空', trigger: 'blur' }
          ],
          address: [
            { required: true, message: '家庭地址不能为空', trigger: 'blur' }
          ]
        },
        pickerOptions: {
          disabledDate(time) {
            return time.getTime() > Date.now();
          },
          shortcuts: [{
            text: '今天',
            onClick(picker) {
              picker.$emit('pick', new Date());
            }
          }, {
            text: '昨天',
            onClick(picker) {
              const date = new Date();
              date.setTime(date.getTime() - 3600 * 1000 * 24);
              picker.$emit('pick', date);
            }
          }, {
            text: '一周前的今天',
            onClick(picker) {
              const date = new Date();
              date.setTime(date.getTime() - 3600 * 1000 * 24 * 7);
              picker.$emit('pick', date);
            }
          }]
        },
      }
    },
    methods: {
      fromComponentAddress(childValue){
        this.address=childValue;
        console.log("d",this.address);
      },
      init (id) {
        this.dataForm.id = id || 0
        this.visible = true
        this.$nextTick(() => {
          this.$refs['dataForm'].resetFields()
          this.address=[]
          this.addressFloor=''
          if (this.dataForm.id) {
            this.$http({
              url: this.$http.adornUrl(`/customer/infocusomerrecords/info/${this.dataForm.id}`),
              method: 'get',
              params: this.$http.adornParams()
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.dataForm.name = data.infoCusomerRecords.name
                this.dataForm.headImgUrl = data.infoCusomerRecords.headImgUrl
                this.dataForm.gender = data.infoCusomerRecords.gender
                this.dataForm.identityNumber = data.infoCusomerRecords.identityNumber
                this.dataForm.birthday = data.infoCusomerRecords.birthday
                this.dataForm.phone = data.infoCusomerRecords.phone
                this.dataForm.bloodType = data.infoCusomerRecords.bloodType
                this.dataForm.address = data.infoCusomerRecords.address
                let arr=this.dataForm.address.split("/")
                this.addressFloor=arr.pop()
                this.address=arr
                this.dataForm.createTime = data.infoCusomerRecords.createTime
                this.dataForm.updateTime = data.infoCusomerRecords.updateTime
                this.dataForm.isDelete = data.infoCusomerRecords.isDelete
              }
            })
          }
        })
      },
      // 表单提交
      dataFormSubmit () {
        this.address.push(this.addressFloor);
        this.dataForm.address=this.address.join("/");
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            this.$http({
              url: this.$http.adornUrl(`/customer/infocusomerrecords/${!this.dataForm.id ? 'save' : 'update'}`),
              method: 'post',
              data: this.$http.adornData({
                'id': this.dataForm.id || undefined,
                'name': this.dataForm.name,
                'headImgUrl': this.dataForm.headImgUrl,
                'gender': this.dataForm.gender,
                'identityNumber': this.dataForm.identityNumber,
                'birthday': this.dataForm.birthday,
                'phone': this.dataForm.phone,
                'bloodType': this.dataForm.bloodType,
                'address': this.dataForm.address,
              })
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.$message({
                  message: '操作成功',
                  type: 'success',
                  duration: 1500,
                  onClose: () => {
                    this.visible = false
                    this.$emit('refreshDataList')
                  }
                })
              } else {
                this.$message.error(data.msg)
                if(data.error){
                  let message=(data.error.identityNumber||"")+' '+(data.error.phone||"")+' '+(data.error.bloodType||"")
                  this.$notify.error({
                    title: '错误',
                    duration:3000,
                    message
                  });
                }
              }
            })
          }
        })
      }
    }
  }
</script>
