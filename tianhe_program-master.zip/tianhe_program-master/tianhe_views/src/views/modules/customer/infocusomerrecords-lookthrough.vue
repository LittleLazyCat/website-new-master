<template>
  <el-dialog
    title="详细信息"
    :close-on-click-modal="false"
    :visible.sync="visible">
    <el-form :model="dataForm" ref="dataForm" label-width="80px" disabled>
      <el-form-item label="客户头像" prop="headImgUrl">
        <el-image style="width: 100px; height: 100px;border-radius: 19px;"
        :src="dataForm.headImgUrl">
          <div slot="error" class="errorImg">
            <i class="el-icon-picture-outline">加载失败...</i>
          </div>
        </el-image>
      </el-form-item>
      <el-form-item label="客户姓名" prop="name">
        <el-input v-model="dataForm.name" placeholder="客户姓名"></el-input>
      </el-form-item>
      <el-form-item label="客户性别" prop="gender">
        <el-radio-group v-model="dataForm.gender" size="small">
          <el-radio-button label="1">男</el-radio-button>
          <el-radio-button label="0">女</el-radio-button>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="身份证" prop="identityNumber">
        <el-input v-model="dataForm.identityNumber" placeholder="身份证"></el-input>
      </el-form-item>
      <el-form-item label="出生日期" prop="birthday">
        <el-input v-model="dataForm.birthday" placeholder="出生日期"></el-input>
      </el-form-item>
      <el-form-item label="手机号码" prop="phone">
        <el-input v-model="dataForm.phone" placeholder="手机号码"></el-input>
      </el-form-item>
      <el-form-item label="血型" prop="bloodType">
        <el-input v-model="dataForm.bloodType" placeholder="手机号码"></el-input>
      </el-form-item>
      <el-form-item label="家庭地址" prop="address">
        <el-input v-model="dataForm.address" placeholder="手机号码"></el-input>
      </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="wantModify" type="text">想要修改?</el-button>
      <el-button @click="visible = false" type="primary">关闭</el-button>
    </span>
    </el-dialog>
</template>

<script>
  export default{
    data(){
      return {
        visible:false,
        dataForm: {
          id: 0,
          name: '',
          headImgUrl: '',
          gender: '',
          identityNumber: '',
          birthday: '',
          phone: '',
          bloodType: '',
          address: '',
          createTime: '',
          updateTime: '',
          isDelete: ''
        },
      }
    },
    methods:{
      wantModify(){
        this.visible=false;
        this.$emit("wantModify",this.dataForm.id);
      },
      init (id) {
        this.dataForm.id = id || 0
        this.visible = true
        this.$nextTick(() => {
          if (this.dataForm.id) {
            this.$http({
              url: this.$http.adornUrl(`/customer/infocusomerrecords/info/${this.dataForm.id}`),
              method: 'get',
              params: this.$http.adornParams()
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.dataForm.name = data.infoCusomerRecords.name
                this.dataForm.headImgUrl = data.infoCusomerRecords.headImgUrl
                this.dataForm.gender = data.infoCusomerRecords.gender
                this.dataForm.identityNumber = data.infoCusomerRecords.identityNumber
                this.dataForm.birthday = data.infoCusomerRecords.birthday
                this.dataForm.phone = data.infoCusomerRecords.phone
                this.dataForm.bloodType = data.infoCusomerRecords.bloodType
                this.dataForm.address = data.infoCusomerRecords.address
                this.dataForm.createTime = data.infoCusomerRecords.createTime
                this.dataForm.updateTime = data.infoCusomerRecords.updateTime
                this.dataForm.isDelete = data.infoCusomerRecords.isDelete
              }
            })
          }
        })
      },
    }
  }
</script>

<style>
  .errorImg{
    background-color: silver;
    text-align: center;
    line-height: 100px;
    width: 100px;
    height: 100px;
  }
</style>
