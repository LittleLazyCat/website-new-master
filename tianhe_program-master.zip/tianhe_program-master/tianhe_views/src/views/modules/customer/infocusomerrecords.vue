<template>
  <div class="mod-config">
    <el-form :inline="true" :model="dataForm" @keyup.enter.native="getDataList()">
      <el-form-item>
        <el-input v-model="dataForm.key" placeholder="参数名" clearable></el-input>
      </el-form-item>
      <el-form-item>
        <el-button @click="getDataList()">查询</el-button>
        <el-button type="warning" @click="selectAll()">{{dataListSelections.length!==dataList.length?'全选':'取消全选'}}</el-button>
        <el-button v-if="isAuth('customer:infocusomerrecords:save')" type="primary" @click="addOrUpdateHandle()">新增</el-button>
        <el-button v-if="isAuth('customer:infocusomerrecords:delete')" type="danger" @click="deleteHandle()" :disabled="dataListSelections.length <= 0">批量删除</el-button>
      </el-form-item>
    </el-form>
    <!-- 表格式信息展示 -->
    <!-- <el-table
      :data="dataList"
      border
      v-loading="dataListLoading"
      @selection-change="selectionChangeHandle"
      style="width: 100%;">
      <el-table-column
        type="selection"
        header-align="center"
        align="center"
        width="50">
      </el-table-column>
      <el-table-column
        type="index"
        header-align="center"
        align="center"
        label="序号"
        width="80">
      </el-table-column>
      <el-table-column
        prop="name"
        header-align="center"
        align="center"
        label="客户姓名">
      </el-table-column>
      <el-table-column
        prop="gender"
        header-align="center"
        align="center"
        label="客户性别">
        <template slot-scope="scope">{{scope.row.gender===1?'男':'女'}}</template>
      </el-table-column>
      <el-table-column
        prop="identityNumber"
        header-align="center"
        align="center"
        label="身份证"
        width="210">
        <template slot-scope="scope">
          {{scope.row.flag? scope.row.identityNumber:(scope.row.identityNumber.substr(0,3)+'***************')}}
          <i @click="scope.row.flag=!scope.row.flag" :class="{'iconfont':true, 'iconbukejian':!scope.row.flag,'iconkejian':scope.row.flag}"></i>
        </template>
      </el-table-column>
      <el-table-column
        prop="birthday"
        header-align="center"
        align="center"
        label="出生日期">
        <template slot-scope="scope">{{scope.row.birthday.split(" ")[0]}}</template>
      </el-table-column>
      <el-table-column
        prop="phone"
        header-align="center"
        align="center"
        label="手机号码">
      </el-table-column>
      <el-table-column
        prop="bloodType"
        header-align="center"
        align="center"
        label="血型">
      </el-table-column>
      <el-table-column
        prop="address"
        header-align="center"
        align="center"
        label="家庭地址"
        width="160">
        <template slot-scope="scope">
          <el-popover trigger="hover" placement="top" :open-delay="400">
            <p>详细住址: <br/>{{ scope.row.address}}</p>
            <div slot="reference" class="name-wrapper">
              <el-tag>{{ scope.row.address.substr(0,10)+"..."}}</el-tag>
            </div>
          </el-popover>
        </template>
      </el-table-column>
      <el-table-column
        prop="createTime"
        header-align="center"
        align="center"
        label="创建时间"
        width="160">
      </el-table-column>
      <el-table-column
        prop="updateTime"
        header-align="center"
        align="center"
        label="更新时间"
        width="160">
      </el-table-column>
      <el-table-column
        fixed="right"
        header-align="center"
        align="center"
        width="150"
        label="操作">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="addOrUpdateHandle(scope.row.id)">修改</el-button>
          <el-button type="text" size="small" @click="deleteHandle(scope.row.id)">删除</el-button>
        </template>
      </el-table-column>
    </el-table> -->
    <!-- 卡片式信息展示 -->
    <div class="mycontainer">
      <el-row v-for="item in Math.ceil(dataList.length/5)" :key="item" class="row">
        <div class="card" v-for="(o, index) in 5" :key="o+5*(item-1)">
          <el-card v-if="o+5*(item-1)-1<dataList.length" style="height: 310px;width: 250px; text-align:center; padding:10px;" shadow="hover">
            <div style="text-align: left;margin-bottom: 10px;">
            <el-checkbox v-model="dataListSelections" :label="dataList[o+5*(item-1)-1]">序号:{{o+5*(item-1)}}</el-checkbox>
            </div>
            <el-avatar  :src="dataList[o+5*(item-1)-1].headImgUrl" :size="70"></el-avatar>
            <div class="mybody">
              <table border="0">
                <tr>
                  <td>姓名：</td>
                  <td>{{dataList[o+5*(item-1)-1].name}}</td>
                </tr>
                <tr>
                  <td>性别：</td>
                  <td>{{dataList[o+5*(item-1)-1].gender?'男':'女'}}</td>
                </tr>
                <tr>
                  <td>手机：</td>
                  <td>{{dataList[o+5*(item-1)-1].phone}}</td>
                </tr>
                <tr>
                  <td>生日：</td>
                  <td>{{dataList[o+5*(item-1)-1].birthday.split(" ")[0]}}</td>
                </tr>
              </table>
            </div>
            <div  class="myfoot">
              <el-button type="text" size="small" @click="infomationHandle(dataList[o+5*(item-1)-1].id)" style="color: #667AFA;">详细</el-button>
              <el-button type="text" size="small" @click="addOrUpdateHandle(dataList[o+5*(item-1)-1].id)">修改</el-button>
              <el-button type="text" size="small" @click="deleteHandle(dataList[o+5*(item-1)-1].id)" style="color: red;">删除</el-button>
            </div>
          </el-card>
        </div>
      </el-row>
    </div>
    <!-- 分页导航 -->
    <el-pagination
      @size-change="sizeChangeHandle"
      @current-change="currentChangeHandle"
      :current-page="pageIndex"
      :page-sizes="[10, 20, 50, 100]"
      :page-size="pageSize"
      :total="totalPage"
      layout="total, sizes, prev, pager, next, jumper">
    </el-pagination>

    <!-- 弹窗, 新增 / 修改 -->
    <add-or-update v-if="addOrUpdateVisible" ref="addOrUpdate" @refreshDataList="getDataList"></add-or-update>
    <!-- 查看详细信息 -->
    <infomation-dialog v-if="infomationVisable" ref="infomationDialog" @wantModify="addOrUpdateHandle($event)"></infomation-dialog>
  </div>
</template>

<script>
  import AddOrUpdate from './infocusomerrecords-add-or-update'
  import InfomationDialog from './infocusomerrecords-lookthrough'
  export default {
    data () {
      return {
        dataForm: {
          key: ''
        },
        dataList: [],
        pageIndex: 1,
        pageSize: 10,
        totalPage: 0,
        dataListLoading: false,
        dataListSelections: [],
        addOrUpdateVisible: false,
        infomationVisable: false
      }
    },
    components: {
      AddOrUpdate,
      InfomationDialog
    },
    activated () {
      this.getDataList()
    },
    methods: {
      // 获取数据列表
      getDataList () {
        this.dataListLoading = true
        this.$http({
          url: this.$http.adornUrl('/customer/infocusomerrecords/list'),
          method: 'get',
          params: this.$http.adornParams({
            'page': this.pageIndex,
            'limit': this.pageSize,
            'key': this.dataForm.key
          })
        }).then(({data}) => {
          if (data && data.code === 0) {
            this.dataList = data.page.list
            this.dataList=this.dataList.map((v)=>v={...v,flag:false});
            this.totalPage = data.page.totalCount
          } else {
            this.dataList = []
            this.totalPage = 0
          }
          this.dataListLoading = false
        })
      },
      // 每页数
      sizeChangeHandle (val) {
        this.pageSize = val
        this.pageIndex = 1
        this.getDataList()
      },
      // 当前页
      currentChangeHandle (val) {
        this.pageIndex = val
        this.getDataList()
      },
      selectAll(){
        this.selectionChangeHandle(this.dataList.length===this.dataListSelections.length?[]:this.dataList)
      },
      // 多选
      selectionChangeHandle (val) {
        this.dataListSelections = val
        console.log(val);
      },
      // 新增 / 修改
      addOrUpdateHandle(id) {
        this.addOrUpdateVisible = true
        this.$nextTick(() => {
          this.$refs.addOrUpdate.init(id)
        })
      },
      // 详细信息
      infomationHandle (id) {
        this.infomationVisable = true
        this.$nextTick(() => {
          this.$refs.infomationDialog.init(id)
        })
      },
      // 删除
      deleteHandle (id) {
        var ids = id ? [id] : this.dataListSelections.map(item => {
          return item.id
        })
        this.$confirm(`确定对[id=${ids.join(',')}]进行[${id ? '删除' : '批量删除'}]操作?`, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.$http({
            url: this.$http.adornUrl('/customer/infocusomerrecords/delete'),
            method: 'post',
            data: this.$http.adornData(ids, false)
          }).then(({data}) => {
            if (data && data.code === 0) {
              this.$message({
                message: '操作成功',
                type: 'success',
                duration: 1500,
                onClose: () => {
                  this.getDataList()
                }
              })
            } else {
              this.$message.error(data.msg)
            }
          })
        })
      }
    },
    filters:{
      changeSecret(e){
        return "************"
      }
    }
  }
</script>
<style>

  /* 设置滚动条的样式 */
  ::-webkit-scrollbar {
    width:10px;
  }
  /* 滚动槽 */
  ::-webkit-scrollbar-track {
    -webkit-box-shadow:inset006pxrgba(35, 71, 75, 0.3);
    border-radius:10px;
  }
  /* 滚动条滑块 */
  ::-webkit-scrollbar-thumb {
    border-radius:10px;
    background:rgba(175, 82, 119, 0.5);
    -webkit-box-shadow:inset006pxrgba(175, 82, 119, 0.5);
  }

  .mycontainer{
    height: 680px;
    overflow-y: auto;
  }
 .row{
   margin-top: 10px;
   display: flex;
   /* justify-content: center; */
   position: relative;
 }
 .card{

  display: block;
  margin: 10px 25px;
 }
 .mybody{
   margin-top: 5px;
 }
 .myfoot{
   margin-top: 10px;
   float: right;
 }
 table{
   margin: 10px auto;
 }
 table tr{
   height: 25px;
 }
</style>
