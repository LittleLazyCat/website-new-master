<template>
  <el-dialog :title="!dataForm.id ? '新增' : '修改'" :close-on-click-modal="false" :visible.sync="visible"
    @open="handleDialogOpen" width="600px">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()"
      label-width="100px" :status-icon="true" >
      <el-form-item label="选择客户" prop="customerId">
        <el-select v-model="dataForm.customerId" placeholder="请选择客户" filterable clearable>
          <el-option v-for="item in customerList" :key="item.id" :label="item.name" :value="item.id">
            <template sloe-scope="{item}">{{item.name}}<span
                style="color: silver;">({{item.identityNumber}})</span></template>
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="家属姓名" prop="name">
        <el-input v-model="dataForm.name" placeholder="请输入家属姓名" ></el-input>
      </el-form-item>
      <el-form-item label="家属电话" prop="phone">
        <el-input v-model="dataForm.phone" placeholder="请输入家属的联系电话"></el-input>
      </el-form-item>
      <el-form-item label="关系" prop="relation">
        <el-select v-model="dataForm.relation" placeholder="请选择客户">
          <el-option v-for="item in relationArr" :key="item.value" :label="item.text" :value="item.value">
            <template sloe-scope="{item}">{{item.text.split("与客户是")[1]}}</template>
          </el-option>
        </el-select>
      </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
  export default {
    props: {
      relationArr: Array
    },
    data() {
      return {
        visible: false,
        dataForm: {
          id: 0,
          customerId: '',
          name: '',
          relation: '',
          phone: '',
          createTime: '',
          updateTime: '',
          isDelete: ''
        },
        dataRule: {
          customerId: [{
            required: true,
            message: '一定要选择客户啊！',
            trigger: 'blur'
          }],
          name: [{
            required: true,
            message: '家属姓名不能为空',
            trigger: 'blur'
          }],
          relation: [{
            required: true,
            message: '与客户的关系不能为空',
            trigger: 'blur'
          }],
          phone: [{
            required: true,
            message: '家属联系电话不能为空',
            trigger: 'blur'
          }, {
            pattern: /^((13[0-9])|(14[5-8])|(15([0-3]|[5-9]))|(16[6])|(17[0|4|6|7|8])|(18[0-9])|(19[8-9]))\d{8}$/,
            message: '手机号格式有误',
            trigger: 'change'
          }],
      },
      customerList: [],
    }
  },
  methods: {
    handleDialogOpen() {
      this.getCustomerList();
    },
    getCustomerList() {
      this.$http({
        url: this.$http.adornUrl(`/customer/infocusomerrecords/customerlist`),
        method: 'get'
      }).then(({
        data
      }) => {
        if (data && data.code === 0) {
          this.customerList = data.data;
        }
      })
    },
    init(id) {
      this.dataForm.id = id || 0
      this.visible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].resetFields()
        if (this.dataForm.id) {
          this.$http({
            url: this.$http.adornUrl(`/customer/infofamilyrecords/info/${this.dataForm.id}`),
            method: 'get',
            params: this.$http.adornParams()
          }).then(({
            data
          }) => {
            if (data && data.code === 0) {
              this.dataForm.customerId = data.infoFamilyRecords.customerId
              this.dataForm.name = data.infoFamilyRecords.name
              this.dataForm.relation = data.infoFamilyRecords.relation
              this.dataForm.phone = data.infoFamilyRecords.phone
            }
          })
        }
      })
    },
    // 表单提交
    dataFormSubmit() {
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          this.$http({
            url: this.$http.adornUrl(`/customer/infofamilyrecords/${!this.dataForm.id ? 'save' : 'update'}`),
            method: 'post',
            data: this.$http.adornData({
              'id': this.dataForm.id || undefined,
              'customerId': this.dataForm.customerId,
              'name': this.dataForm.name,
              'relation': this.dataForm.relation,
              'phone': this.dataForm.phone,
            })
          }).then(({
            data
          }) => {
            if (data && data.code === 0) {
              this.$message({
                message: '操作成功',
                type: 'success',
                duration: 1500,
                onClose: () => {
                  this.visible = false
                  this.$emit('refreshDataList')
                }
              })
            } else {
              this.$message.error(data.msg)
            }
          })
        }
      })
    }
  }
  }
</script>
