<template>
  <el-dialog :title="!dataForm.id ? '新增' : '修改'" :close-on-click-modal="false" :visible.sync="visible" width="600px">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()"
      label-width="120px">
      <el-form-item label="外来人员姓名" prop="name">
        <el-input v-model="dataForm.name" placeholder="在此输入外来人员姓名" prefix-icon="el-icon-edit" maxlength="10" show-word-limit></el-input>
      </el-form-item>
      <el-form-item label="外来人员电话" prop="phone">
        <el-input v-model="dataForm.phone" placeholder="在此输入外来人员电话" prefix-icon="el-icon-phone" maxlength="11" show-word-limit></el-input>
      </el-form-item>
      <el-form-item label="到访时间" prop="accessTime">
        <el-date-picker
          v-model="dataForm.accessTime"
          format="yyyy-MM-dd HH:mm:ss"
          value-format="yyyy-MM-dd HH:mm:ss"
          align="right"
          type="datetime"
          :default-value="new Date()"
          placeholder="选择时间"
          :picker-options="expireTimeOption">
        </el-date-picker>
      </el-form-item>
      <el-form-item label="离开时间" prop="leaveTime">
        <el-date-picker
          v-model="dataForm.leaveTime"
          format="yyyy-MM-dd HH:mm:ss"
          value-format="yyyy-MM-dd HH:mm:ss"
          align="right"
          type="datetime"
          :default-value="new Date()"
          placeholder="选择时间"
          :picker-options="expireTimeOption">
        </el-date-picker>
      </el-form-item>
      <el-form-item label="到访原因" prop="accessReason" style="margin-bottom: 0px;">
        <el-input
          type="textarea"
          placeholder="请输入到访原因"
          v-model="dataForm.accessReason"
          maxlength="60">
        </el-input>
      </el-form-item>
    </el-form>
    <div class="recommendBox">
      <a @click="dataForm.accessReason=item.accessReason" v-for="item in recommendReasonList" :key="item.accessReason" v-text="item.accessReason+'?'" class="recommendItem"></a>
    </div>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
  export default {
    data() {
      return {
        expireTimeOption: {
          disabledDate(date) {
            //disabledDate 文档上：设置禁用状态，参数为当前日期，要求返回 Boolean
            return date.getTime() < Date.now() - 24 * 60 * 60 * 1000;
          }
        },
        visible: false,
        dataForm: {
          id: 0,
          name: '',
          phone: '',
          accessTime: '',
          leaveTime: '',
          accessReason: '',
        },
        dataRule: {
          name: [{
            required: true,
            message: '外来人员姓名不能为空',
            trigger: 'blur'
          }],
          phone: [{
            required: true,
            message: '外来人员电话不能为空',
            trigger: 'blur'
          }],
          accessTime: [{
            required: true,
            message: '到访时间不能为空',
            trigger: 'blur'
          }],
          accessReason: [{
            required: true,
            message: '到访原因不能为空',
            trigger: 'blur'
          }]
        },
        recommendReasonList:[]
      }
    },
    methods: {
      getRecommendReason(){
        this.$http({
          url:this.$http.adornUrl(`/customer/infofamilyrecords/getRecommendReason`),
          method:'get'
        }).then(({data})=>{
          if (data && data.code === 0) {
            this.recommendReasonList=data.data;
          }
        })
      },
      init(id) {
        this.dataForm.id = id || 0
        this.visible = true
        this.$nextTick(() => {
          this.$refs['dataForm'].resetFields()
          this.getRecommendReason()
          if (this.dataForm.id) {
            this.$http({
              url: this.$http.adornUrl(`/customer/infootherrecords/info/${this.dataForm.id}`),
              method: 'get',
              params: this.$http.adornParams()
            }).then(({
              data
            }) => {
              if (data && data.code === 0) {
                this.dataForm.name = data.infoOtherRecords.name
                this.dataForm.phone = data.infoOtherRecords.phone
                this.dataForm.accessTime = data.infoOtherRecords.accessTime
                this.dataForm.leaveTime = data.infoOtherRecords.leaveTime
                this.dataForm.accessReason = data.infoOtherRecords.accessReason
              }
            })
          }
        })
      },
      // 表单提交
      dataFormSubmit() {
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            this.$http({
              url: this.$http.adornUrl(`/customer/infootherrecords/${!this.dataForm.id ? 'save' : 'update'}`),
              method: 'post',
              data: this.$http.adornData({
                'id': this.dataForm.id || undefined,
                'name': this.dataForm.name,
                'phone': this.dataForm.phone,
                'accessTime': this.dataForm.accessTime,
                'leaveTime': this.dataForm.leaveTime,
                'accessReason': this.dataForm.accessReason,
              })
            }).then(({
              data
            }) => {
              if (data && data.code === 0) {
                this.$message({
                  message: '操作成功',
                  type: 'success',
                  duration: 1500,
                  onClose: () => {
                    this.visible = false
                    this.$emit('refreshDataList')
                  }
                })
              } else {
                this.$message.error(data.msg)
              }
            })
          }
        })
      }
    }
  }
</script>
<style>
  .recommendBox{
    text-align: center;
    margin-top: 10px;
  }
  .recommendBox .recommendItem{
    margin-left: 5px;
    color: #7da2aa;
  }
  .recommendBox .recommendItem:hover{
    cursor: pointer;
    text-decoration: none;
    color: lightcoral;
  }
</style>
