<template>
  <el-dialog :title="!dataForm.id ? '新增' : '修改'" :close-on-click-modal="false" :visible.sync="visible" @open="handleOpen">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()"
      label-width="120px">
      <el-form-item label="在住客户" prop="customerId" v-if="dataForm.id===0">
        <el-select v-model="dataForm.customerId" placeholder="请选择客户" :disabled="dataForm.id!==0">
          <el-option v-for="item in canOutList" :key="item.customerId" :label="item.customerName" :value="item.customerId">
            <template sloe-scope="{item}">{{item.customerName}}-{{item.identityNumber}}</template>
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="在住客户" prop="customerId" v-else="dataForm.id===0">
        <el-input v-model="previewName" :disabled="dataForm.id!==0">
        </el-input>
      </el-form-item>
      <el-form-item label="陪同人姓名" prop="withWhoName">
        <el-input v-model="dataForm.withWhoName" placeholder="陪同人姓名"></el-input>
      </el-form-item>
      <el-form-item label="陪同人电话" prop="withWhoPhone">
        <el-input v-model="dataForm.withWhoPhone" placeholder="陪同人电话"></el-input>
      </el-form-item>
      <el-form-item label="与客户关系" prop="relation">
        <el-select v-model="dataForm.relation" placeholder="请选择客户">
          <el-option v-for="item in relationArr" :key="item.value" :label="item.text" :value="item.value">
            <template sloe-scope="{item}">{{item.text}}</template>
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="外出原因" prop="outReason">
        <el-input v-model="dataForm.outReason" placeholder="外出原因"></el-input>
      </el-form-item>
      <el-form-item label="外出时间" prop="outTime">
        <el-date-picker
          v-model="dataForm.outTime"
          format="yyyy-MM-dd HH:mm:ss"
          value-format="yyyy-MM-dd HH:mm:ss"
          align="right"
          type="datetime"
          :default-value="new Date()"
          placeholder="选择时间"
          :picker-options="expireTimeOption">
        </el-date-picker>
      </el-form-item>
      <el-form-item label="预计返回时间" prop="exReturnTime">
        <el-date-picker
          v-model="dataForm.exReturnTime"
          format="yyyy-MM-dd HH:mm:ss"
          value-format="yyyy-MM-dd HH:mm:ss"
          align="right"
          type="datetime"
          :default-value="new Date()"
          placeholder="选择时间"
          :picker-options="expireTimeOption">
        </el-date-picker>
      </el-form-item>
      <el-form-item label="实际返回时间" prop="realReturnTime">
        <el-date-picker
          v-model="dataForm.realReturnTime"
          format="yyyy-MM-dd HH:mm:ss"
          value-format="yyyy-MM-dd HH:mm:ss"
          align="right"
          type="datetime"
          :default-value="new Date()"
          placeholder="选择时间"
          :picker-options="expireTimeOption">
        </el-date-picker>
      </el-form-item>
      <el-form-item label="外出状态" prop="state">
        <el-radio-group v-model="dataForm.state" size="small" disabled>
          <el-radio-button label="0">未返回</el-radio-button>
          <el-radio-button label="1">已返回</el-radio-button>
        </el-radio-group>
      </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
  export default {
    props:{
      relationArr:Array
    },
    watch:{
      "dataForm.realReturnTime":{
        handler(newVal,oldVal){
            this.dataForm.state=!newVal?0:1;
        },
        deep:true
      }
    },
    data() {
      return {
        expireTimeOption: {
          disabledDate(date) {
            //disabledDate 文档上：设置禁用状态，参数为当前日期，要求返回 Boolean
            return date.getTime() < Date.now() - 24 * 60 * 60 * 1000;
          }
        },
        visible: false,
        canOutList:[],
        previewName:'',
        dataForm: {
          id: 0,
          customerId: '',
          withWhoName: '',
          withWhoPhone: '',
          relation: '',
          outReason: '',
          outTime: '',
          exReturnTime: '',
          realReturnTime: '',
          state: '',
        },
        dataRule: {
          customerId: [{
            required: true,
            message: '客户id 参照客户档案中的主键id不能为空',
            trigger: 'blur'
          }],
          withWhoName: [{
            required: true,
            message: '陪同人姓名不能为空',
            trigger: 'blur'
          }],
          withWhoPhone: [{
            required: true,
            message: '陪同人电话不能为空',
            trigger: 'blur'
          }],
          relation: [{
            required: true,
            message: '与客户关系不能为空',
            trigger: 'blur'
          }],
          outReason: [{
            required: true,
            message: '外出原因不能为空',
            trigger: 'blur'
          }],
          outTime: [{
            required: true,
            message: '外出时间不能为空',
            trigger: 'blur'
          }],
          exReturnTime: [{
            required: true,
            message: '预计返回时间不能为空',
            trigger: 'blur'
          }],
          state: [{
            required: true,
            message: '外出状态不能为空',
            trigger: 'blur'
          }]
        }
      }
    },
    methods: {
      getCanOutList(){
        this.$http({
          url:this.$http.adornUrl(`/customer/infooutrecords/getCanGoOutList`),
          method:'get'
        }).then(({data})=>{
          if(data&&data.code===0){
            this.canOutList=data.data.list;
          }
        })
      },
      handleOpen(){
        this.canOutList=[];
        this.getCanOutList();
      },
      init(id) {
        this.dataForm.id = id || 0
        this.visible = true
        this.$nextTick(() => {
          this.$refs['dataForm'].resetFields()
          if (this.dataForm.id) {
            this.$http({
              url: this.$http.adornUrl(`/customer/infooutrecords/info/${this.dataForm.id}`),
              method: 'get',
              params: this.$http.adornParams()
            }).then(({
              data
            }) => {
              if (data && data.code === 0) {
                this.previewName= data.infoOutRecords.customerName
                this.dataForm.customerId = data.infoOutRecords.customerId
                this.dataForm.withWhoName = data.infoOutRecords.withWhoName
                this.dataForm.withWhoPhone = data.infoOutRecords.withWhoPhone
                this.dataForm.relation = data.infoOutRecords.relation
                this.dataForm.outReason = data.infoOutRecords.outReason
                this.dataForm.outTime = data.infoOutRecords.outTime
                this.dataForm.exReturnTime = data.infoOutRecords.exReturnTime
                this.dataForm.realReturnTime = data.infoOutRecords.realReturnTime
                this.dataForm.state = data.infoOutRecords.state
              }
            })
          }
        })
      },
      // 表单提交
      dataFormSubmit() {
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            this.$http({
              url: this.$http.adornUrl(`/customer/infooutrecords/${!this.dataForm.id ? 'save' : 'update'}`),
              method: 'post',
              data: this.$http.adornData({
                'id': this.dataForm.id || undefined,
                'customerId': this.dataForm.customerId,
                'withWhoName': this.dataForm.withWhoName,
                'withWhoPhone': this.dataForm.withWhoPhone,
                'relation': this.dataForm.relation,
                'outReason': this.dataForm.outReason,
                'outTime': this.dataForm.outTime,
                'exReturnTime': this.dataForm.exReturnTime,
                'realReturnTime': this.dataForm.realReturnTime,
                'state': this.dataForm.state,
              })
            }).then(({
              data
            }) => {
              if (data && data.code === 0) {
                this.$message({
                  message: '操作成功',
                  type: 'success',
                  duration: 1500,
                  onClose: () => {
                    this.visible = false
                    this.$emit('refreshDataList')
                  }
                })
              } else {
                this.$message.error(data.msg)
              }
            })
          }
        })
      }
    }
  }
</script>
