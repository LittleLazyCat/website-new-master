<template>
  <el-dialog
    :title="!dataForm.id ? '新增' : '修改'"
    :close-on-click-modal="false"
    :visible.sync="visible"
    @open="open">
    <el-form :model="dataForm" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="80px">
    <el-form-item label="床位检查" prop="bedCheck">
      <el-input v-model="dataForm.bedCheck" placeholder="检查为1,默认为0"></el-input>
    </el-form-item>
    <el-form-item label="床位清洁" prop="bedClean">
      <el-input v-model="dataForm.bedClean" placeholder="清洁为1,默认为0"></el-input>
    </el-form-item>
    <el-form-item label="房间号" prop="roomId">
      <el-select v-model="dataForm.roomId" placeholder="请选择房间号">
        <el-option
          v-for="item in roomList"
          :key="item.roomId"
          :label="item.roomId"
          :value="item.roomId">
          <template sloe-scope="{item}">{{item.roomId+'号房'}}<span style="color: silver;font-size: smaller;">({{item.roomFloor+'楼'}})</span></template>
        </el-option>
      </el-select>
    </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
  export default {
    data () {
      return {
        visible: false,
        roomList: [],
        dataForm: {
          bedId: 0,
          customerId: '',
          bedCheck: '',
          bedClean: '',
          roomId: '',
        }
      }
    },
    methods: {
      open(){
        this.getRoom()
      },
      getRoom(){
        this.$http({
          url: this.$http.adornUrl('/cw/cwroom/getRoomList'),
          method: 'get',
        }).then(({
          data
        }) => {
          if (data && data.code === 0) {
            this.roomList = data.data
          } else {
            this.roomList = []
          }
        })
      },
      init (id) {
        this.dataForm.bedId = id || 0
        this.visible = true
        this.$nextTick(() => {
          this.$refs['dataForm'].resetFields()
          if (this.dataForm.bedId) {
            this.$http({
              url: this.$http.adornUrl(`/cw/cwbed/info/${this.dataForm.bedId}`),
              method: 'get',
              params: this.$http.adornParams()
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.dataForm.customerId = data.cwBed.customerId
                this.dataForm.bedCheck = data.cwBed.bedCheck
                this.dataForm.bedClean = data.cwBed.bedClean
                this.dataForm.roomId = data.cwBed.roomId
              }
            })
          }
        })
      },
      // 表单提交
      dataFormSubmit () {
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            this.$http({
              url: this.$http.adornUrl(`/cw/cwbed/${!this.dataForm.bedId ? 'save' : 'update'}`),
              method: 'post',
              data: this.$http.adornData({
                'bedId': this.dataForm.bedId || undefined,
                'customerId': this.dataForm.customerId,
                'bedCheck': this.dataForm.bedCheck,
                'bedClean': this.dataForm.bedClean,
                'roomId': this.dataForm.roomId
              })
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.$message({
                  message: '操作成功',
                  type: 'success',
                  duration: 1500,
                  onClose: () => {
                    this.visible = false
                    this.$emit('refreshDataList')
                  }
                })
              } else {
                this.$message.error(data.msg)
              }
            })
          }
        })
      }
    }
  }
</script>
