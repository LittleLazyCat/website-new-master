<template>
  <div class="mod-config">
    <el-form :inline="true" :model="dataForm" @keyup.enter.native="getDataList()">
      <el-form-item>
        <el-input v-model="dataForm.key" placeholder="请输入床位编号" clearable></el-input>
      </el-form-item>
      <el-form-item>
        <el-button @click="getDataList()">查询</el-button>
        <el-button type="warning" @click="selectAll()">{{dataListSelections.length!==dataList.length?'全选':'取消全选'}}</el-button>
        <el-button v-if="isAuth('cw:cwbed:save')" type="primary" @click="addOrUpdateHandle()">新增</el-button>
        <el-button v-if="isAuth('cw:cwbed:delete')" type="danger" @click="deleteHandle()" :disabled="dataListSelections.length <= 0">批量删除</el-button>
      </el-form-item>
    </el-form>
    <!-- 表格式展示 -->
<!--    <el-table
      :data="dataList"
      border
      v-loading="dataListLoading"
      @selection-change="selectionChangeHandle"
      style="width: 100%;">
      <el-table-column
        type="selection"
        header-align="center"
        align="center"
        width="50">
      </el-table-column>
      <el-table-column
        prop="bedId"
        header-align="center"
        align="center"
        label="床位编号">
      </el-table-column>
      <el-table-column
        prop="customerName"
        header-align="center"
        align="center"
        label="床位用户">
      </el-table-column>
      <el-table-column
        prop="bedCheck"
        header-align="center"
        align="center"
        label="床位检查">
      </el-table-column>
      <el-table-column
        prop="bedClean"
        header-align="center"
        align="center"
        label="床位清洁">
      </el-table-column>
      <el-table-column
        prop="roomId"
        header-align="center"
        align="center"
        label="房间号">
      </el-table-column>
      <el-table-column
        prop="createTime"
        header-align="center"
        align="center"
        label="创建时间">
      </el-table-column>
      <el-table-column
        prop="updateTime"
        header-align="center"
        align="center"
        label="更新时间">
      </el-table-column>
      <el-table-column
        fixed="right"
        header-align="center"
        align="center"
        width="150"
        label="操作">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="addOrUpdateHandle(scope.row.bedId)">修改</el-button>
          <el-button type="text" size="small" @click="deleteHandle(scope.row.bedId)">删除</el-button>
        </template>
      </el-table-column>
    </el-table> -->
    <!-- 颜色提示栏 -->
    <div class="colorBar">
       <i v-for="e in colorList" :key="e.color" style="margin-right: 10px;" class="iconfont iconcheckbox-full" :style="{color:e.color}">
         <span style="font-size: 10px;margin-left: 2px;">{{e.text}}</span>
       </i>
    </div>
    <!-- 卡片式展示 -->
    <div class="mycontainer">
      <el-row v-for="item in Math.ceil(dataList.length/5)" :key="item" class="row">
        <div class="card" v-for="(o, index) in 5" :key="o+5*(item-1)">
          <el-card v-if="o+5*(item-1)-1<dataList.length" style="height: 280px;width: 280px; text-align:center; padding:10px;" shadow="hover">
            <div style="text-align: left;margin-bottom: 10px;">
            <el-checkbox v-model="dataListSelections" :label="dataList[o+5*(item-1)-1]">序号:{{o+5*(item-1)}} - {{dataList[o+5*(item-1)-1].bedId}}床/{{dataList[o+5*(item-1)-1].roomId}}房/{{dataList[o+5*(item-1)-1].roomFloor}}楼</el-checkbox>
            </div>
            <!-- 床位图标展示 -->
            <!-- 空床 -->
            <i class="iconfont iconbed-none" style="font-size: 64px;"
              :style="{color:getColor(0,dataList[o+5*(item-1)-1].bedCheck,dataList[o+5*(item-1)-1].bedClean)}"
              v-if="!dataList[o+5*(item-1)-1].customerId"></i>
            <!-- 有人 -->
            <i class="iconfont iconbed-one" style="font-size: 64px;"
              :style="{color:getColor(1,dataList[o+5*(item-1)-1].bedCheck,dataList[o+5*(item-1)-1].bedClean)}"
              v-if="dataList[o+5*(item-1)-1].customerId"></i>
            <div class="mybody">
              <table border="0">
                <tr>
                  <td style="text-align: right;">持有人：</td>
                  <td>{{dataList[o+5*(item-1)-1].customerName|showText}}</td>
                </tr>
                <tr>
                  <td style="text-align: right;">手机号：</td>
                  <td>{{dataList[o+5*(item-1)-1].customerPhone|showText}}</td>
                </tr>
                <tr>
                  <td style="text-align: right;">更新时间：</td>
                  <td>{{dataList[o+5*(item-1)-1].updateTime|showText}}</td>
                </tr>
              </table>
            </div>
            <div  class="myfoot">
              <!-- <el-button type="text" size="small" @click="infomationHandle(dataList[o+5*(item-1)-1].id)" style="color: #667AFA;">详细</el-button> -->
              <el-button type="text" size="small" @click="addOrUpdateHandle(dataList[o+5*(item-1)-1].bedId)">修改</el-button>
              <el-button type="text" size="small" @click="deleteHandle(dataList[o+5*(item-1)-1].bedId)" style="color: red;">删除</el-button>
            </div>
          </el-card>
        </div>
      </el-row>
    </div>
    <el-pagination
      @size-change="sizeChangeHandle"
      @current-change="currentChangeHandle"
      :current-page="pageIndex"
      :page-sizes="[10, 20, 50, 100]"
      :page-size="pageSize"
      :total="totalPage"
      layout="total, sizes, prev, pager, next, jumper">
    </el-pagination>
    <!-- 弹窗, 新增 / 修改 -->
    <add-or-update v-if="addOrUpdateVisible" ref="addOrUpdate" @refreshDataList="getDataList"></add-or-update>
  </div>
</template>

<script>
  import AddOrUpdate from './cwbed-add-or-update'
  export default {
    data () {
      return {
        dataForm: {
          key: ''
        },
        dataList: [],
        pageIndex: 1,
        pageSize: 10,
        totalPage: 0,
        dataListLoading: false,
        dataListSelections: [],
        addOrUpdateVisible: false,
        colorList:[
          {text:"有人",color:'#407fc2'},
          {text:"无人",color:'#3adc32'},
          {text:"正检修",color:'#c2425e'},
          {text:"正清理",color:'#c28871'},
          {text:"正清修",color:'#ff0000'}
        ]
      }
    },
    components: {
      AddOrUpdate
    },
    activated () {
      this.getDataList()
    },
    filters:{
      showText(e){
        return e?e:'暂无'
      }
    },
    methods: {
      getColor(one,ck,cl){
        let arr=this.colorList;
        if(ck===0&&cl===0){
          return one?arr[0].color:arr[1].color;
        }else if(ck===1&&cl===0){
          return arr[2].color;
        }else if(ck===0&&cl===1){
          return arr[3].color;
        }else{
          return arr[4].color;
        }
      },
      // 获取数据列表
      getDataList () {
        this.dataListLoading = true
        this.$http({
          url: this.$http.adornUrl('/cw/cwbed/list'),
          method: 'get',
          params: this.$http.adornParams({
            'page': this.pageIndex,
            'limit': this.pageSize,
            'key': this.dataForm.key
          })
        }).then(({data}) => {
          if (data && data.code === 0) {
            this.dataList = data.page.list
            this.totalPage = data.page.totalCount
          } else {
            this.dataList = []
            this.totalPage = 0
          }
          this.dataListLoading = false
        })
      },
      // 每页数
      sizeChangeHandle (val) {
        this.pageSize = val
        this.pageIndex = 1
        this.getDataList()
      },
      // 当前页
      currentChangeHandle (val) {
        this.pageIndex = val
        this.getDataList()
      },
      selectAll(){
        this.selectionChangeHandle(this.dataList.length===this.dataListSelections.length?[]:this.dataList)
      },
      // 多选
      selectionChangeHandle (val) {
        this.dataListSelections = val
      },
      // 新增 / 修改
      addOrUpdateHandle (id) {
        this.addOrUpdateVisible = true
        this.$nextTick(() => {
          this.$refs.addOrUpdate.init(id)
        })
      },
      // 删除
      deleteHandle (id) {
        var ids = id ? [id] : this.dataListSelections.map(item => {
          return item.bedId
        })
        this.$confirm(`确定对[id=${ids.join(',')}]进行[${id ? '删除' : '批量删除'}]操作?`, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.$http({
            url: this.$http.adornUrl('/cw/cwbed/delete'),
            method: 'post',
            data: this.$http.adornData(ids, false)
          }).then(({data}) => {
            if (data && data.code === 0) {
              this.$message({
                message: '操作成功',
                type: 'success',
                duration: 1500,
                onClose: () => {
                  this.getDataList()
                }
              })
            } else {
              this.$message.error(data.msg)
            }
          })
        })
      }
    }
  }
</script>

<style>

   /* 设置滚动条的样式 */
   ::-webkit-scrollbar {
     width:10px;
   }
   /* 滚动槽 */
   ::-webkit-scrollbar-track {
     -webkit-box-shadow:inset006pxrgba(35, 71, 75, 0.3);
     border-radius:10px;
   }
   /* 滚动条滑块 */
   ::-webkit-scrollbar-thumb {
     border-radius:10px;
     background:rgba(175, 82, 119, 0.5);
     -webkit-box-shadow:inset006pxrgba(175, 82, 119, 0.5);
   }
   .colorBar{
      text-align: right;
      margin-bottom: 5px;
    }
   .mycontainer{
     height: 680px;
     overflow-y: auto;
   }
  .row{
    margin-top: 10px;
    display: flex;
    /* justify-content: center; */
    position: relative;
  }
  .card{
   display: block;
   margin: 10px 20px;
  }
  .mybody{
    margin-top: 5px;
  }
  .myfoot{
    margin-top: 10px;
    float: right;
  }
  table{
    margin: 10px auto;
  }
  table tr{
    height: 25px;
  }
</style>
