<template>
  <el-dialog :title="!dataForm.id ? '新增' : '修改'" :close-on-click-modal="false" :visible.sync="visible">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()"
      label-width="80px">
      <el-form-item label="楼层1-7" prop="roomFloor">
        <el-select v-model="dataForm.roomFloor" clearable placeholder="选择楼层" style="width: 140px" >
          <el-option v-for="item in floor" :key="item.value" :value="item.value" :label="item.text" />
        </el-select>
      </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
  export default {
    props:{
      floor:Array
    },
    data() {
      return {
        visible: false,
        dataForm: {
          roomId: 0,
          roomFloor:''
        },
        dataRule: {
          roomFloor: [{
            required: true,
            message: '楼层1-7不能为空',
            trigger: 'blur'
          }]
        }
      }
    },
    methods: {
      init(id) {
        this.dataForm.roomId = id || 0
        this.visible = true
        this.$nextTick(() => {
          this.$refs['dataForm'].resetFields()
          if (this.dataForm.roomId) {
            this.$http({
              url: this.$http.adornUrl(`/cw/cwroom/info/${this.dataForm.roomId}`),
              method: 'get',
              params: this.$http.adornParams()
            }).then(({
              data
            }) => {
              if (data && data.code === 0) {
                this.dataForm.roomFloor = data.cwRoom.roomFloor
              }
            })
          }
        })
      },
      // 表单提交
      dataFormSubmit() {
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            this.$http({
              url: this.$http.adornUrl(`/cw/cwroom/${!this.dataForm.roomId ? 'save' : 'update'}`),
              method: 'post',
              data: this.$http.adornData({
                'roomId': this.dataForm.roomId || undefined,
                'roomFloor': this.dataForm.roomFloor,
              })
            }).then(({
              data
            }) => {
              if (data && data.code === 0) {
                this.$message({
                  message: '操作成功',
                  type: 'success',
                  duration: 1500,
                  onClose: () => {
                    this.visible = false
                    this.$emit('refreshDataList')
                  }
                })
              } else {
                this.$message.error(data.msg)
              }
            })
          }
        })
      }
    }
  }
</script>
