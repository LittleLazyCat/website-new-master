<template>
  <el-dialog
    :title="!dataForm.id ? '新增' : '修改'"
    :close-on-click-modal="false"
    :visible.sync="visible"
    @open="handleOpen()">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="100px">
    <el-form-item label="客户id" prop="customerId">
      <el-select v-model="dataForm.customerId" placeholder="请选择客户" :disabled="dataForm.id?true:false">
        <el-option
          v-for="item in checkedCustList"
          :key="item.ckiId"
          :label="item.customerName"
          :value="item.customerId">
          <template sloe-scope="{item}" >
            <el-row>
              <el-col :span="5" style="padding: 3px 0px;"><el-image :src="item.headImgUrl" style="width: 25px;height: 25px;border-radius: 50%;"></el-image></el-col>
              <el-col :span="7">{{item.customerName}}</el-col>
              <el-col :span="7" style="font-size: 12px;color: silver;">({{item.identityNumber.substring(0,8)+'...'}})</el-col>
            </el-row>
          </template>
        </el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="订单类型" prop="orderType">
      <el-select v-model="dataForm.orderType" placeholder="请选择订单类型" :disabled="dataForm.id?true:false">
        <el-option
          v-for="(item,index) in ['饮食','护理']"
          :key="item"
          :label="item"
          :value="item">
          </el-option>
        </el-select>
    </el-form-item>
    <el-form-item label="项目名称" prop="orderName">
      <el-input v-model="dataForm.orderName" placeholder="订单项目名称"></el-input>
    </el-form-item>
    <el-form-item label="订单数目" prop="orderNum">
      <el-input v-model="dataForm.orderNum" placeholder="订单数目"></el-input>
    </el-form-item>
    <el-form-item label="订单金额" prop="orderCost">
      <el-input v-model="dataForm.orderCost" placeholder="订单金额"></el-input>
    </el-form-item>
    <el-form-item label="缴费状态" prop="payState">
      <el-switch
        v-model="dataForm.payState"
        active-color="#13ce66"
        inactive-color="#a8a6a0"
        :active-value='1'
        :inactive-value='0'>
      </el-switch>
    </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
  export default {
    data () {
      return {
        visible: false,
        checkedCustList:[],
        dataForm: {
          orderId: 0,
          customerId: '',
          orderType: '',
          orderName: '',
          orderNum: '',
          orderCost: '',
          payState:0
        },
        dataRule: {
          customerId: [
            { required: true, message: '客户id：订单的源主不能为空', trigger: 'blur' }
          ],
          orderType: [
            { required: true, message: '订单类型[饮食、护理]不能为空', trigger: 'blur' }
          ],
          orderName: [
            { required: true, message: '订单项目名称:对应膳食名称或护理项目名称不能为空', trigger: 'blur' }
          ],
          orderNum: [
            { required: true, message: '订单数目：默认为1，对应所定项目的数量不能为空', trigger: 'blur' }
          ],
          orderCost: [
            { required: true, message: '订单金额(单个项目的费用)不能为空', trigger: 'blur' }
          ],
        }
      }
    },
    methods: {
      handleOpen(){
        this.getCheckedCustList();
      },
      getCheckedCustList(){
        this.$http({
          url: this.$http.adornUrl(`/customer/infocheckout/getCheckedCustomer`),
          method: 'get',
        }).then(({data})=>{
          if (data && data.code === 0) {
            this.checkedCustList=data.data;
          }
        })
      },
      init (id) {
        this.dataForm.orderId = id || 0
        this.visible = true
        this.$nextTick(() => {
          this.$refs['dataForm'].resetFields()
          if (this.dataForm.orderId) {
            this.$http({
              url: this.$http.adornUrl(`/fy/fyorder/info/${this.dataForm.orderId}`),
              method: 'get',
              params: this.$http.adornParams()
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.dataForm.customerId = data.fyOrder.customerId
                this.dataForm.orderType = data.fyOrder.orderType
                this.dataForm.orderName = data.fyOrder.orderName
                this.dataForm.orderNum = data.fyOrder.orderNum
                this.dataForm.orderCost = data.fyOrder.orderCost
                this.dataForm.payState = data.fyOrder.payState
              }
            })
          }
        })
      },
      // 表单提交
      dataFormSubmit () {
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            this.$http({
              url: this.$http.adornUrl(`/fy/fyorder/${!this.dataForm.orderId ? 'save' : 'update'}`),
              method: 'post',
              data: this.$http.adornData({
                'orderId': this.dataForm.orderId || undefined,
                'customerId': this.dataForm.customerId,
                'orderType': this.dataForm.orderType,
                'orderName': this.dataForm.orderName,
                'orderNum': this.dataForm.orderNum,
                'orderCost': this.dataForm.orderCost,
                'payState': this.dataForm.payState,
              })
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.$message({
                  message: '操作成功',
                  type: 'success',
                  duration: 1500,
                  onClose: () => {
                    this.visible = false
                    this.$emit('refreshDataList')
                  }
                })
              } else {
                this.$message.error(data.msg)
              }
            })
          }
        })
      }
    }
  }
</script>
