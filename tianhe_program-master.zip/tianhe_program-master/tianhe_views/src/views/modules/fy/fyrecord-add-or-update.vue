<template>
  <el-dialog
    :title="!dataForm.id ? '新增' : '修改'"
    :close-on-click-modal="false"
    :visible.sync="visible">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="80px">
    <el-form-item label="客户ID" prop="costumerId">
      <el-input v-model="dataForm.costumerId" placeholder="客户ID"></el-input>
    </el-form-item>
    <el-form-item label="订单编号" prop="orderId">
      <el-input v-model="dataForm.orderId" placeholder="订单编号"></el-input>
    </el-form-item>
    <el-form-item label="费用总额" prop="totalcost">
      <el-input v-model="dataForm.totalcost" placeholder="费用总额"></el-input>
    </el-form-item>
    <el-form-item label="缴费状态" prop="payState">
      <el-switch
        v-model="dataForm.payState"
        active-color="#13ce66"
        inactive-color="#a8a6a0"
        :active-value='1'
        :inactive-value='0'>
      </el-switch>
    </el-form-item>
    <el-form-item label="缴费时间" prop="payTime">
      <el-input v-model="dataForm.payTime" placeholder="缴费时间"></el-input>
      <el-date-picker
        v-model="dataForm.payTime"
        format="yyyy-MM-dd HH:mm:ss"
        value-format="yyyy-MM-dd HH:mm:ss"
        align="right"
        type="datetime"
        placeholder="请选择缴费时间">
      </el-date-picker>
    </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
  export default {
    data () {
      return {
        visible: false,
        dataForm: {
          id: 0,
          costumerId: '',
          orderId: '',
          totalcost: '',
          payState: 0,
          payTime: '',
        },
        dataRule: {
          costumerId: [
            { required: true, message: '客户ID不能为空', trigger: 'blur' }
          ],
          orderId: [
            { required: true, message: '订单编号不能为空', trigger: 'blur' }
          ],
          totalcost: [
            { required: true, message: '费用总额不能为空', trigger: 'blur' }
          ],
          payState: [
            { required: true, message: '缴费状态：默认值=0-未缴费，1-已缴费不能为空', trigger: 'blur' }
          ],
          payTime: [
            { required: true, message: '缴费时间不能为空', trigger: 'blur' }
          ],
        }
      }
    },
    methods: {
      init (id) {
        this.dataForm.id = id || 0
        this.visible = true
        this.$nextTick(() => {
          this.$refs['dataForm'].resetFields()
          if (this.dataForm.id) {
            this.$http({
              url: this.$http.adornUrl(`/fy/fyrecord/info/${this.dataForm.id}`),
              method: 'get',
              params: this.$http.adornParams()
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.dataForm.costumerId = data.fyRecord.costumerId
                this.dataForm.orderId = data.fyRecord.orderId
                this.dataForm.totalcost = data.fyRecord.totalcost
                this.dataForm.payState = data.fyRecord.payState
                this.dataForm.payTime = data.fyRecord.payTime
              }
            })
          }
        })
      },
      // 表单提交
      dataFormSubmit () {
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            this.$http({
              url: this.$http.adornUrl(`/fy/fyrecord/${!this.dataForm.id ? 'save' : 'update'}`),
              method: 'post',
              data: this.$http.adornData({
                'id': this.dataForm.id || undefined,
                'costumerId': this.dataForm.costumerId,
                'orderId': this.dataForm.orderId,
                'totalcost': this.dataForm.totalcost,
                'payState': this.dataForm.payState,
                'payTime': this.dataForm.payTime,
              })
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.$message({
                  message: '操作成功',
                  type: 'success',
                  duration: 1500,
                  onClose: () => {
                    this.visible = false
                    this.$emit('refreshDataList')
                  }
                })
              } else {
                this.$message.error(data.msg)
              }
            })
          }
        })
      }
    }
  }
</script>
