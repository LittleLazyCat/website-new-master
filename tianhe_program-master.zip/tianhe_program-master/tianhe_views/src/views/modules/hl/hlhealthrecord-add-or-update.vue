<template>
  <el-dialog
    :title="!dataForm.id ? '新增' : '修改'"
    :close-on-click-modal="false"
    :visible.sync="visible"
    @open="handleOpen">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="100px">
    <el-form-item label="客户id:" prop="customerId">
      <el-select v-model="dataForm.customerId" placeholder="请选择客户" :disabled="dataForm.id?true:false">
        <el-option
          v-for="item in checkedCustList"
          :key="item.ckiId"
          :label="item.customerName"
          :value="item.customerId">
          <template sloe-scope="{item}" >
            <el-row>
              <el-col :span="5" style="padding: 3px 0px;"><el-image :src="item.headImgUrl" style="width: 25px;height: 25px;border-radius: 50%;"></el-image></el-col>
              <el-col :span="7">{{item.customerName}}</el-col>
              <el-col :span="7" style="font-size: 12px;color: silver;">({{item.identityNumber.substring(0,8)+'...'}})</el-col>
            </el-row>
          </template>
        </el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="体检时间" prop="doTime">
      <el-date-picker
        v-model="dataForm.doTime"
        format="yyyy-MM-dd HH:mm:ss"
        value-format="yyyy-MM-dd HH:mm:ss"
        align="right"
        type="datetime"
        placeholder="请选择体检时间">
      </el-date-picker>
    </el-form-item>
    <el-form-item label="肝功能：" prop="liverFunction">
      <el-input v-model="dataForm.liverFunction" placeholder="正常（0-40）"></el-input>
    </el-form-item>
    <el-form-item label="血糖：" prop="bloodSugar">
      <el-input v-model="dataForm.bloodSugar" placeholder="正常（3.9-6.0）"></el-input>
    </el-form-item>
    <el-form-item label="心率：" prop="heartRate">
      <el-input v-model="dataForm.heartRate" placeholder="正常（60-100)"></el-input>
    </el-form-item>
    <el-form-item label="肾功能：" prop="kidneyFunction">
      <el-input v-model="dataForm.kidneyFunction" placeholder="正常（50-130)"></el-input>
    </el-form-item>
    <el-form-item label="体检医生：" prop="empId">
      <el-select v-model="dataForm.empId" placeholder="检修人">
        <el-option v-for="item in docList" :key="item.id" :label="item.empName" :value="item.id">
          <template sloe-scope="{item}" >
            <el-row>
              <el-col :span="5" style="padding: 3px 0px;"><el-image :src="item.headImgUrl" style="width: 25px;height: 25px;border-radius: 50%;"></el-image></el-col>
              <el-col :span="7">{{item.empName}}</el-col>
              <el-col :span="7" style="font-size: 12px;color: silver;">({{item.empPhone}})</el-col>
            </el-row>
          </template>
        </el-option>
      </el-select>
    </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
  export default {
    data () {
      return {
        checkedCustList:[],
        docList:[],
        visible: false,
        dataForm: {
          id: 0,
          customerId: '',
          doTime: '',
          liverFunction: '',
          bloodSugar: '',
          heartRate: '',
          kidneyFunction: '',
          empId: '',
          createTime: '',
          updateTime: '',
          isDelete: ''
        },
        dataRule: {
          customerId: [
            { required: true, message: '客户id：不能为空', trigger: 'blur' }
          ],
          doTime: [
            { required: true, message: '体检时间不能为空', trigger: 'blur' }
          ],
          liverFunction: [
            { required: true, message: '肝功不能为空', trigger: 'blur' },
            {pattern:'^[0-9]*[1-9][0-9]*$' ,message:'一定要是整数哟',trigger:'change'}
          ],
          bloodSugar: [
            { required: true, message: '血糖不能为空', trigger: 'blur' },
            {pattern:'^\\d+(\\.[\\d]{1,2})?$' ,message:'不是至少两位的合法小数哟',trigger:'change'}
          ],
          heartRate: [
            { required: true, message: '心率不能为空', trigger: 'blur' },
            {pattern:'^[0-9]*[1-9][0-9]*$' ,message:'一定要是整数哟',trigger:'change'}
          ],
          kidneyFunction: [
            { required: true, message: '肾功不能为空', trigger: 'blur' },
            {pattern:'^[0-9]*[1-9][0-9]*$' ,message:'一定要是整数哟',trigger:'change'}
          ],
          empId: [
            { required: true, message: '体检医生id不能为空', trigger: 'blur' }
          ],
        }
      }
    },
    methods: {
      handleOpen(){
        this.getCheckedCustList();
        this.getDocList();
      },
      getDocList(){
        this.$http({
          url:this.$http.adornUrl("/mysys/sysemployee/getEmpListByRole/5"),
          method:'get'
        }).then(({data})=>{
          if(data && data.code===0){
            this.docList=data.data;
          }
        })
      },
      getCheckedCustList(){
        this.$http({
          url: this.$http.adornUrl(`/customer/infocheckout/getCheckedCustomer`),
          method: 'get',
        }).then(({data})=>{
          if (data && data.code === 0) {
            this.checkedCustList=data.data;
          }
        })
      },
      init (id) {
        this.dataForm.id = id || 0
        this.visible = true
        this.$nextTick(() => {
          this.$refs['dataForm'].resetFields()
          if (this.dataForm.id) {
            this.$http({
              url: this.$http.adornUrl(`/hl/hlhealthrecord/info/${this.dataForm.id}`),
              method: 'get',
              params: this.$http.adornParams()
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.dataForm.customerId = data.hlHealthRecord.customerId
                this.dataForm.doTime = data.hlHealthRecord.doTime
                this.dataForm.liverFunction = data.hlHealthRecord.liverFunction.toFixed(0)
                this.dataForm.bloodSugar = data.hlHealthRecord.bloodSugar.toFixed(2)
                this.dataForm.heartRate = data.hlHealthRecord.heartRate.toFixed(0)
                this.dataForm.kidneyFunction = data.hlHealthRecord.kidneyFunction.toFixed(0)
                this.dataForm.empId = data.hlHealthRecord.empId
              }
            })
          }
        })
      },
      // 表单提交
      dataFormSubmit () {
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            this.$http({
              url: this.$http.adornUrl(`/hl/hlhealthrecord/${!this.dataForm.id ? 'save' : 'update'}`),
              method: 'post',
              data: this.$http.adornData({
                'id': this.dataForm.id || undefined,
                'customerId': this.dataForm.customerId,
                'doTime': this.dataForm.doTime,
                'liverFunction': this.dataForm.liverFunction,
                'bloodSugar': this.dataForm.bloodSugar,
                'heartRate': this.dataForm.heartRate,
                'kidneyFunction': this.dataForm.kidneyFunction,
                'empId': this.dataForm.empId,
              })
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.$message({
                  message: '操作成功',
                  type: 'success',
                  duration: 1500,
                  onClose: () => {
                    this.visible = false
                    this.$emit('refreshDataList')
                  }
                })
              } else {
                this.$message.error(data.msg)
              }
            })
          }
        })
      }
    }
  }
</script>
