<template>
  <el-dialog
    :title="!dataForm.id ? '新增' : '修改'"
    :close-on-click-modal="false"
    :visible.sync="visible">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="80px">
    <el-form-item label="级别名称" prop="levelName">
      <el-input v-model="dataForm.levelName" placeholder="护理级别名称"></el-input>
    </el-form-item>
    <el-form-item label="级别描述" prop="levelDescribe">
      <el-input v-model="dataForm.levelDescribe" placeholder="护理级别描述"></el-input>
    </el-form-item>
    <el-form-item label="是否启用" prop="levelState">
      <el-switch
        style="display: block"
        v-model="dataForm.levelState"
        active-color="#13ce66"
        inactive-color="#a8a6a0">
      </el-switch>
    </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
  export default {
    data () {
      return {
        visible: false,
        dataForm: {
          levelId: 0,
          levelName: '',
          levelDescribe: '',
          levelState:true,
        },
        dataRule: {
          levelName: [
            { required: true, message: '护理级别名称不能为空', trigger: 'blur' }
          ],
          levelDescribe: [
            { required: true, message: '护理级别描述不能为空', trigger: 'blur' }
          ],
          levelState: [
            { required: true, message: '级别状态，默认=1启用 0禁用不能为空', trigger: 'blur' }
          ],
        }
      }
    },
    methods: {
      init (id) {
        this.dataForm.levelId = id || 0
        this.visible = true
        this.$nextTick(() => {
          this.$refs['dataForm'].resetFields()
          if (this.dataForm.levelId) {
            this.$http({
              url: this.$http.adornUrl(`/hl/hllevel/info/${this.dataForm.levelId}`),
              method: 'get',
              params: this.$http.adornParams()
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.dataForm.levelName = data.hlLevel.levelName
                this.dataForm.levelDescribe = data.hlLevel.levelDescribe
                this.dataForm.levelState = data.hlLevel.levelState?true:false
              }
            })
          }
        })
      },
      // 表单提交
      dataFormSubmit () {
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            this.$http({
              url: this.$http.adornUrl(`/hl/hllevel/${!this.dataForm.levelId ? 'save' : 'update'}`),
              method: 'post',
              data: this.$http.adornData({
                'levelId': this.dataForm.levelId || undefined,
                'levelName': this.dataForm.levelName,
                'levelDescribe': this.dataForm.levelDescribe,
                'levelState': this.dataForm.levelState?1:0,
              })
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.$message({
                  message: '操作成功',
                  type: 'success',
                  duration: 1500,
                  onClose: () => {
                    this.visible = false
                    this.$emit('refreshDataList')
                  }
                })
              } else {
                this.$message.error(data.msg)
              }
            })
          }
        })
      }
    }
  }
</script>
