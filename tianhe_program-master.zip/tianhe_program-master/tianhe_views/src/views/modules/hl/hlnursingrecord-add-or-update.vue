<template>
  <el-dialog
    :title="!dataForm.id ? '新增' : '修改'"
    :close-on-click-modal="false"
    :visible.sync="visible"
    @open="handleOpen()">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="80px">
    <el-form-item label="客户id" prop="customerId">
      <el-select v-model="dataForm.customerId" placeholder="请选择客户" :disabled="dataForm.id?true:false">
        <el-option
          v-for="item in checkedCustList"
          :key="item.ckiId"
          :label="item.customerName"
          :value="item.customerId">
          <template sloe-scope="{item}" >
            <el-row>
              <el-col :span="5" style="padding: 3px 0px;"><el-image :src="item.headImgUrl" style="width: 25px;height: 25px;border-radius: 50%;"></el-image></el-col>
              <el-col :span="7">{{item.customerName}}</el-col>
              <el-col :span="7" style="font-size: 12px;color: silver;">({{item.identityNumber.substring(0,8)+'...'}})</el-col>
            </el-row>
          </template>
        </el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="护理时间" prop="nursingTime">
      <el-date-picker
        v-model="dataForm.nursingTime"
        format="yyyy-MM-dd HH:mm:ss"
        value-format="yyyy-MM-dd HH:mm:ss"
        align="right"
        type="datetime"
        placeholder="请选择护理时间">
      </el-date-picker>
    </el-form-item>
    <el-form-item label="护理项目" prop="projectId">
      <el-select v-model="dataForm.projectId" placeholder="护理项目">
        <el-option v-for="item in projectList" :key="item.projectId" :label="item.projectName" :value="item.projectId">
          <template sloe-scope="{item}" >
              {{item.projectName}}
              <span style="font-size: 12px;color: silver;">({{item.projectDescribe}})</span>
          </template>
        </el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="数量" prop="number">
      <el-input placeholder="采购数量" type="digit" v-model="dataForm.number"  style="width: 220px;" maxlength="4">
          <el-button slot="prepend" icon="el-icon-minus" @click="changeNumber(false)" :disabled="dataForm.number<=1"></el-button>
          <el-button slot="append" icon="el-icon-plus" @click="changeNumber(true)" :disabled="dataForm.number>=9999"></el-button>
      </el-input>
    </el-form-item>
    <el-form-item label="护理等级" prop="levelId">
      <el-select v-model="dataForm.levelId" placeholder="护理级别">
        <el-option v-for="item in levelList" :key="item.levelId" :label="item.levelName" :value="item.levelId">
          <template sloe-scope="{item}" >
              {{item.levelName}}
              <span style="font-size: 12px;color: silver;">({{item.levelDescribe}})</span>
          </template>
        </el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="护理人员" prop="empId">
      <el-select v-model="dataForm.empId" placeholder="护理师">
        <el-option v-for="item in hlerList" :key="item.id" :label="item.empName" :value="item.id">
          <template sloe-scope="{item}" >
            <el-row>
              <el-col :span="5" style="padding: 3px 0px;"><el-image :src="item.headImgUrl" style="width: 25px;height: 25px;border-radius: 50%;"></el-image></el-col>
              <el-col :span="7">{{item.empName}}</el-col>
              <el-col :span="7" style="font-size: 12px;color: silver;">({{item.empPhone}})</el-col>
            </el-row>
          </template>
        </el-option>
      </el-select>
    </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
  export default {
    data () {
      return {
        visible: false,
        checkedCustList:[],
        levelList:[],
        hlerList:[],
        projectList:[],
        dataForm: {
          id: 0,
          customerId: '',
          nursingTime: '',
          projectId: '',
          number: 1,
          levelId: '',
          empId: '',
        },
        dataRule: {
          customerId: [
            { required: true, message: '参照客户档案中的id不能为空', trigger: 'blur' }
          ],
          nursingTime: [
            { required: true, message: '护理时间不能为空', trigger: 'blur' }
          ],
          projectId: [
            { required: true, message: '参照护理项目表中的id不能为空', trigger: 'blur' }
          ],
          number: [
            { required: true, message: '数量不能为空', trigger: 'blur' },
            { pattern:'^\\+?([1-9]{1})$',message:'数量不合法(1-9)',trigger:'change'}
          ],
          levelId: [
            { required: true, message: '参照护理等级不能为空', trigger: 'blur' }
          ],
          empId: [
            { required: true, message: '参照职工表中的id不能为空', trigger: 'blur' }
          ],
        }
      }
    },
    methods: {
      changeNumber(flag){
        if(flag){
          this.dataForm.number++;
        }else{
          this.dataForm.number-=1;
        }
        this.dataForm.number+="";
      },
      handleOpen(){
        this.getCheckedCustList();
        this.getProjectList();
        this.gethlerList();
        this.getAvailableHlLevelList();
      },
      getAvailableHlLevelList(){
        this.$http({
          url:this.$http.adornUrl("/hl/hllevel/getAvailableHlLevelList"),
          method:'get'
        }).then(({data})=>{
          if(data && data.code===0){
            this.levelList=data.data;
          }
        })
      },
      getCheckedCustList(){
        this.$http({
          url: this.$http.adornUrl(`/customer/infocheckout/getCheckedCustomer`),
          method: 'get',
        }).then(({data})=>{
          if (data && data.code === 0) {
            this.checkedCustList=data.data;
          }
        })
      },
      gethlerList(){
        this.$http({
          url:this.$http.adornUrl("/mysys/sysemployee/getEmpListByRole/3"),
          method:'get'
        }).then(({data})=>{
          if(data && data.code===0){
            this.hlerList=data.data;
          }
        })
      },
      getProjectList(){
        this.$http({
          url:this.$http.adornUrl("/hl/hlproject/getProjectList"),
          method:'get'
        }).then(({data})=>{
          if(data && data.code===0){
            this.projectList=data.data;
          }
        })
      },
      init (id) {
        this.dataForm.id = id || 0
        this.visible = true
        this.$nextTick(() => {
          this.$refs['dataForm'].resetFields()
          if (this.dataForm.id) {
            this.$http({
              url: this.$http.adornUrl(`/hl/hlnursingrecord/info/${this.dataForm.id}`),
              method: 'get',
              params: this.$http.adornParams()
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.dataForm.customerId = data.hlNursingRecord.customerId
                this.dataForm.nursingTime = data.hlNursingRecord.nursingTime
                this.dataForm.projectId = data.hlNursingRecord.projectId
                this.dataForm.number = data.hlNursingRecord.number.toFixed(0)
                this.dataForm.levelId = data.hlNursingRecord.levelId
                this.dataForm.empId = data.hlNursingRecord.empId
              }
            })
          }
        })
      },
      // 表单提交
      dataFormSubmit () {
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            this.$http({
              url: this.$http.adornUrl(`/hl/hlnursingrecord/${!this.dataForm.id ? 'save' : 'update'}`),
              method: 'post',
              data: this.$http.adornData({
                'id': this.dataForm.id || undefined,
                'customerId': this.dataForm.customerId,
                'nursingTime': this.dataForm.nursingTime,
                'projectId': this.dataForm.projectId,
                'number': this.dataForm.number,
                'levelId': this.dataForm.levelId,
                'empId': this.dataForm.empId,
              })
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.$message({
                  message: '操作成功',
                  type: 'success',
                  duration: 1500,
                  onClose: () => {
                    this.visible = false
                    this.$emit('refreshDataList')
                  }
                })
              } else {
                this.$message.error(data.msg)
              }
            })
          }
        })
      }
    }
  }
</script>
