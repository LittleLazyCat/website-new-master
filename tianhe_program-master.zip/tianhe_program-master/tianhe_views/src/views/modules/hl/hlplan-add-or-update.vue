<template>
  <el-dialog
    :title="!dataForm.id ? '新增' : '修改'"
    :close-on-click-modal="false"
    :visible.sync="visible"
    @open="handleOpen">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="100px">
    <el-form-item label="护理项目" prop="projectId">
      <el-select v-model="dataForm.projectId" placeholder="护理项目">
        <el-option v-for="item in projectList" :key="item.projectId" :label="item.projectName" :value="item.projectId">
          <template sloe-scope="{item}" >
              {{item.projectName}}
              <span style="font-size: 12px;color: silver;">({{item.projectDescribe}})</span>
          </template>
        </el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="护理级别" prop="levelId">
      <el-select v-model="dataForm.levelId" placeholder="护理级别">
        <el-option v-for="item in levelList" :key="item.levelId" :label="item.levelName" :value="item.levelId">
          <template sloe-scope="{item}" >
              {{item.levelName}}
              <span style="font-size: 12px;color: silver;">({{item.levelDescribe}})</span>
          </template>
        </el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="客户" prop="customId">
      <el-select v-model="dataForm.customId" placeholder="请选择客户" :disabled="dataForm.id?true:false">
        <el-option
          v-for="item in checkedCustList"
          :key="item.ckiId"
          :label="item.customerName"
          :value="item.customerId">
          <template sloe-scope="{item}" >
            <el-row>
              <el-col :span="5" style="padding: 3px 0px;"><el-image :src="item.headImgUrl" style="width: 25px;height: 25px;border-radius: 50%;"></el-image></el-col>
              <el-col :span="7">{{item.customerName}}</el-col>
              <el-col :span="7" style="font-size: 12px;color: silver;">({{item.identityNumber.substring(0,8)+'...'}})</el-col>
            </el-row>
          </template>
        </el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="护理师" prop="empId">
      <el-select v-model="dataForm.empId" placeholder="护理师">
        <el-option v-for="item in hlerList" :key="item.id" :label="item.empName" :value="item.id">
          <template sloe-scope="{item}" >
            <el-row>
              <el-col :span="5" style="padding: 3px 0px;"><el-image :src="item.headImgUrl" style="width: 25px;height: 25px;border-radius: 50%;"></el-image></el-col>
              <el-col :span="7">{{item.empName}}</el-col>
              <el-col :span="7" style="font-size: 12px;color: silver;">({{item.empPhone}})</el-col>
            </el-row>
          </template>
        </el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="计划周期：" prop="planCycle">
      <el-select v-model="dataForm.planCycle" placeholder="预计计划周期">
        <el-option v-for="item in week" :key="item.value" :label="item.text" :value="item.value">
        </el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="计划备注" prop="planDesc">
      <el-input v-model="dataForm.planDesc" placeholder="护理计划描述"></el-input>
    </el-form-item>
    <el-form-item label="计划状态" prop="planState">
      <el-switch
        v-model="dataForm.planState"
        active-color="#13ce66"
        inactive-color="#a8a6a0"
        :active-value='1'
        :inactive-value='0'>
      </el-switch>
    </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
  export default {
    props:{
      week:Array
    },
    data () {
      return {
        hlerList:[],
        checkedCustList:[],
        levelList:[],
        projectList:[],
        visible: false,
        dataForm: {
          planId: 0,
          projectId: '',
          levelId: '',
          customId: '',
          empId: '',
          planDesc: '',
          planState: '',
          planCycle: '',
          createTime: '',
          updateTime: '',
          isDelete: ''
        },
        dataRule: {
          projectId: [
            { required: true, message: '项目id不能为空', trigger: 'blur' }
          ],
          levelId: [
            { required: true, message: '级别id不能为空', trigger: 'blur' }
          ],
          customId: [
            { required: true, message: '客户id不能为空', trigger: 'blur' }
          ],
          empId: [
            { required: true, message: '护理师id不能为空', trigger: 'blur' }
          ],
          planDesc: [
            { required: true, message: '护理计划描述不能为空', trigger: 'blur' }
          ],
          planState: [
            { required: true, message: '计划状态不能为空', trigger: 'blur' }
          ],
          planCycle: [
            { required: true, message: '预计计划周期不能为空', trigger: 'blur' }
          ],
        }
      }
    },
    methods: {
      handleOpen(){
        this.gethlerList();
        this.getCheckedCustList();
        this.getProjectList();
        this.getAvailableHlLevelList();
      },
      getCheckedCustList(){
        this.$http({
          url: this.$http.adornUrl(`/customer/infocheckout/getCheckedCustomer`),
          method: 'get',
        }).then(({data})=>{
          if (data && data.code === 0) {
            this.checkedCustList=data.data;
          }
        })
      },
      getProjectList(){
        this.$http({
          url:this.$http.adornUrl("/hl/hlproject/getProjectList"),
          method:'get'
        }).then(({data})=>{
          if(data && data.code===0){
            this.projectList=data.data;
          }
        })
      },
      gethlerList(){
        this.$http({
          url:this.$http.adornUrl("/mysys/sysemployee/getEmpListByRole/3"),
          method:'get'
        }).then(({data})=>{
          if(data && data.code===0){
            this.hlerList=data.data;
          }
        })
      },
      getAvailableHlLevelList(){
        this.$http({
          url:this.$http.adornUrl("/hl/hllevel/getAvailableHlLevelList"),
          method:'get'
        }).then(({data})=>{
          if(data && data.code===0){
            this.levelList=data.data;
          }
        })
      },
      init (id) {
        this.dataForm.planId = id || 0
        this.visible = true
        this.$nextTick(() => {
          this.$refs['dataForm'].resetFields()
          if (this.dataForm.planId) {
            this.$http({
              url: this.$http.adornUrl(`/hl/hlplan/info/${this.dataForm.planId}`),
              method: 'get',
              params: this.$http.adornParams()
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.dataForm.projectId = data.hlPlan.projectId
                this.dataForm.levelId = data.hlPlan.levelId
                this.dataForm.customId = data.hlPlan.customId
                this.dataForm.empId = data.hlPlan.empId
                this.dataForm.planDesc = data.hlPlan.planDesc
                this.dataForm.planState = data.hlPlan.planState
                this.dataForm.planCycle = data.hlPlan.planCycle
              }
            })
          }
        })
      },
      // 表单提交
      dataFormSubmit () {
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            this.$http({
              url: this.$http.adornUrl(`/hl/hlplan/${!this.dataForm.planId ? 'save' : 'update'}`),
              method: 'post',
              data: this.$http.adornData({
                'planId': this.dataForm.planId || undefined,
                'projectId': this.dataForm.projectId,
                'levelId': this.dataForm.levelId,
                'customId': this.dataForm.customId,
                'empId': this.dataForm.empId,
                'planDesc': this.dataForm.planDesc,
                'planState': this.dataForm.planState,
                'planCycle': this.dataForm.planCycle,
              })
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.$message({
                  message: '操作成功',
                  type: 'success',
                  duration: 1500,
                  onClose: () => {
                    this.visible = false
                    this.$emit('refreshDataList')
                  }
                })
              } else {
                this.$message.error(data.msg)
              }
            })
          }
        })
      }
    }
  }
</script>
