<template>
  <el-dialog
    :title="!dataForm.id ? '新增' : '修改'"
    :close-on-click-modal="false"
    :visible.sync="visible">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="80px">
    <el-form-item label="护理项目" prop="projectName">
      <el-input v-model="dataForm.projectName" placeholder="护理项目名称"></el-input>
    </el-form-item>
    <el-form-item label="描述" prop="projectDescribe">
      <el-input v-model="dataForm.projectDescribe" placeholder="护理项目描述"></el-input>
    </el-form-item>
    <el-form-item label="价格" prop="projectPrice">
      <el-input v-model="dataForm.projectPrice" placeholder="护理项目价格"></el-input>
    </el-form-item>
    <el-form-item label="备注" prop="projectNote">
      <el-input v-model="dataForm.projectNote" placeholder="护理项目备注"></el-input>
    </el-form-item>
    <el-form-item label="是否启用" prop="projectState">
      <el-switch
        v-model="dataForm.projectState"
        active-color="#13ce66"
        inactive-color="#a8a6a0"
        :active-value='1'
        :inactive-value='0'>
      </el-switch>
    </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
  export default {
    data () {
      return {
        visible: false,
        dataForm: {
          projectId: 0,
          projectName: '',
          projectDescribe: '',
          projectState: 1,
          projectPrice: '',
          projectNote: '',
          createTime: '',
          updateTime: '',
          isDelete: ''
        },
        dataRule: {
          projectName: [
            { required: true, message: '名称不能为空', trigger: 'blur' }
          ],
          projectDescribe: [
            { required: true, message: '描述不能为空', trigger: 'blur' }
          ],
          projectState: [
            { required: true, message: '项目状态默认=1启用 0禁用不能为空', trigger: 'blur' }
          ],
          projectPrice: [
            { required: true, message: '价格不能为空', trigger: 'blur' }
          ],
          projectNote: [
            { required: true, message: '备注不能为空', trigger: 'blur' }
          ],
        }
      }
    },
    methods: {
      init (id) {
        this.dataForm.projectId = id || 0
        this.visible = true
        this.$nextTick(() => {
          this.$refs['dataForm'].resetFields()
          if (this.dataForm.projectId) {
            this.$http({
              url: this.$http.adornUrl(`/hl/hlproject/info/${this.dataForm.projectId}`),
              method: 'get',
              params: this.$http.adornParams()
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.dataForm.projectName = data.hlProject.projectName
                this.dataForm.projectDescribe = data.hlProject.projectDescribe
                this.dataForm.projectState = data.hlProject.projectState
                this.dataForm.projectPrice = data.hlProject.projectPrice
                this.dataForm.projectNote = data.hlProject.projectNote
              }
            })
          }
        })
      },
      // 表单提交
      dataFormSubmit () {
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            this.$http({
              url: this.$http.adornUrl(`/hl/hlproject/${!this.dataForm.projectId ? 'save' : 'update'}`),
              method: 'post',
              data: this.$http.adornData({
                'projectId': this.dataForm.projectId || undefined,
                'projectName': this.dataForm.projectName,
                'projectDescribe': this.dataForm.projectDescribe,
                'projectState': this.dataForm.projectState,
                'projectPrice': this.dataForm.projectPrice,
                'projectNote': this.dataForm.projectNote,
              })
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.$message({
                  message: '操作成功',
                  type: 'success',
                  duration: 1500,
                  onClose: () => {
                    this.visible = false
                    this.$emit('refreshDataList')
                  }
                })
              } else {
                this.$message.error(data.msg)
              }
            })
          }
        })
      }
    }
  }
</script>
