<template>
  <el-dialog
    :title="!dataForm.id ? '新增' : '修改'"
    :close-on-click-modal="false"
    :visible.sync="visible"
    @open="handleOpen">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="100px">
    <el-form-item label="设备名称" prop="eqName">
      <el-input v-model="dataForm.eqName" placeholder="设备名称"></el-input>
    </el-form-item>
    <el-form-item label="采购时间" prop="buyTime">
      <el-date-picker
        v-model="dataForm.buyTime"
        format="yyyy-MM-dd HH:mm:ss"
        value-format="yyyy-MM-dd HH:mm:ss"
        align="right"
        type="datetime"
        placeholder="请选择采购时间">
      </el-date-picker>
    </el-form-item>
    <el-form-item label="采购数量" prop="buyAmount">
      <el-input placeholder="采购数量" type="digit" v-model="dataForm.buyAmount=new Number(dataForm.buyAmount).toFixed(0)"  style="width: 220px;" maxlength="4">
          <el-button slot="prepend" icon="el-icon-minus" @click="dataForm.buyAmount--" :disabled="dataForm.buyAmount<=0"></el-button>
          <el-button slot="append" icon="el-icon-plus" @click="dataForm.buyAmount++" :disabled="dataForm.buyAmount>=9999"></el-button>
      </el-input>
    </el-form-item>
    <el-form-item label="采购价格" prop="buyPrice">
      <el-input v-model="dataForm.buyPrice" placeholder="请输入采购价格"></el-input>
    </el-form-item>
    <el-form-item label="采购人编号" prop="empId">
      <el-select v-model="dataForm.empId" placeholder="采购人">
        <el-option v-for="item in buyerList" :key="item.id" :label="item.empName" :value="item.id">
          <template sloe-scope="{item}" >
            <el-row>
              <el-col :span="5" style="padding: 3px 0px;"><el-image :src="item.headImgUrl" style="width: 25px;height: 25px;border-radius: 50%;"></el-image></el-col>
              <el-col :span="7">{{item.empName}}</el-col>
              <el-col :span="7" style="font-size: 12px;color: silver;">({{item.empPhone}})</el-col>
            </el-row>
          </template>
        </el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="备注" prop="remarks">
      <el-input v-model="dataForm.remarks" placeholder="备注"></el-input>
    </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
  export default {
    data () {
      return {
        visible: false,
        buyerList:[],
        dataForm: {
          buyId: 0,
          eqName: '',
          buyTime: '',
          buyAmount: 0,
          buyPrice: '',
          empId: "",
          remarks: ''
        },
        dataRule: {
          eqName: [
            { required: true, message: '设备名称不能为空', trigger: 'blur' }
          ],
          buyTime: [
            { required: true, message: '采购时间不能为空', trigger: 'blur' }
          ],
          buyAmount: [
            { required: true, message: '采购数量不能为空', trigger: 'blur' },
            { pattern:'^\\+?[1-9][0-9]*$',message:'采购数量不合法',trigger:'change'}
          ],
          buyPrice: [
            { required: true, message: '采购价格不能为空', trigger: 'blur' },
            { pattern:'(^[1-9]([0-9]+)?(\.[0-9]{1,2})?$)|(^(0){1}$)|(^[0-9]\.[0-9]([0-9])?$)',message:'采购价格不合法',trigger:'change'}
          ],
          empId: [
            { required: true, message: '采购人不能为空', trigger: 'blur' }
          ],
        }
      }
    },
    methods: {
      handleOpen(){
        this.getBuyerList();
      },
      getBuyerList(){
        this.$http({
          url:this.$http.adornUrl("/mysys/sysemployee/getEmpListByRole/1"),
          method:'get'
        }).then(({data})=>{
          if(data && data.code===0){
            this.buyerList=data.data;
          }
        })
      },
      init (id) {
        this.dataForm.buyId = id || 0
        this.visible = true
        this.$nextTick(() => {
          this.$refs['dataForm'].resetFields()
          if (this.dataForm.buyId) {
            this.$http({
              url: this.$http.adornUrl(`/houqin/hqbuy/info/${this.dataForm.buyId}`),
              method: 'get',
              params: this.$http.adornParams()
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.dataForm.eqName = data.hqBuy.eqName
                this.dataForm.buyTime = data.hqBuy.buyTime
                this.dataForm.buyAmount = data.hqBuy.buyAmount*1
                this.dataForm.buyPrice = data.hqBuy.buyPrice+''
                this.dataForm.empId = data.hqBuy.empId
                this.dataForm.remarks = data.hqBuy.remarks
              }
            })
          }
        })
      },
      // 表单提交
      dataFormSubmit () {
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            this.$http({
              url: this.$http.adornUrl(`/houqin/hqbuy/${!this.dataForm.buyId ? 'save' : 'update'}`),
              method: 'post',
              data: this.$http.adornData({
                'buyId': this.dataForm.buyId || undefined,
                'eqName': this.dataForm.eqName,
                'buyTime': this.dataForm.buyTime,
                'buyAmount': this.dataForm.buyAmount,
                'buyPrice': this.dataForm.buyPrice,
                'empId': this.dataForm.empId,
                'remarks': this.dataForm.remarks
              })
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.$message({
                  message: '操作成功',
                  type: 'success',
                  duration: 1500,
                  onClose: () => {
                    this.visible = false
                    this.$emit('refreshDataList')
                  }
                })
              } else {
                this.$message.error(data.msg)
              }
            })
          }
        })
      }
    }
  }
</script>
