<template>
  <el-dialog
    :title="!dataForm.id ? '新增' : '修改'"
    :close-on-click-modal="false"
    :visible.sync="visible"
    @open="handlerDialogOpen"
    >
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="80px">
    <el-form-item label="床位" prop="bedId">
      <el-select v-model="dataForm.bedId" placeholder="请选择床位">
        <el-option
          v-for="item in bedList"
          :key="item.bedId"
          :label="'编号: '+item.bedId"
          :value="item.bedId">
        </el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="保洁员" prop="empId">
      <el-select v-model="dataForm.empId" placeholder="保洁员">
        <el-option v-for="item in cleanerList" :key="item.id" :label="item.empName" :value="item.id">
          <template sloe-scope="{item}" >
            <el-row>
              <el-col :span="5" style="padding: 3px 0px;"><el-image :src="item.headImgUrl" style="width: 25px;height: 25px;border-radius: 50%;"></el-image></el-col>
              <el-col :span="7">{{item.empName}}</el-col>
              <el-col :span="7" style="font-size: 12px;color: silver;">({{item.empPhone}})</el-col>
            </el-row>
          </template>
        </el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="清洁时间" prop="cleanTime">
      <el-date-picker
        v-model="dataForm.cleanTime"
        format="yyyy-MM-dd HH:mm:ss"
        value-format="yyyy-MM-dd HH:mm:ss"
        align="right"
        type="datetime"
        placeholder="请选择清洁时间"
        :disabled="dataForm.cleanStatus==0">
      </el-date-picker>
    </el-form-item>
    <el-form-item label="清洁状态" prop="cleanStatus">
      <el-radio-group v-model="dataForm.cleanStatus" size="small" @change="changeClean">
        <el-radio-button label="1">已清洁</el-radio-button>
        <el-radio-button label="0">未清洁</el-radio-button>
      </el-radio-group>
    </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
  export default {
    data () {
      return {
        visible: false,
        cleanerList:[],
        bedList:[],
        dataForm: {
          id: 0,
          bedId: '',
          empId: '',
          cleanTime: '',
          cleanStatus: 0
        },
        dataRule: {
          bedId: [
            { required: true, message: '床位 id 参照床位表id不能为空', trigger: 'blur' }
          ],
          empId: [
            { required: true, message: '保洁员  参照工作人员表id不能为空', trigger: 'blur' }
          ],
          cleanTime: [
            { required: false, message: '清洁时间不能为空', trigger: 'blur' }
          ],
          cleanStatus: [
            { required: true, message: '清洁状态   0 未清洁  1 已清洁不能为空', trigger: 'blur' }
          ],
        }
      }
    },
    methods: {
      changeClean(val){
        if(val==0){
          this.dataForm.cleanTime='';
          this.dataRule.cleanTime[0].required=false;
        }else{
          this.dataRule.cleanTime[0].required=true;
        }
      },
      handlerDialogOpen(){
        this.getBedList();
        this.getFixerList();
        if(this.dataForm.cleanStatus==1){
          this.dataRule.cleanTime[0].required=true
        }else{
          this.dataRule.cleanTime[0].required=false
        }
      },
      getFixerList(){
        this.$http({
          url:this.$http.adornUrl("/mysys/sysemployee/getEmpListByRole/4"),
          method:'get'
        }).then(({data})=>{
          if(data && data.code===0){
            this.cleanerList=data.data;
          }
        })
      },
      getBedList() {
        // 获取已在籍的顾客档案信息
        this.$http({
          url: this.$http.adornUrl('/cw/cwbed/getBedList?flag=true'),
          method: 'get',
        }).then(({
          data
        }) => {
          if (data && data.code === 0) {
            this.bedList = data.data
          } else {
            this.bedList = []
          }
        })
      },
      init (id) {
        this.dataForm.id = id || 0
        this.visible = true
        this.$nextTick(() => {
          this.$refs['dataForm'].resetFields()
          if (this.dataForm.id) {
            this.$http({
              url: this.$http.adornUrl(`/houqin/hqclean/info/${this.dataForm.id}`),
              method: 'get',
              params: this.$http.adornParams()
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.dataForm.bedId = data.hqClean.bedId
                this.dataForm.empId = data.hqClean.empId
                this.dataForm.cleanTime = data.hqClean.cleanTime
                this.dataForm.cleanStatus = data.hqClean.cleanStatus
                if(this.dataForm.cleanStatus==1){
                  this.dataRule.cleanTime[0].required=true
                }
              }
            })
          }
        })
      },
      // 表单提交
      dataFormSubmit () {
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            this.$http({
              url: this.$http.adornUrl(`/houqin/hqclean/${!this.dataForm.id ? 'save' : 'update'}`),
              method: 'post',
              data: this.$http.adornData({
                'id': this.dataForm.id || undefined,
                'bedId': this.dataForm.bedId,
                'empId': this.dataForm.empId,
                'cleanTime': this.dataForm.cleanTime,
                'cleanStatus': this.dataForm.cleanStatus
                // 'createTime': this.dataForm.createTime,
                // 'updateTime': this.dataForm.updateTime,
                // 'isDelete': this.dataForm.isDelete
              })
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.$message({
                  message: '操作成功',
                  type: 'success',
                  duration: 1500,
                  onClose: () => {
                    this.visible = false
                    this.$emit('refreshDataList')
                  }
                })
              } else {
                this.$message.error(data.msg)
              }
            })
          }
        })
      }
    }
  }
</script>
