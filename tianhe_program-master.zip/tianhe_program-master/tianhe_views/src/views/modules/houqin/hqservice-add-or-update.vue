<template>
  <el-dialog
    :title="!dataForm.eqId ? '新增' : '修改'"
    :close-on-click-modal="false"
    :visible.sync="visible"
    @open="handleOpen">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="80px">
    <el-form-item label="设备名称" prop="eqName">
      <el-input v-model="dataForm.eqName" placeholder="设备名称"></el-input>
    </el-form-item>
    <el-form-item label="检修状态" prop="checkStatus">
      <el-radio-group v-model="dataForm.checkStatus" size="small">
        <el-radio-button label="1" :disabled="!dataForm.eqId">已检修</el-radio-button>
        <el-radio-button label="0">未检修</el-radio-button>
      </el-radio-group>
    </el-form-item>
    <el-form-item label="检修时间" prop="checkTime">
      <el-date-picker
        v-model="dataForm.checkTime"
        format="yyyy-MM-dd HH:mm:ss"
        value-format="yyyy-MM-dd HH:mm:ss"
        align="right"
        type="datetime"
        placeholder="请选择检修时间">
      </el-date-picker>
    </el-form-item>
    <el-form-item label="检修员" prop="empId">
      <el-select v-model="dataForm.empId" placeholder="检修员">
        <el-option v-for="item in fixerList" :key="item.id" :label="item.empName" :value="item.id">
          <template sloe-scope="{item}" >
            <el-row>
              <el-col :span="5" style="padding: 3px 0px;"><el-image :src="item.headImgUrl" style="width: 25px;height: 25px;border-radius: 50%;"></el-image></el-col>
              <el-col :span="7">{{item.empName}}</el-col>
              <el-col :span="7" style="font-size: 12px;color: silver;">({{item.empPhone}})</el-col>
            </el-row>
          </template>
        </el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="检修结果" prop="checkResult">
      <el-input v-model="dataForm.checkResult" placeholder="检修结果"></el-input>
    </el-form-item>
    <el-form-item label="故障原因 " prop="reason">
      <el-input v-model="dataForm.reason" placeholder="故障原因 "></el-input>
    </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
  export default {
    data () {
      return {
        visible: false,
        fixerList:[],
        dataForm: {
          eqId: 0,
          eqName: '',
          checkStatus: 0,
          checkTime: '',
          empId: '',
          checkResult: '',
          reason: ''
        },
        dataRule: {
          eqName: [
            { required: true, message: '设备名称不能为空', trigger: 'blur' }
          ],
          checkStatus: [
            { required: true, message: '检修状态   0  未检修   1  已检修不能为空', trigger: 'blur' }
          ],
          // checkTime: [
          //   { required: true, message: '检修时间不能为空', trigger: 'blur' }
          // ],
          // empId: [
          //   { required: true, message: '检修人员  参照工作人员表id不能为空', trigger: 'blur' }
          // ],
          // checkResult: [
          //   { required: true, message: '检修结果不能为空', trigger: 'blur' }
          // ],
          // reason: [
          //   { required: true, message: '故障原因 不能为空', trigger: 'blur' }
          // ]
        }
      }
    },
    methods: {
      handleOpen(){
        this.getFixerList();
      },
      getFixerList(){
        this.$http({
          url:this.$http.adornUrl("/mysys/sysemployee/getEmpListByRole/2"),
          method:'get'
        }).then(({data})=>{
          if(data && data.code===0){
            this.fixerList=data.data;
          }
        })
      },
      init (id) {
        this.dataForm.eqId = id || 0
        this.visible = true
        this.$nextTick(() => {
          this.$refs['dataForm'].resetFields()
          if (this.dataForm.eqId) {
            this.$http({
              url: this.$http.adornUrl(`/houqin/hqservice/info/${this.dataForm.eqId}`),
              method: 'get',
              params: this.$http.adornParams()
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.dataForm.eqName = data.hqService.eqName
                this.dataForm.checkStatus = data.hqService.checkStatus
                this.dataForm.checkTime = data.hqService.checkTime
                this.dataForm.empId = data.hqService.empId
                this.dataForm.checkResult = data.hqService.checkResult
                this.dataForm.reason = data.hqService.reason
              }
            })
          }
        })
      },
      // 表单提交
      dataFormSubmit () {
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            this.$http({
              url: this.$http.adornUrl(`/houqin/hqservice/${!this.dataForm.eqId ? 'save' : 'update'}`),
              method: 'post',
              data: this.$http.adornData({
                'eqId': this.dataForm.eqId || undefined,
                'eqName': this.dataForm.eqName,
                'checkStatus': this.dataForm.checkStatus,
                'checkTime': this.dataForm.checkTime,
                'empId': this.dataForm.empId,
                'checkResult': this.dataForm.checkResult,
                'reason': this.dataForm.reason,
                'createTime': this.dataForm.createTime,
                'updateTime': this.dataForm.updateTime,
                'isDelete': this.dataForm.isDelete
              })
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.$message({
                  message: '操作成功',
                  type: 'success',
                  duration: 1500,
                  onClose: () => {
                    this.visible = false
                    this.$emit('refreshDataList')
                  }
                })
              } else {
                this.$message.error(data.msg)
              }
            })
          }
        })
      }
    }
  }
</script>
