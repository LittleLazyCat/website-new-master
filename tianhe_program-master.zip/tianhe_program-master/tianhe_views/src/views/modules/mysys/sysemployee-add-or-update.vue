<template>
  <el-dialog
    :title="!dataForm.id ? '新增' : '修改'"
    :close-on-click-modal="false"
    :visible.sync="visible"
    @open="handleOpen">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="100px">
    <el-form-item label="职工姓名" prop="empName">
      <el-input v-model="dataForm.empName" placeholder="职工姓名"></el-input>
    </el-form-item>
    <el-form-item label="职工头像" prop="headImgUrl">
      <!-- <el-input v-model="dataForm.headImgUrl" placeholder="职工头像"></el-input> -->
      <single-upload v-model="dataForm.headImgUrl"></single-upload>
    </el-form-item>
    <el-form-item label="职工电话" prop="empPhone">
      <el-input v-model="dataForm.empPhone" placeholder="职工电话"></el-input>
    </el-form-item>
    <el-form-item label="职工权限" prop="empRoleId">
      <el-select placeholder="职工权限" v-model="dataForm.empRoleId">
        <el-option
          v-for="item in empRoleList"
          :key="item.id"
          :label="item.roleName"
          :value="item.id">
          <template sloe-scope="{item}">{{item.roleName}}<span style="color: silver; font-size: smaller;"> ({{item.roleDesc}})</span></template>
        </el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="职工住址" prop="empAddress">
      <el-row>
         <el-col :span="12"><select-address @fromComponentAddress="fromComponentAddress" :Address="address"></select-address></el-col>
         <el-col :span="12"><el-input v-model="addressFloor" placeholder="请输入详细楼牌(此处选填)" :disabled="address.length===0"></el-input></el-col>
      </el-row>
    </el-form-item>
    <el-form-item label="职工身份证" prop="empIdentity">
      <el-input v-model="dataForm.empIdentity" placeholder="职工身份证"></el-input>
    </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
  import selectAddress from "../../../components/select-address/SelectAddress.vue"
  import singleUpload from "../../../components/upload/singleUpload.vue"
  export default {
    components:{
      selectAddress,
      singleUpload
    },
    data () {
      return {
        empRoleList:[],
        address:[],
        addressFloor:'',
        visible: false,
        dataForm: {
          id: 0,
          empName: '',
          headImgUrl: '',
          empPhone: '',
          empRoleId: '',
          empAddress: '',
          empIdentity: '',
          createTime: '',
          updateTime: '',
          isDelete: ''
        },
        dataRule: {
          empName: [
            { required: true, message: '职工姓名不能为空', trigger: 'blur' }
          ],
          headImgUrl: [
            { required: true, message: '职工头像不能为空', trigger: 'blur' }
          ],
          empPhone: [
            { required: true, message: '职工电话不能为空', trigger: 'blur' }
          ],
          empRoleId: [
            { required: true, message: '职工权限id：外键不能为空', trigger: 'blur' }
          ],
          empAddress: [
            { required: true, message: '职工住址不能为空', trigger: 'blur' }
          ],
          empIdentity: [
            { required: true, message: '职工身份证,唯一值不能为空', trigger: 'blur' }
          ]
        }
      }
    },
    methods: {
      fromComponentAddress(childValue){
        this.address=childValue;
        // this.dataForm.empAddress=this.address.join("/");
        console.log("d",this.address);
      },
      handleOpen(){
        this.getEmpRoleList();
      },
      getEmpRoleList(){
        this.$http({
          url:this.$http.adornUrl("/mysys/sysrole/infobylevel/3"),
          method:'get'
        }).then(({data})=>{
          if(data && data.code===0){
            this.empRoleList=data.data;
          }
        })
      },
      init (id) {
        this.dataForm.id = id || 0
        this.visible = true
        this.$nextTick(() => {
          this.$refs['dataForm'].resetFields()
          this.address=[]
          this.addressFloor=''
          if (this.dataForm.id) {
            this.$http({
              url: this.$http.adornUrl(`/mysys/sysemployee/info/${this.dataForm.id}`),
              method: 'get',
              params: this.$http.adornParams()
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.dataForm.empName = data.sysEmployee.empName
                this.dataForm.headImgUrl = data.sysEmployee.headImgUrl
                this.dataForm.empPhone = data.sysEmployee.empPhone
                this.dataForm.empRoleId = data.sysEmployee.empRoleId
                this.dataForm.empAddress = data.sysEmployee.empAddress
                let arr=this.dataForm.empAddress.split("/")
                this.addressFloor=(arr.pop()).toString().trim()
                this.address=arr
                this.dataForm.empIdentity = data.sysEmployee.empIdentity
              }
            })
          }
        })
      },
      // 表单提交
      dataFormSubmit () {
        if(this.addressFloor.trim())
          this.address.push(this.addressFloor.trim());
        this.dataForm.empAddress=this.address.join("/");
        console.log(this.address.length,this.address);
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            this.$http({
              url: this.$http.adornUrl(`/mysys/sysemployee/${!this.dataForm.id ? 'save' : 'update'}`),
              method: 'post',
              data: this.$http.adornData({
                'id': this.dataForm.id || undefined,
                'empName': this.dataForm.empName,
                'headImgUrl': this.dataForm.headImgUrl,
                'empPhone': this.dataForm.empPhone,
                'empRoleId': this.dataForm.empRoleId,
                'empAddress': this.dataForm.empAddress,
                'empIdentity': this.dataForm.empIdentity
              })
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.$message({
                  message: '操作成功',
                  type: 'success',
                  duration: 1500,
                  onClose: () => {
                    this.visible = false
                    this.$emit('refreshDataList')
                  }
                })
              } else {
                this.$message.error(data.msg)
              }
            })
          }
        })
      }
    }
  }
</script>
