<template>
  <el-dialog
    :title="!dataForm.id ? '新增' : '修改'"
    :close-on-click-modal="false"
    :visible.sync="visible">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="80px">
    <el-form-item label="权限名称" prop="roleName">
      <el-input v-model="dataForm.roleName" placeholder="权限名称"></el-input>
    </el-form-item>
    <el-form-item label="权限等级" prop="roleLevel">
      <el-select v-model="dataForm.roleLevel">
        <el-option v-for="item in roleLevelList" :key="item.value" :label="item.text" :value="item.value"></el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="描述权限" prop="roleDesc">
      <el-input v-model="dataForm.roleDesc" placeholder="描述权限"></el-input>
    </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
  export default {
    props:{
      roleLevelList:Array
    },
    data () {
      return {
        visible: false,
        dataForm: {
          id: 0,
          roleName: '',
          roleLevel: '',
          roleDesc: '',
          createTime: '',
          updateTime: '',
          idDelete: ''
        },
        dataRule: {
          roleName: [
            { required: true, message: '权限名称不能为空', trigger: 'blur' }
          ],
          roleLevel: [
            { required: true, message: '权限等级不能为空', trigger: 'blur' }
          ],
          roleDesc: [
            { required: true, message: '描述权限不能为空', trigger: 'blur' }
          ],
        }
      }
    },
    methods: {
      init (id) {
        this.dataForm.id = id || 0
        this.visible = true
        this.$nextTick(() => {
          this.$refs['dataForm'].resetFields()
          if (this.dataForm.id) {
            this.$http({
              url: this.$http.adornUrl(`/mysys/sysrole/info/${this.dataForm.id}`),
              method: 'get',
              params: this.$http.adornParams()
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.dataForm.roleName = data.sysRole.roleName
                this.dataForm.roleLevel = data.sysRole.roleLevel
                this.dataForm.roleDesc = data.sysRole.roleDesc
              }
            })
          }
        })
      },
      // 表单提交
      dataFormSubmit () {
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            this.$http({
              url: this.$http.adornUrl(`/mysys/sysrole/${!this.dataForm.id ? 'save' : 'update'}`),
              method: 'post',
              data: this.$http.adornData({
                'id': this.dataForm.id || undefined,
                'roleName': this.dataForm.roleName,
                'roleLevel': this.dataForm.roleLevel,
                'roleDesc': this.dataForm.roleDesc,
              })
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.$message({
                  message: '操作成功',
                  type: 'success',
                  duration: 1500,
                  onClose: () => {
                    this.visible = false
                    this.$emit('refreshDataList')
                  }
                })
              } else {
                this.$message.error(data.msg)
              }
            })
          }
        })
      }
    }
  }
</script>
