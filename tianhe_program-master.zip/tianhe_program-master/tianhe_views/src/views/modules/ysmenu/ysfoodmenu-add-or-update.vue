<template>
  <el-dialog
    :title="!dataForm.id ? '新增' : '修改'"
    :close-on-click-modal="false"
    :visible.sync="visible">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="80px">
    <el-form-item label="食品名称" prop="foodName">
      <el-input v-model="dataForm.foodName" placeholder="食品名称"></el-input>
    </el-form-item>
    <el-form-item label="食品类别" prop="classifyId">
      <el-input v-model="dataForm.classifyId" placeholder="食品类别"></el-input>
    </el-form-item>
    <el-form-item label="食品标签" prop="foodTag">
      <el-input v-model="dataForm.foodTag" placeholder="食品标签"></el-input>
    </el-form-item>
    <el-form-item label="食品价格" prop="foodPrice">
      <el-input v-model="dataForm.foodPrice" placeholder="食品价格"></el-input>
    </el-form-item>
    <el-form-item label="是否清真" prop="foodQingzhen">
      <el-radio-group v-model="dataForm.foodQingzhen" size="small">
        <el-radio-button label="1">是</el-radio-button>
        <el-radio-button label="0">否</el-radio-button>
      </el-radio-group>
    </el-form-item>
    <el-form-item label="供应星期" prop="supplyWeek">
      <el-select placeholder="请选择供应星期" v-model="dataForm.supplyWeek">
        <el-option
          v-for="item in week"
          :key="item.value"
          :label="item.label"
          :value="item.value">
        </el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="供应类型" prop="supplyKind">
      <!-- <el-input v-model="dataForm.supplyKind" placeholder="供应类型1早餐2午餐3晚餐"></el-input> -->
      <el-select v-model="dataForm.supplyKind" filterable placeholder="请选择">
          <el-option
            v-for="item in options"
            :key="item.value"
            :label="item.label"
            :value="item.value">
          </el-option>
      </el-select>
    </el-form-item>
    <!-- <el-form-item label="创建时间" prop="createTime">
      <el-input v-model="dataForm.createTime" placeholder="创建时间"></el-input>
    </el-form-item>
    <el-form-item label="更新时间" prop="updateTime">
      <el-input v-model="dataForm.updateTime" placeholder="更新时间"></el-input>
    </el-form-item>
    <el-form-item label="默认为1，0表示删除" prop="isDelete">
      <el-input v-model="dataForm.isDelete" placeholder="默认为1，0表示删除"></el-input>
    </el-form-item> -->
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
  export default {
    data () {
      return {
        visible: false,
        options:[
          {value:1,label:"早餐"},
          {value:2,label:"午餐"},
          {value:3,label:"晚餐"}
        ],
        week:[
          {value:1,label:"周一"},
          {value:2,label:"周二"},
          {value:3,label:"周三"},
          {value:4,label:"周四"},
          {value:5,label:"周五"},
          {value:6,label:"周六"},
          {value:7,label:"周天"},
        ],
        dataForm: {
          foodId: 0,
          foodName: '',
          classifyId: '',
          foodTag: '',
          foodPrice: '',
          foodQingzhen: '',
          supplyWeek: '',
          supplyKind: '',
          createTime: '',
          updateTime: '',
          isDelete: ''
        },
        dataRule: {
          foodName: [
            { required: true, message: '食品名称不能为空', trigger: 'blur' }
          ],
          classifyId: [
            { required: true, message: '食品类别不能为空', trigger: 'blur' }
          ],
          foodTag: [
            { required: true, message: '食品标签不能为空', trigger: 'blur' }
          ],
          foodPrice: [
            { required: true, message: '食品价格不能为空', trigger: 'blur' }
          ],
          foodQingzhen: [
            { required: true, message: '是否清真不能为空', trigger: 'blur' }
          ],
          supplyWeek: [
            { required: true, message: '供应星期不能为空', trigger: 'blur' }
          ],
          supplyKind: [
            { required: true, message: '供应类型不能为空', trigger: 'blur' }
          ]
        }
      }
    },
    methods: {
      init (id) {
        this.dataForm.foodId = id || 0
        this.visible = true
        this.$nextTick(() => {
          this.$refs['dataForm'].resetFields()
          if (this.dataForm.foodId) {
            this.$http({
              url: this.$http.adornUrl(`/ysmenu/ysfoodmenu/info/${this.dataForm.foodId}`),
              method: 'get',
              params: this.$http.adornParams()
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.dataForm.foodName = data.ysFoodMenu.foodName
                this.dataForm.classifyId = data.ysFoodMenu.classifyId
                this.dataForm.foodTag = data.ysFoodMenu.foodTag
                this.dataForm.foodPrice = data.ysFoodMenu.foodPrice
                this.dataForm.foodQingzhen = data.ysFoodMenu.foodQingzhen
                this.dataForm.supplyWeek = data.ysFoodMenu.supplyWeek
                this.dataForm.supplyKind = data.ysFoodMenu.supplyKind
                /* this.dataForm.createTime = data.ysFoodMenu.createTime
                this.dataForm.updateTime = data.ysFoodMenu.updateTime
                this.dataForm.isDelete = data.ysFoodMenu.isDelete */
              }
            })
          }
        })
      },
      // 表单提交
      dataFormSubmit () {
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            this.$http({
              url: this.$http.adornUrl(`/ysmenu/ysfoodmenu/${!this.dataForm.foodId ? 'save' : 'update'}`),
              method: 'post',
              data: this.$http.adornData({
                'foodId': this.dataForm.foodId || undefined,
                'foodName': this.dataForm.foodName,
                'classifyId': this.dataForm.classifyId,
                'foodTag': this.dataForm.foodTag,
                'foodPrice': this.dataForm.foodPrice,
                'foodQingzhen': this.dataForm.foodQingzhen,
                'supplyWeek': this.dataForm.supplyWeek,
                'supplyKind': this.dataForm.supplyKind,
                /* 'createTime': this.dataForm.createTime,
                'updateTime': this.dataForm.updateTime,
                'isDelete': this.dataForm.isDelete */
              })
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.$message({
                  message: '操作成功',
                  type: 'success',
                  duration: 1500,
                  onClose: () => {
                    this.visible = false
                    this.$emit('refreshDataList')
                  }
                })
              } else {
                this.$message.error(data.msg)
              }
            })
          }
        })
      }
    }
  }
</script>
