<template>
  <el-dialog
    :title="!dataForm.id ? '新增' : '修改'"
    :close-on-click-modal="false"
    :visible.sync="visible"
    @open="handleOpen">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="80px">
    <el-form-item label="客户id" prop="customerId">
      <el-select v-model="dataForm.customerId" placeholder="请选择客户">
        <el-option v-for="item in customerList" :key="item.identityNumber" :label="item.customerName" :value="item.customerId">
          <template sloe-scope="{item}">{{item.customerName}}-{{item.identityNumber}}</template>
        </el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="饮食id" prop="foodId">
      <el-select v-model="dataForm.foodId" placeholder="请选择食品">
        <el-option v-for="item in foodMenu" :key="item.foodId" :label="item.foodName" :value="item.foodId">
          <template sloe-scope="{item}">{{item.foodName}}<span style="color: silver;font-size: smaller;">({{item.foodTag}})</span></template>
        </el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="计划周期" prop="planDay">
      <el-select v-model="dataForm.planDay" placeholder="请选择客户">
        <el-option v-for="item in planWeek" :key="item.value" :label="item.text" :value="item.value">
        </el-option>
      </el-select>
    </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
  export default {
    props:{
      planWeek:Array
    },
    data () {
      return {
        customerList:[],
        foodMenu:[],
        visible: false,
        dataForm: {
          id: 0,
          customerId: '',
          foodId: '',
          planDay: '',
          createTime: '',
          updateTime: '',
          isDelete: ''
        },
        dataRule: {
          customerId: [
            { required: true, message: '客户id：参照客户档案id不能为空', trigger: 'blur' }
          ],
          foodId: [
            { required: true, message: '饮食id：参照饮食菜单中id不能为空', trigger: 'blur' }
          ],
          planDay: [
            { required: true, message: '计划周期:(星期)1-7不能为空', trigger: 'blur' }
          ]
        }
      }
    },
    methods: {
      handleOpen(){
        this.getFoodMenu();
        this.getCustomerList();
      },
      getFoodMenu(){
        this.$http({
          url: this.$http.adornUrl(`/ysmenu/ysfoodmenu/list_no_page`),
          method: 'get',
        }).then(({data})=>{
          if (data && data.code === 0) {
            this.foodMenu=data.data;
          }
        })
      },
      getCustomerList(){
        this.$http({
          url: this.$http.adornUrl(`/customer/infocheckout/getCheckedCustomer`),
          method: 'get',
        }).then(({data})=>{
          if (data && data.code === 0) {
            this.customerList=data.data;
          }
        })
      },
      init (id) {
        this.dataForm.id = id || 0
        this.visible = true
        this.$nextTick(() => {
          this.$refs['dataForm'].resetFields()
          if (this.dataForm.id) {
            this.$http({
              url: this.$http.adornUrl(`/ysmenu/ysfoodplan/info/${this.dataForm.id}`),
              method: 'get',
              params: this.$http.adornParams()
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.dataForm.customerId = data.ysFoodPlan.customerId
                this.dataForm.foodId = data.ysFoodPlan.foodId
                this.dataForm.planDay = data.ysFoodPlan.planDay
              }
            })
          }
        })
      },
      // 表单提交
      dataFormSubmit () {
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            this.$http({
              url: this.$http.adornUrl(`/ysmenu/ysfoodplan/${!this.dataForm.id ? 'save' : 'update'}`),
              method: 'post',
              data: this.$http.adornData({
                'id': this.dataForm.id || undefined,
                'customerId': this.dataForm.customerId,
                'foodId': this.dataForm.foodId,
                'planDay': this.dataForm.planDay,
              })
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.$message({
                  message: '操作成功',
                  type: 'success',
                  duration: 1500,
                  onClose: () => {
                    this.visible = false
                    this.$emit('refreshDataList')
                  }
                })
              } else {
                this.$message.error(data.msg)
              }
            })
          }
        })
      }
    }
  }
</script>
